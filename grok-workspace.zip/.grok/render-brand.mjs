import { chromium } from "playwright";
import { writeFileSync } from "node:fs";

const fonts = `
@font-face { font-family: "LSerif"; src: url("fonts/LiberationSerif-Regular.ttf") format("truetype"); font-weight: 400; font-style: normal; }
@font-face { font-family: "LSerif"; src: url("fonts/LiberationSerif-Bold.ttf") format("truetype"); font-weight: 700; font-style: normal; }
@font-face { font-family: "LSerif"; src: url("fonts/LiberationSerif-Italic.ttf") format("truetype"); font-weight: 400; font-style: italic; }
@font-face { font-family: "LSans"; src: url("fonts/LiberationSans-Regular.ttf") format("truetype"); font-weight: 400; font-style: normal; }
@font-face { font-family: "LSans"; src: url("fonts/LiberationSans-Bold.ttf") format("truetype"); font-weight: 700; font-style: normal; }
`;

const paper = `
  .sheet {
    position: absolute; inset: 0;
    background-color: #F4EFE4;
    background-image: repeating-linear-gradient(
      to bottom,
      transparent 0 31px,
      rgba(14, 92, 100, 0.11) 31px 32px
    );
  }
  .grain {
    position: absolute; inset: 0;
    background-image: url("noise.png");
    background-size: 480px 480px;
    opacity: 0.16;
    mix-blend-mode: multiply;
    pointer-events: none;
  }
  .margin {
    position: absolute; top: 0; bottom: 0; width: 1.5px; background: #8C3040;
  }
`;

const og = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<style>
  ${fonts}
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { width: 1200px; height: 630px; overflow: hidden; background: #F4EFE4; }
  ${paper}
  .margin { left: 64px; }
  .safe { position: absolute; inset: 36px 72px 32px 88px; display: flex; flex-direction: column; }
  .dbl { display: flex; flex-direction: column; gap: 3px; }
  .dbl .thick { height: 3px; background: #0E5C64; }
  .dbl .thin { height: 1px; background: #0E5C64; }
  .mast {
    margin: 16px 0 0;
    text-align: center;
    font-family: "LSans", sans-serif;
    font-weight: 700;
    font-size: 13px;
    letter-spacing: 0.42em;
    color: #0E5C64;
  }
  .stage { flex: 1; display: flex; align-items: center; justify-content: center; }
  .card {
    position: relative;
    width: 940px;
    background: #F4EFE4;
    border: 1px solid #B0893E;
    box-shadow: inset 0 0 0 7px #F4EFE4, inset 0 0 0 8px rgba(14, 92, 100, 0.85);
    padding: 26px 40px 22px;
    text-align: center;
  }
  .tick { position: absolute; width: 18px; height: 18px; pointer-events: none; }
  .tl { top: -3px; left: -3px; border-top: 2px solid #8C3040; border-left: 2px solid #8C3040; }
  .tr { top: -3px; right: -3px; border-top: 2px solid #8C3040; border-right: 2px solid #8C3040; }
  .bl { bottom: -3px; left: -3px; border-bottom: 2px solid #8C3040; border-left: 2px solid #8C3040; }
  .br { bottom: -3px; right: -3px; border-bottom: 2px solid #8C3040; border-right: 2px solid #8C3040; }
  .kicker {
    font-family: "LSans", sans-serif;
    font-weight: 700;
    font-size: 13px;
    letter-spacing: 0.46em;
    color: #8C3040;
  }
  h1 {
    margin-top: 8px;
    font-family: "LSerif", serif;
    font-weight: 400;
    color: #122326;
    line-height: 0.92;
  }
  h1 .l1 { display: block; font-size: 128px; letter-spacing: -0.02em; }
  h1 .l2 { display: block; font-size: 150px; letter-spacing: -0.025em; margin-top: 8px; }
  .goldrule { width: 84px; height: 1px; background: #B0893E; margin: 18px auto 12px; }
  .sub {
    font-family: "LSerif", serif;
    font-style: italic;
    font-size: 26px;
    letter-spacing: 0.08em;
    color: #B0893E;
  }
  .answers {
    display: flex;
    justify-content: center;
    gap: 36px;
    margin: 18px 0 16px;
    font-family: "LSerif", serif;
    font-size: 18px;
    color: #122326;
  }
  .opt { display: flex; align-items: center; gap: 10px; }
  .dot {
    width: 13px; height: 13px; border-radius: 50%;
    border: 1.5px solid #122326;
    box-sizing: border-box;
  }
  .dot.on { background: #8C3040; border-color: #8C3040; }
  .bar { width: 72px; height: 1px; background: rgba(18, 35, 38, 0.55); }
</style>
</head>
<body>
  <div class="sheet"></div>
  <div class="grain"></div>
  <div class="margin"></div>
  <div class="safe">
    <div class="dbl"><div class="thick"></div><div class="thin"></div></div>
    <div class="mast">CURRENT AFFAIRS</div>
    <div class="stage">
      <div class="card" id="card">
        <span class="tick tl"></span><span class="tick tr"></span>
        <span class="tick bl"></span><span class="tick br"></span>
        <div class="kicker">MULTIPLE CHOICE</div>
        <h1 id="title"><span class="l1">Week One</span><span class="l2">Drill</span></h1>
        <div class="goldrule"></div>
        <div class="sub" id="sub">1–7 August 2026</div>
      </div>
    </div>
    <div class="answers" id="answers">
      <div class="opt"><span>A</span><span class="dot"></span><span class="bar"></span></div>
      <div class="opt"><span>B</span><span class="dot"></span><span class="bar"></span></div>
      <div class="opt"><span>C</span><span class="dot on"></span><span class="bar"></span></div>
      <div class="opt"><span>D</span><span class="dot"></span><span class="bar"></span></div>
    </div>
    <div class="dbl"><div class="thin"></div><div class="thick"></div></div>
  </div>
</body>
</html>`;

const banner = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<style>
  ${fonts}
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body { width: 1200px; height: 264px; overflow: hidden; background: #F4EFE4; }
  ${paper}
  .sheet {
    background-image: repeating-linear-gradient(
      to bottom,
      transparent 0 21px,
      rgba(14, 92, 100, 0.11) 21px 22px
    );
  }
  .margin { left: 36px; }
  .toprule {
    position: absolute; left: 56px; right: 40px; top: 16px;
    display: flex; flex-direction: column; gap: 3px;
  }
  .toprule .thick { height: 3px; background: #0E5C64; }
  .toprule .thin { height: 1px; background: #0E5C64; }
  .lockup { position: absolute; left: 64px; top: 34px; width: 500px; }
  .kicker {
    font-family: "LSans", sans-serif;
    font-weight: 700;
    font-size: 12px;
    letter-spacing: 0.38em;
    color: #0E5C64;
  }
  h1 {
    margin-top: 4px;
    font-family: "LSerif", serif;
    font-weight: 400;
    color: #122326;
    line-height: 0.92;
  }
  h1 .l1 { display: block; font-size: 54px; }
  h1 .l2 { display: block; font-size: 70px; margin-top: 4px; }
  .sub {
    margin-top: 6px;
    font-family: "LSerif", serif;
    font-style: italic;
    font-size: 18px;
    letter-spacing: 0.06em;
    color: #B0893E;
  }
  .slip {
    position: absolute;
    left: 700px; top: 40px;
    width: 620px; height: 150px;
    background: #F4EFE4;
    border: 1px solid #B0893E;
    box-shadow: inset 0 0 0 5px #F4EFE4, inset 0 0 0 6px rgba(14, 92, 100, 0.85);
  }
  .tick { position: absolute; width: 14px; height: 14px; }
  .tl { top: -3px; left: -3px; border-top: 2px solid #8C3040; border-left: 2px solid #8C3040; }
  .bl { bottom: -3px; left: -3px; border-bottom: 2px solid #8C3040; border-left: 2px solid #8C3040; }
  .rows { position: absolute; left: 22px; top: 28px; display: flex; flex-direction: column; gap: 18px; }
  .row { display: flex; align-items: center; gap: 12px; }
  .dot {
    width: 12px; height: 12px; border-radius: 50%;
    border: 1.5px solid #122326; box-sizing: border-box;
  }
  .dot.on { background: #8C3040; border-color: #8C3040; }
  .bar { height: 1px; background: rgba(18, 35, 38, 0.5); }
</style>
</head>
<body>
  <div class="sheet"></div>
  <div class="grain"></div>
  <div class="margin"></div>
  <div class="toprule"><div class="thick"></div><div class="thin"></div></div>
  <div class="lockup" id="lockup">
    <div class="kicker">CURRENT AFFAIRS</div>
    <h1 id="title"><span class="l1">Week One</span><span class="l2">Drill</span></h1>
    <div class="sub" id="sub">1–7 August 2026</div>
  </div>
  <div class="slip">
    <span class="tick tl"></span><span class="tick bl"></span>
    <div class="rows">
      <div class="row"><span class="dot"></span><span class="bar" style="width:180px"></span></div>
      <div class="row"><span class="dot on"></span><span class="bar" style="width:220px"></span></div>
      <div class="row"><span class="dot"></span><span class="bar" style="width:150px"></span></div>
    </div>
  </div>
</body>
</html>`;

writeFileSync("/workspace/.grok/og-card.html", og);
writeFileSync("/workspace/.grok/x-banner.html", banner);

const browser = await chromium.launch({ args: ["--no-sandbox", "--font-render-hinting=none"] });

async function shoot(file, width, height, out) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: 2,
  });
  await page.goto(`file:///workspace/.grok/${file}`);
  await page.screenshot({ path: out, type: "png" });
  const box = await page.evaluate(() => {
    const rect = (id) => {
      const el = document.getElementById(id);
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: r.x, y: r.y, w: r.width, h: r.height, right: r.right, bottom: r.bottom, text: el.innerText };
    };
    return { title: rect("title"), sub: rect("sub"), lockup: rect("lockup"), card: rect("card"), answers: rect("answers") };
  });
  await page.close();
  return box;
}

const ogBox = await shoot("og-card.html", 1200, 630, "/workspace/.grok/og-raw.png");
const banBox = await shoot("x-banner.html", 1200, 264, "/workspace/.grok/x-banner-raw.png");
await browser.close();
console.log(JSON.stringify({ ogBox, banBox }, null, 2));
