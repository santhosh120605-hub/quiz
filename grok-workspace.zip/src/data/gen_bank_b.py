#!/usr/bin/env python3
import json
from pathlib import Path

qs = json.loads(Path("/tmp/qs_part_a.json").read_text())

def add(s, t, q, a, d1, d2, d3, w):
    qs.append({"s": s, "t": t, "q": q, "a": a, "d": [d1, d2, d3], "w": w})

PIB = "GA · PIB"
OTH = "GA · Other"
ESI = "GA + ESI"
FIN = "GA + Finance"

# ---------- CWG ----------
T = "Commonwealth Games 2026"
add(OTH, T, "The 2026 Commonwealth Games, the 23rd edition, were hosted in which city?",
    "Glasgow, Scotland", "Birmingham, England", "Gold Coast, Australia", "Victoria, Australia",
    "They were hosted at Glasgow, Scotland.")
add(OTH, T, "The 2026 Games were originally awarded to which host, before a withdrawal?",
    "Victoria, Australia", "Durban, South Africa", "Edmonton, Canada", "Kuala Lumpur, Malaysia",
    "They were originally awarded to Victoria, Australia, which withdrew over escalating costs.")
add(OTH, T, "Glasgow 2026 was which time Scotland has hosted the Commonwealth Games?",
    "The fourth time", "The third time", "The second time", "The first time",
    "Scotland had hosted in Edinburgh (1970, 1986) and Glasgow (2014) before 2026.")
add(OTH, T, "Which earlier Scottish hosts are named before Glasgow 2026?",
    "Edinburgh 1970, Edinburgh 1986 and Glasgow 2014",
    "Edinburgh 1970, Glasgow 1986 and Glasgow 2014",
    "Edinburgh 1986 and Glasgow 2014 only",
    "Glasgow 1970, 1986 and 2014",
    "Previous Scottish Games were Edinburgh 1970, Edinburgh 1986 and Glasgow 2014.")
add(OTH, T, "Which set correctly names the four venues of Glasgow 2026?",
    "Scotstoun Stadium, Tollcross International Swimming Centre, Glasgow International Arena and the Scottish Event Campus",
    "Hampden Park, Tollcross, Emirates Arena and Celtic Park",
    "Scotstoun, London Aquatics Centre, SEC and Murrayfield",
    "Only the Scottish Event Campus",
    "The four venues are Scotstoun, Tollcross, Glasgow International Arena and the SEC.")
add(OTH, T, "The mascot of the 2026 Commonwealth Games was:",
    "Finnie, a Glaswegian unicorn", "Mayur, a peacock", "Borobi, a koala", "Clyde, a thistle man",
    "The mascot was Finnie, a Glaswegian unicorn, Scotland’s national animal.")
add(OTH, T, "The Indian squad’s official attire at Glasgow 2026 was:",
    "Sustainable “Make in India” jute apparel designed by NIFT New Delhi",
    "Khadi jackets designed by NIFT Mumbai",
    "Recycled polyester kits by the Sports Authority of India",
    "Jute apparel designed by NID Ahmedabad",
    "The squad wore sustainable Make in India jute apparel designed by NIFT New Delhi.")
add(OTH, T, "How many sports were on the Glasgow 2026 programme, and how many were integrated para-sports?",
    "10 sports, including six integrated para-sports",
    "15 sports, including six para-sports",
    "10 sports, including four para-sports",
    "7 sports, with table tennis included",
    "There were 10 sports, including six integrated para-sports. Table tennis was not in the CWG programme.")
add(OTH, T, "Who was India’s opening-ceremony flag bearer at Glasgow 2026?",
    "Mirabai Chanu (weightlifting)", "Lovlina Borgohain (boxing)", "Neeraj Chopra", "Jaismine Lamboria",
    "Mirabai Chanu was the opening ceremony flag bearer.")
add(OTH, T, "Who carried the baton for India at the opening ceremony?",
    "Lovlina Borgohain (boxing)", "Mirabai Chanu", "P. T. Usha", "Jaismine Lamboria",
    "Lovlina Borgohain was the opening ceremony baton bearer.")
add(OTH, T, "Who was India’s closing-ceremony flag bearer?",
    "Jaismine Lamboria", "Mirabai Chanu", "Neeraj Chopra", "Lovlina Borgohain",
    "Jaismine Lamboria was the closing ceremony flag bearer.")
add(OTH, T, "In the Glasgow 2026 medal table, which country ranked first, and with how many golds?",
    "Australia with 70 golds", "England with 70 golds", "Australia with 45 golds", "India with 22 golds",
    "Australia led with 70 gold, 45 silver, 56 bronze, total 171.")
add(OTH, T, "England’s Glasgow 2026 medal count was:",
    "29 gold, 45 silver, 36 bronze, total 110",
    "45 gold, 29 silver, 36 bronze, total 110",
    "29 gold, 36 silver, 45 bronze, total 110",
    "19 gold, 20 silver, 23 bronze, total 62",
    "England was second with 29-45-36 and a total of 110.")
add(OTH, T, "Canada finished third at Glasgow 2026 with which haul?",
    "19 gold, 20 silver, 23 bronze, total 62",
    "13 gold, 17 silver, 9 bronze, total 39",
    "20 gold, 19 silver, 23 bronze, total 62",
    "23 gold, 20 silver, 19 bronze, total 62",
    "Canada had 19 gold, 20 silver and 23 bronze, total 62.")
add(OTH, T, "India’s Glasgow 2026 medal tally was:",
    "13 gold, 17 silver, 9 bronze, total 39",
    "13 gold, 9 silver, 17 bronze, total 39",
    "17 gold, 13 silver, 9 bronze, total 39",
    "22 gold, 16 silver, 23 bronze, total 61",
    "India was fourth with 13-17-9, total 39.")
add(OTH, T, "Scotland’s total medals at Glasgow 2026 equalled India’s, but the split was:",
    "13 gold, 9 silver, 17 bronze",
    "13 gold, 17 silver, 9 bronze",
    "9 gold, 13 silver, 17 bronze",
    "17 gold, 13 silver, 9 bronze",
    "Scotland also totalled 39, with 13 gold, 9 silver and 17 bronze.")
add(OTH, T, "Which sport is called the backbone of India’s 2026 Commonwealth campaign?",
    "Boxing", "Weightlifting", "Athletics", "Judo",
    "Boxing emerged as the backbone of India’s 2026 campaign.")
add(OTH, T, "Indian boxers won how many medals at Glasgow 2026, including how many golds?",
    "10 medals, including 7 golds", "7 medals, including 5 golds", "10 medals, including 5 golds", "13 medals, including 7 golds",
    "Indian boxers clinched 10 medals, including 7 golds — the highest gold haul by one nation in boxing at a single CWG.")
add(OTH, T, "India produced double podiums in which three events?",
    "Men’s 100 m T47, men’s shot put F57 and women’s shot put F57",
    "Men’s and women’s 100 m and the javelin",
    "Three boxing weight classes",
    "Men’s high jump, long jump and triple jump",
    "The three double podiums were men’s 100 m T47 and the men’s and women’s shot put F57.")
add(OTH, T, "Who won India’s first gold medal at CWG 2026?",
    "Mirabai Chanu in the women’s 48 kg weightlifting",
    "Preeti Pawar in boxing",
    "Sharmila Dhankar in para shot put",
    "Jhandu Kumar in para powerlifting",
    "Mirabai Chanu’s women’s 48 kg gold was India’s first gold. Jhandu Kumar had won India’s first medal, a bronze.")
add(OTH, T, "Mirabai Chanu’s Glasgow gold completed a hat-trick of CWG golds from which editions?",
    "2018, 2022 and 2026", "2014, 2018 and 2022", "2010, 2018 and 2026", "2018, 2024 and 2026",
    "She had won gold in 2018 and 2022; Glasgow 2026 completed the hat-trick.")
add(OTH, T, "Before Mirabai Chanu, which Indian had won three successive individual Commonwealth golds?",
    "Vinesh Phogat", "Mary Kom", "Sushil Kumar", "Neeraj Chopra",
    "She became only the second Indian, after Vinesh Phogat, to win three successive individual CWG golds.")
add(OTH, T, "Mirabai Chanu’s Glasgow records in snatch and clean & jerk were:",
    "85 kg snatch and 105 kg clean and jerk",
    "87 kg snatch and 108 kg clean and jerk",
    "85 kg snatch and 110 kg clean and jerk",
    "80 kg snatch and 105 kg clean and jerk",
    "She lifted 85 kg in the snatch and 105 kg in the clean and jerk, both CWG records.")
add(OTH, T, "What is unique about Mirabai Chanu among India’s gold medallists at CWG 2026?",
    "She was the only Indian gold medallist who was not a first-time CWG gold winner",
    "She was the only woman gold medallist",
    "She was the only medallist from Manipur",
    "She was the only athlete with two golds",
    "She was the only Indian gold medallist at CWG 2026 who was not winning a CWG gold for the first time.")
add(OTH, T, "Sharmila Dhankar’s gold was a first for India in which sense?",
    "India’s first Commonwealth Games gold in para athletics",
    "India’s first CWG medal in any para sport",
    "India’s first women’s athletics gold at a CWG",
    "India’s first shot put medal of any kind",
    "She is India’s first CWG gold medallist in para athletics, in women’s shot put F57.")
add(OTH, T, "Who won bronze behind Sharmila Dhankar in women’s shot put F57, and which first did that person mark?",
    "Shilpa K. Shyla, Karnataka’s first para-athlete to win a CWG medal",
    "Soman Rana, Bihar’s first para medallist",
    "Shubham Juyal, Uttarakhand’s first para medallist",
    "Dilip Gavit, Maharashtra’s first para gold",
    "Shilpa K. Shyla took bronze and is Karnataka’s first para-athlete CWG medallist. It was India’s first double podium in a CWG para-athletics event.")
add(OTH, T, "Dilip Gavit won men’s 100 m T47 in what time, and that time was:",
    "10.71 seconds, a Games Record", "10.61 seconds, a World Record", "10.81 seconds, a Games Record", "11.71 seconds, an Asian Record",
    "He set a Games Record of 10.71 seconds and became the first Indian to win CWG gold in men’s 100 m T47.")
add(OTH, T, "Who won silver in the men’s 100 m T47 behind Dilip Gavit?",
    "Mohammed Basil Morssinganakathi of Kerala",
    "Soman Rana of Bihar",
    "Gulveer Singh of Uttar Pradesh",
    "Shubham Juyal of Uttarakhand",
    "Mohammed Basil Morssinganakathi (Kerala) won silver.")
add(OTH, T, "Asmita Dey’s women’s −48 kg judo gold made her:",
    "The first Indian judoka, and the first Indian woman, to win a CWG judo gold",
    "The first Indian male judoka to win CWG gold",
    "The second Indian woman judoka with a CWG gold",
    "A silver medallist from Delhi",
    "Asmita Dey (Tripura) was the first Indian judoka to win CWG gold and the first Indian woman to do so.")
add(OTH, T, "Harsh Singh, who won men’s −60 kg judo gold, is from which place, and what first did he achieve?",
    "Delhi; the first Indian male judoka to win a CWG gold",
    "Haryana; the first Indian judoka of either gender to win gold",
    "Manipur; a third successive judo gold",
    "Tripura; silver in −60 kg",
    "Harsh Singh (Delhi) became the first Indian male judoka to win a Commonwealth Games gold.")
add(OTH, T, "Which boxer won the women’s 54 kg gold at Glasgow 2026?",
    "Preeti Pawar (Haryana)", "Jaismine Lamboria (Haryana)", "Lovlina Borgohain (Assam)", "Sakshi Chaudhary (Haryana)",
    "Preeti Pawar won women’s 54 kg. Jaismine won 57 kg, Sakshi 51 kg, and Lovlina took 75 kg silver.")
add(OTH, T, "Jaismine Lamboria’s women’s 57 kg gold followed which earlier CWG result?",
    "Bronze at Birmingham 2022", "Gold at Birmingham 2022", "Silver at Gold Coast 2018", "No previous CWG medal",
    "She had earlier won bronze at Birmingham 2022.")
add(OTH, T, "Soman Rana won gold in which event, and who took silver in the same event?",
    "Men’s shot put F57; Shubham Juyal (Uttarakhand)",
    "Women’s shot put F57; Shilpa K. Shyla",
    "Men’s shot put F57; Jhandu Kumar",
    "Men’s javelin; Neeraj Chopra",
    "Soman Rana (Bihar) won men’s shot put F57 gold; Shubham Juyal took silver.")
add(OTH, T, "Match the Glasgow boxing gold: women’s 51 kg, 60 kg and 70 kg.",
    "Sakshi Chaudhary, Priya Ghanghas and Arundhati Choudhary",
    "Preeti Pawar, Jaismine Lamboria and Lovlina Borgohain",
    "Sakshi Chaudhary, Nikhat Zareen and Lovlina Borgohain",
    "Priya Ghanghas, Sakshi Chaudhary and Jaismine Lamboria",
    "Sakshi Chaudhary won 51 kg, Priya Ghanghas 60 kg and Arundhati Choudhary (Rajasthan) 70 kg.")
add(OTH, T, "The two Indian men who won boxing gold at Glasgow were:",
    "Sachin Siwach (60 kg) and Ankush Panghal (80 kg), both from Haryana",
    "Amit Panghal (51 kg) and Sachin Siwach (57 kg)",
    "Ankush Panghal (60 kg) and Sachin Siwach (80 kg)",
    "Hussamuddin (57 kg) and Nishant Dev (71 kg)",
    "Sachin Siwach won men’s 60 kg and Ankush Panghal men’s 80 kg, both from Haryana.")
add(OTH, T, "India’s first silver medallist at CWG 2026 was:",
    "Chanambam Rishikanta Singh in men’s 60 kg weightlifting",
    "Neeraj Chopra in the javelin",
    "Lovlina Borgohain in boxing",
    "Murali Sreeshankar in the long jump",
    "Chanambam Rishikanta Singh (Manipur) was India’s first silver medallist.")
add(OTH, T, "Chanambam Rishikanta Singh’s silver also marked which state first?",
    "Manipur’s first male CWG medallist in weightlifting",
    "Manipur’s first CWG medal in any sport",
    "Haryana’s first weightlifting medal",
    "A CWG record in the clean and jerk of 176 kg",
    "He is Manipur’s first male CWG medallist in weightlifting and also produced a CWG record in the snatch.")
add(OTH, T, "Neeraj Chopra’s Glasgow javelin medal was:",
    "Silver, his second CWG medal after gold at Gold Coast 2018",
    "Gold, his second successive CWG gold",
    "Bronze, his first CWG medal",
    "Silver, after bronze at Birmingham 2022",
    "He won silver, his second CWG medal after gold at Gold Coast 2018.")
add(OTH, T, "Murali Sreeshankar’s men’s long jump silver at Glasgow was:",
    "His second consecutive CWG silver, repeating Birmingham 2022",
    "His first CWG medal",
    "A gold, upgrading his 2022 silver",
    "A bronze behind a Malaysian",
    "It was his second consecutive CWG silver.")
add(OTH, T, "Praveen Chithravel, who won silver in the men’s triple jump, represents which state, and was the medal:",
    "Tamil Nadu; a maiden CWG medal", "Kerala; a second medal", "Tamil Nadu; a gold", "Karnataka; a maiden medal",
    "Praveen Chithravel (Tamil Nadu) won a maiden CWG medal, silver in the triple jump.")
add(OTH, T, "Sarvesh Anil Kushare’s silver was a first for India in which event?",
    "Men’s high jump — the first Indian CWG silver in that event",
    "Men’s pole vault",
    "Men’s long jump",
    "Men’s decathlon",
    "He was the first Indian to win a CWG silver in the men’s high jump. He is from Maharashtra.")
add(OTH, T, "Gulveer Singh’s Glasgow campaign is distinctive because:",
    "He won 10,000 m silver and 5,000 m bronze — the only Indian with two medals at Glasgow 2026",
    "He won two golds in distance events",
    "He was the flag bearer and a medallist",
    "He won India’s only track gold",
    "He was the only Indian to win two medals at Glasgow 2026, and the first Indian track-and-field athlete with two individual medals at one CWG.")
add(OTH, T, "Gulveer Singh was the first Indian, male or female, to win a CWG medal in which event?",
    "The 5,000 m", "The marathon", "The 1500 m", "The 400 m hurdles",
    "He was the first Indian athlete of either gender to medal in the 5,000 m. His 10,000 m medal was also an Indian first in the men’s event.")
add(OTH, T, "Valluri Ajaya Babu’s silver in the men’s 79 kg weightlifting is notable because:",
    "His father, Valluri Srinivasa Rao, was a 2010 CWG bronze medallist",
    "He is the son of Karnam Malleswari",
    "He broke a world record",
    "He is from Tamil Nadu and was on debut at 65 kg",
    "He joined his father Valluri Srinivasa Rao, a 2010 bronze medallist, as a rare father-son CWG medal pair. Ajaya Babu is from Andhra Pradesh.")
add(OTH, T, "Raja Muthupandi, a CWG debutant who medalled, competed in which class and for which state?",
    "Men’s 65 kg weightlifting, Tamil Nadu",
    "Men’s 79 kg weightlifting, Andhra Pradesh",
    "Men’s +110 kg, Punjab",
    "Men’s 60 kg, Manipur",
    "Raja Muthupandi (Tamil Nadu) medalled in the men’s 65 kg on his Commonwealth Games debut.")
add(OTH, T, "Harjinder Kaur upgraded which previous medal in the women’s 69 kg?",
    "Birmingham 2022 bronze to Glasgow 2026 silver",
    "2022 silver to 2026 gold",
    "2018 gold to 2026 silver",
    "2022 bronze to 2026 bronze again",
    "She upgraded her Birmingham 2022 bronze to silver in 2026. She is from Punjab.")
add(OTH, T, "Lovepreet Singh’s snatch record at Glasgow, in the men’s +110 kg, was:",
    "176 kg, while upgrading a 2022 bronze to silver",
    "166 kg, with a gold",
    "186 kg, with a bronze",
    "176 kg in the clean and jerk",
    "He upgraded his 2022 bronze to silver and set a CWG snatch record of 176 kg. He is from Punjab.")
add(OTH, T, "Lovlina Borgohain’s result at Glasgow 2026 was:",
    "Silver in the women’s 75 kg, her first Commonwealth Games medal",
    "Gold in the women’s 75 kg",
    "Bronze in the women’s 70 kg",
    "Silver in the women’s 70 kg, her second CWG medal",
    "The Olympic medallist won her first CWG medal, a silver at 75 kg. She is from Assam.")
add(OTH, T, "Yamini Mourya won silver in which event?",
    "Women’s −57 kg judo", "Women’s −48 kg judo", "Women’s −63 kg judo", "Women’s 57 kg boxing",
    "Yamini Mourya (Madhya Pradesh) won silver in the women’s −57 kg judo.")
add(OTH, T, "Who won India’s first medal of CWG 2026?",
    "Jhandu Kumar, bronze in men’s heavyweight para powerlifting",
    "Mirabai Chanu, gold in weightlifting",
    "Chanambam Rishikanta Singh, silver in weightlifting",
    "Neeraj Chopra, silver in javelin",
    "Jhandu Kumar (Bihar) won India’s first medal, a maiden bronze in para powerlifting.")
add(OTH, T, "Tejaswin Shankar’s decathlon bronze was historic because:",
    "He was the first Indian ever to win a CWG medal in the decathlon",
    "He was the first Indian decathlon gold medallist",
    "It was his first CWG medal of any kind",
    "He also won the high jump gold",
    "It was the first Indian CWG medal in the decathlon, and his second CWG bronze after high-jump bronze in 2022. He is from Delhi.")
add(OTH, T, "Which two athletes won maiden CWG medals with bronze in javelin and triple jump respectively?",
    "Yash Vir Singh (Rajasthan) and Selva Prabhu Thirumaran (Tamil Nadu)",
    "Neeraj Chopra and Praveen Chithravel",
    "Yash Vir Singh and Murali Sreeshankar",
    "Tejaswin Shankar and Gulveer Singh",
    "Yash Vir Singh took a maiden javelin bronze and Selva Prabhu Thirumaran a maiden triple-jump bronze.")
add(OTH, T, "Unnati Sharma’s maiden CWG medal was in which event?",
    "Women’s −63 kg judo", "Women’s −57 kg judo", "Women’s −48 kg judo", "Women’s 60 kg boxing",
    "Unnati Sharma (Uttarakhand) won a maiden medal in the women’s −63 kg judo.")
add(OTH, T, "The record for the most Commonwealth Games medals is held by whom, and at what number?",
    "Chad le Clos of South Africa, with 21 medals",
    "Ian Thorpe of Australia, with 21 medals",
    "Chad le Clos, with 18 medals",
    "Michael Phelps, with 21 Commonwealth medals",
    "South African swimmer Chad le Clos reached 21 medals, with bronze in the men’s 4×100 m medley relay.")
add(OTH, T, "The 2030 Commonwealth Games will be hosted by which city?",
    "Ahmedabad (Amdavad), Gujarat", "Delhi", "Mumbai", "Gandhinagar",
    "Ahmedabad will host the 2030 Games.")
add(OTH, T, "Why is the 2030 edition called the Centenary Commonwealth Games?",
    "It marks 100 years since the inaugural Games in Hamilton, Canada, in 1930",
    "It marks 100 years of India’s membership",
    "It is the 100th edition of the Games",
    "It marks 100 years since the inaugural Games in London in 1930",
    "The inaugural Games were in Hamilton, Canada, in 1930.")
add(OTH, T, "Who received the CWG flag and baton on behalf of India for 2030?",
    "Neeraj Chopra and Indian Olympic Association President P. T. Usha",
    "Mirabai Chanu and P. T. Usha",
    "Neeraj Chopra and Abhinav Bindra",
    "P. T. Usha and Lovlina Borgohain",
    "They were received by Neeraj Chopra and IOA President P. T. Usha.")
add(OTH, T, "2030 will be which time India hosts the Commonwealth Games?",
    "The second time, after Delhi 2010",
    "The first time",
    "The third time, after Delhi 2010 and a bid win in 2022",
    "The second time, after Melbourne was co-hosted",
    "India will host for the second time, after Delhi 2010.")
add(OTH, T, "India made its Commonwealth Games debut in which year?",
    "1934", "1930", "1950", "1948",
    "India debuted in 1934.")
add(OTH, T, "Pistol shooter Jaspal Rana’s all-time CWG medal count is:",
    "15 medals — nine gold, four silver and two bronze",
    "15 medals — nine gold, two silver and four bronze",
    "12 medals — eight gold and four silver",
    "21 medals, the all-time record",
    "Jaspal Rana has 15 medals: nine gold, four silver and two bronze.")
add(OTH, T, "India’s best-ever CWG performance, at New Delhi 2010, produced how many medals?",
    "101 medals — 38 gold, 26 silver and 36 bronze — second on the table",
    "101 medals — 38 gold, 27 silver and 36 bronze — first on the table",
    "61 medals including 22 gold",
    "99 medals, the only time India crossed 90",
    "Delhi 2010 yielded 101 medals (38-26-36), second place, and is the only time India crossed 100 medals.")
add(OTH, T, "At Birmingham 2022, India finished in which place, with how many medals?",
    "Fourth, with 61 medals including 22 gold",
    "Third, with 61 medals including 22 gold",
    "Fourth, with 39 medals",
    "Second, with 101 medals",
    "India finished fourth at Birmingham 2022 with 61 medals including 22 gold.")
add(OTH, T, "The Commonwealth Games are also known as, and how many nations and territories took part most recently in Glasgow?",
    "The Friendly Games; 74 nations and territories",
    "The Family Games; 72 nations",
    "The Friendly Games; 56 nations",
    "The Empire Games; 74 nations",
    "They are known as the Friendly Games. 74 nations and territories participated in Glasgow.")
add(OTH, T, "India assumed the Chair of which Commonwealth sports body, and for which cycle?",
    "Commonwealth Advisory Body on Sport (CABOS), for 2026–2030",
    "Commonwealth Games Federation, for 2026–2030",
    "CABOS, for 2022–2026",
    "World Anti-Doping Agency, for 2026–2030",
    "India assumed the Chair of CABOS for the 2026–2030 cycle.")

# ---------- other firsts ----------
T = "Alluri Sitarama Raju Airport"
add(OTH, T, "Andhra Pradesh’s first greenfield international airport since the 2014 bifurcation is named:",
    "Alluri Sitarama Raju International Airport",
    "Bhogapuram International Airport, without a personal name",
    "Visakhapatnam International Airport",
    "Alluri Sitarama Raju Airport at Vijayawada",
    "The airport is the Alluri Sitarama Raju International Airport.")
add(OTH, T, "Alluri Sitarama Raju International Airport is located in which district?",
    "Bhogapuram, Vizianagaram district",
    "Bhogapuram, Visakhapatnam district",
    "Gannavaram, Krishna district",
    "Renigunta, Tirupati district",
    "It is in Bhogapuram, Vizianagaram district, Andhra Pradesh.")
add(OTH, T, "Who built the Bhogapuram airport, and under what arrangement?",
    "GMR Visakhapatnam International Airport Limited, under a public-private partnership",
    "AAI, as a fully government airport",
    "GMR Hyderabad International Airport Limited",
    "Adani Airports, under PPP",
    "It was built by GMR Visakhapatnam International Airport Limited under a PPP.")
add(OTH, T, "A Guinness World Records title at the new airport was for:",
    "The largest Dhimsa dance, with more than 13,000 tribal women and student participants",
    "The largest Kuchipudi ensemble",
    "The longest airport runway inauguration parade",
    "The largest Bathukamma gathering",
    "More than 13,000 tribal women and students set a Guinness title for the largest Dhimsa dance.")
add(OTH, T, "Dhimsa is described as:",
    "A traditional group folk dance of tribal communities of Andhra Pradesh’s Eastern Ghats",
    "A martial dance of the Kodavas",
    "A classical dance of Tamil Nadu",
    "A harvest dance of the Godavari delta only",
    "Dhimsa is a traditional group folk dance associated with tribal communities of the Eastern Ghats region of Andhra Pradesh.")

T = "Cheetah book"
add(OTH, T, "Who authored “Bringing the Cheetah Back to India: How Diplomacy Made Conservation’s Big Mission Possible”?",
    "Prashant Agrawal", "M. K. Ranjitsinh", "Bhupender Yadav", "Prashant Kishor",
    "The book is by veteran diplomat Prashant Agrawal.")
add(OTH, T, "Project Cheetah is described as:",
    "The world’s first intercontinental translocation of a large wild carnivore",
    "The world’s first reintroduction of a big cat from captivity",
    "India’s first tiger translocation between states",
    "A Namibia-only breeding programme",
    "It was the world’s first intercontinental translocation of a large wild carnivore.")
add(OTH, T, "The first eight cheetahs under Project Cheetah came from where, and were released where, and when?",
    "From Namibia, into Kuno National Park, Madhya Pradesh, in 2022",
    "From South Africa, into Kuno, in 2023",
    "From Namibia, into Nauradehi, in 2022",
    "From Botswana, into Kuno, in 2022",
    "Eight cheetahs from Namibia were released in Kuno National Park in 2022.")
add(OTH, T, "Namibia is referred to in the book’s context as:",
    "The “cheetah capital of the world”",
    "The “lion capital of the world”",
    "The only African source of India’s cheetahs",
    "A country that refused further translocations",
    "Namibia was selected as a source country as it is regarded as the cheetah capital of the world. India also received cheetahs from South Africa and Botswana, but the book focuses on Namibia-to-India.")

T = "Tanzania cricket"
add(OTH, T, "Tanzania’s first ICC-approved cricket arena was inaugurated at:",
    "University of Dar es Salaam", "University of Dodoma", "National Stadium, Dar es Salaam", "Arusha Cricket Club",
    "It was inaugurated at the University of Dar es Salaam.")

T = "ANUGYAN"
add(OTH, T, "ANUGYAN expands to:",
    "Nuclear Technology Orientation Programme",
    "Atomic and Nuclear Upgrade for Young Graduates in Advanced Nucleonics",
    "National Uranium Generation and Yielding Network",
    "Advanced Nuclear Undergraduate Yearly Programme",
    "ANUGYAN is the Nuclear Technology Orientation Programme (NTOP).")
add(OTH, T, "ANUGYAN was jointly developed by which pair?",
    "IIT Hyderabad and Pune-based Crimson Energy Experts Pvt. Ltd.",
    "IIT Bombay and NPCIL",
    "IIT Madras and BARC",
    "IIT Hyderabad and SIDBI",
    "It was developed by IIT Hyderabad and Crimson Energy Experts Pvt. Ltd. (CEEPL), Pune.")
add(OTH, T, "ANUGYAN is India’s first industry-academia partnership specifically designed to:",
    "Train deployment-ready engineering talent for the civil nuclear energy sector",
    "Fund space-tech start-ups",
    "Build Small Modular Reactors at Tarapur",
    "Train fighter combat leaders",
    "It trains deployment-ready engineering talent for civil nuclear energy.")

T = "COSPAR medal"
add(OTH, T, "The COSPAR Vikram Sarabhai Medal for 2026 was awarded to:",
    "Prof. Annapurni Subramaniam, Director of IIA Bengaluru",
    "Anil Bhardwaj",
    "S. Somanath",
    "Gurbax Singh Lakhina",
    "It was awarded to Prof. Annapurni Subramaniam, Director of the Indian Institute of Astrophysics.")
add(OTH, T, "Annapurni Subramaniam is which Indian winner of the COSPAR Vikram Sarabhai Medal?",
    "The first Indian woman and the fourth Indian winner",
    "The first Indian winner",
    "The third Indian winner",
    "The first woman Director to win it in 2014",
    "She is the first Indian woman and the fourth Indian, after U. R. Rao (1996), Gurbax Singh Lakhina (2014) and Anil Bhardwaj (2024).")
add(OTH, T, "The medal was awarded during which meeting?",
    "The 46th COSPAR Scientific Assembly in Florence, Italy",
    "The 45th COSPAR Assembly in Paris",
    "The 46th Assembly in Bengaluru",
    "The International Astronautical Congress in Milan",
    "It was awarded during the 46th COSPAR Scientific Assembly in Florence.")
add(OTH, T, "The COSPAR Vikram Sarabhai Medal is awarded jointly by whom, and how often?",
    "ISRO and COSPAR, every two years",
    "ISRO and UNESCO, every year",
    "COSPAR alone, every four years",
    "IIA and COSPAR, every two years",
    "It is awarded jointly by ISRO and COSPAR every two years, since 1990, for space research in developing countries.")
add(OTH, T, "Annapurni Subramaniam became the first woman Director of IIA in which year?",
    "2019", "2014", "2024", "1996",
    "She became the first woman Director of IIA in 2019.")
add(OTH, T, "COSPAR was established in which year, by whom, and is headquartered where?",
    "1958, by the International Council for Scientific Unions, in Paris",
    "1962, by the UN, in Vienna",
    "1958, by ISRO, in Bengaluru",
    "1990, by ICSU, in Geneva",
    "COSPAR was established in 1958 by ICSU and is headquartered in Paris. The medal honours Vikram Sarabhai, regarded as the father of the Indian space programme.")
add(OTH, T, "The 2026 medal recognised Annapurni Subramaniam’s work including which reserve?",
    "Hanle Dark Sky Reserve", "Night Sky Reserve of Spiti", "Nilgiri Biosphere Reserve", "Kavalur observatory only",
    "Her work cited includes stellar populations, blue straggler stars, UVIT/AstroSat, future telescopes and the Hanle Dark Sky Reserve.")

T = "Rail-tech park"
add(OTH, T, "India’s first rail-tech manufacturing park is to be set up where?",
    "Sahaspur industrial estate, Khordha district, Odisha",
    "Kalinganagar, Odisha",
    "Dankuni, West Bengal",
    "Kapurthala, Punjab",
    "It is to be set up at the Sahaspur industrial estate in Khordha, Odisha.")

T = "Saint Louis chess"
add(OTH, T, "Who won the 2026 Saint Louis Rapid & Blitz?",
    "R Praggnanandhaa", "D Gukesh", "Arjun Erigaisi", "Javokhir Sindarov",
    "Indian GM R Praggnanandhaa won the title for the first time.")
add(OTH, T, "Praggnanandhaa’s score in the rapid section, and his winner’s prize, were:",
    "12/18 points and US$50,000", "12/18 points and US$75,000", "14/18 points and US$50,000", "11/18 points and US$40,000",
    "He topped the rapid section with 12/18 and received US$50,000.")
add(OTH, T, "Who finished runner-up at the 2026 Saint Louis Rapid & Blitz?",
    "Javokhir Sindarov of Uzbekistan", "Nodirbek Abdusattorov of Uzbekistan", "Alireza Firouzja", "Wei Yi",
    "Javokhir Sindarov of Uzbekistan was runner-up.")
add(OTH, T, "The Saint Louis event was part of which tour, and what was special about it?",
    "The 2026 Grand Chess Tour, and its first U.S. leg",
    "The Candidates cycle, and its first U.S. leg",
    "The Grand Chess Tour, and its second U.S. leg",
    "The World Rapid Championship in Missouri",
    "It was part of the 2026 Grand Chess Tour and was its first U.S. leg, at the Saint Louis Chess Club, Missouri.")

T = "Additive manufacturing"
add(OTH, T, "India’s first commercial large-format additive manufacturing facility for composite tooling will be set up by whom, and where?",
    "Lohia Aerospace Systems with Israel-based Massivit, at Kanpur",
    "HAL with Stratasys, at Bengaluru",
    "Lohia Aerospace with Massivit, at Hyderabad",
    "Tata Advanced Systems with Massivit, at Kanpur",
    "Lohia Aerospace Systems will set it up with Massivit at its plant in Kanpur, Uttar Pradesh.")

T = "Bhawana Kanth"
add(OTH, T, "Who is the first woman IAF pilot to qualify as a Fighter Combat Leader?",
    "Squadron Leader Bhawana Kanth", "Squadron Leader Avani Chaturvedi", "Squadron Leader Mohana Singh", "Wing Commander Shaliza Dhami",
    "Squadron Leader Bhawana Kanth qualified as an FCL.")
add(OTH, T, "Bhawana Kanth completed the Fighter Combat Leader course at which establishment?",
    "TACDE, Gwalior", "ASTE, Bengaluru", "TACDE, Bidar", "Air Force Academy, Dundigal",
    "She completed it at the Tactics and Air Combat Development Establishment, Gwalior.")
add(OTH, T, "Bhawana Kanth was commissioned in June 2016 alongside which two women, as the first three women fighter pilots?",
    "Avani Chaturvedi and Mohana Singh", "Avani Chaturvedi and Shivangi Singh", "Mohana Singh and Shivangi Singh", "Avani Chaturvedi and Bhawna Kanth is the same person as a distractor",
    "The first three, commissioned in June 2016, were Bhawana Kanth, Avani Chaturvedi and Mohana Singh.")
add(OTH, T, "In 2019, Bhawana Kanth became the first Indian woman fighter pilot qualified to:",
    "Undertake combat missions by day",
    "Fly a Rafale",
    "Lead a night combat mission",
    "Command a fighter squadron",
    "In 2019 she became the first Indian woman fighter pilot qualified to undertake combat missions by day.")
add(OTH, T, "In 2021, Bhawana Kanth became the first woman fighter pilot to:",
    "Participate in India’s Republic Day Parade",
    "Qualify as a Fighter Combat Leader",
    "Fly at the Bahrain air show",
    "Land on an aircraft carrier",
    "She was the first woman fighter pilot in the Republic Day Parade in 2021. The FCL qualification is the separate, later first covered in this news item.")

T = "High-altitude wildlife safari"
add(OTH, T, "India’s first high-altitude wildlife safari is to be launched in:",
    "Ladakh", "Spiti, Himachal Pradesh", "Sikkim", "Uttarakhand",
    "It is to be launched in Ladakh.")
add(OTH, T, "Potential safari routes will be explored across which three protected areas?",
    "Hemis National Park, Changthang Wildlife Sanctuary and Karakoram Wildlife Sanctuary",
    "Hemis, Pin Valley and Kibber",
    "Changthang, Karakoram and Great Himalayan National Park",
    "Hemis, Dachigam and Changthang",
    "The three areas are Hemis National Park, Changthang Wildlife Sanctuary and Karakoram Wildlife Sanctuary.")

# ---------- other MOUs, banking, S&T, defence, env ----------
T = "NSDC & AVPL"
add(OTH, T, "NSDC and AVPL International will establish how many Advanced Skill Centres for drones, over what period?",
    "350 centres over three years", "250 centres over five years", "350 centres over five years", "75 centres over three years",
    "The objective is 350 ASCs over the next three years.")
add(OTH, T, "How many drone Advanced Skill Centres are targeted in the first year of the NSDC–AVPL plan?",
    "75", "100", "50", "350",
    "75 centres are targeted for the first year.")
add(OTH, T, "The drone skill centres will be located in, and will support which policy?",
    "Universities and engineering colleges, supporting NEP 2020",
    "ITI campuses only, supporting the Skill India Mission of 2015",
    "Air force stations, supporting NEP 2020",
    "Industrial corridors, supporting NICDP",
    "They will be in universities and engineering colleges and support the National Education Policy 2020, with training in piloting, manufacturing, agriculture and analytics.")

T = "Tripura & NSE"
add(OTH, T, "How many MoUs did the Tripura government sign with the National Stock Exchange?",
    "Three", "Two", "One", "Four",
    "Three MoUs were signed.")
add(OTH, T, "The Tripura–NSE MoUs are aimed at:",
    "Financial literacy, MSME funding and the state’s investment ecosystem",
    "A regional stock exchange in Agartala",
    "Only sovereign AI adoption",
    "Drone training centres",
    "They strengthen financial literacy, scale MSME funding and foster investment across the state.")

T = "IBM and Sarvam"
add(OTH, T, "The IBM–Sarvam partnership aims to advance what in India?",
    "Sovereign AI technologies", "Quantum-only cloud regions", "A payments switch", "Cross-border UPI",
    "The objective is sovereign AI for governments, public sector organisations and regulated enterprises.")
add(OTH, T, "The IBM–Sarvam stack combines which two offerings?",
    "IBM Sovereign Core and Sarvam’s Sovereign AI stack",
    "IBM watsonx and Sarvam-1 only as a chatbot",
    "Azure OpenAI and Sarvam",
    "IBM Cloud and Bhashini",
    "It combines IBM Sovereign Core with Sarvam’s Sovereign AI stack to operationalise full-stack sovereign AI.")

T = "HDFC savings variants"
add(OTH, T, "HDFC Bank’s ‘Max for Seniors’ and ‘Max for Her’ were launched under which portfolio?",
    "Savings Max", "Millennia Savings", "Premium Select", "Parivartan",
    "They are two new savings-account variants under the Savings Max portfolio.")
add(OTH, T, "‘Max for Seniors’ and ‘Max for Her’ are targeted respectively at:",
    "Senior citizens and women customers",
    "NRIs and women",
    "Senior citizens and students",
    "Women and start-up founders",
    "Max for Seniors is for senior citizens; Max for Her is for women.")

T = "StanChart GIFT City"
add(OTH, T, "Standard Chartered received in-principle approval to offer what from GIFT City?",
    "Wealth management products", "Retail home loans only", "A digital-only payments bank", "Insurance broking",
    "It received in-principle approval to offer wealth management products from GIFT City, Gujarat.")
add(OTH, T, "GIFT City expands to, and hosts what Indian first?",
    "Gujarat International Finance Tec-City, India’s first International Financial Services Centre",
    "Gujarat International Free Trade City, India’s first SEZ",
    "Gandhinagar International Finance and Trade City, India’s second IFSC",
    "Gujarat Integrated Financial Technology City, a domestic banking hub",
    "GIFT City is Gujarat International Finance Tec-City and hosts India’s first IFSC.")
add(OTH, T, "Standard Chartered became the first foreign bank to commence operations in GIFT City in which year?",
    "2020", "2019", "2022", "2015",
    "It was the first foreign bank to commence operations in GIFT City in 2020.")

T = "Microsoft data centre"
add(OTH, T, "Microsoft’s largest data-centre hub in India was launched in which city?",
    "Hyderabad, Telangana", "Pune", "Chennai", "Visakhapatnam",
    "It was launched at Hyderabad and is part of the India South Central cloud region.")
add(OTH, T, "After the Hyderabad hub, how many cloud regions does Microsoft operate in India, and which were the earlier ones?",
    "Four: the new hub plus Pune, Chennai and Mumbai",
    "Three: Pune, Chennai and Mumbai, with Hyderabad replacing Pune",
    "Four: Hyderabad, Bengaluru, Pune and Delhi",
    "Five: Hyderabad, Pune, Chennai, Mumbai and Noida",
    "Microsoft now operates four Indian cloud regions: Hyderabad, Pune, Chennai and Mumbai.")

T = "Qwen3.8-Max"
add(OTH, T, "Qwen3.8-Max was launched by which company, with how many parameters?",
    "Alibaba, with 2.4 trillion parameters",
    "Moonshot AI, with 2.4 trillion",
    "Alibaba, with 2.8 trillion",
    "DeepSeek, with 2.4 trillion",
    "Alibaba’s Qwen3.8-Max has 2.4 trillion parameters.")
add(OTH, T, "Qwen3.8-Max is described as close in size to which model?",
    "Moonshot AI’s Kimi K3, around 2.8 trillion parameters",
    "OpenAI’s GPT-4, around 1.8 trillion",
    "Kimi K2, around 1 trillion",
    "Google Gemini Ultra, around 2.4 trillion",
    "Its size is close to Moonshot AI’s Kimi K3, which has around 2.8 trillion parameters.")

T = "Exercise ROTOR CLAP III"
add(OTH, T, "Exercise ROTOR CLAP III was conducted by whom, and where?",
    "The Indian Air Force at Pokhran Field Firing Range, Jaisalmer, Rajasthan",
    "The Indian Army at Pokhran",
    "The IAF at Mahajan Field Firing Range",
    "The Indian Navy at Pokhran",
    "IAF conducted it at Pokhran Field Firing Range in Jaisalmer district.")
add(OTH, T, "The theme of Exercise ROTOR CLAP III was:",
    "Counter-UAS (Counter-Unmanned Aerial Systems)",
    "High-altitude helicopter ops",
    "Maritime interdiction",
    "Night troop insertion",
    "The theme was “Counter-UAS”.")

T = "Maritime defence coalition"
add(OTH, T, "The Multinational Maritime Defence Coalition was announced by Saudi Arabia and how many other countries?",
    "13 other countries, making 14 founding members",
    "12 other countries",
    "15 other countries",
    "13 countries including India",
    "Saudi Arabia and 13 other countries — 14 founding members. India is not in the list.")
add(OTH, T, "The coalition’s priority maritime areas are:",
    "Bab el-Mandeb Strait, Red Sea and Gulf of Aden",
    "Strait of Hormuz, Persian Gulf and Arabian Sea",
    "Malacca, Sunda and Lombok",
    "Bab el-Mandeb, Gulf of Oman and Mediterranean",
    "Priority areas are the Bab el-Mandeb Strait, the Red Sea and the Gulf of Aden.")
add(OTH, T, "Where will the coalition’s permanent headquarters be?",
    "Riyadh, Saudi Arabia", "Manama, Bahrain", "Cairo, Egypt", "Djibouti city",
    "Saudi Arabia is the founding and leading state and will host the permanent headquarters in Riyadh.")
add(OTH, T, "Which of these is among the 14 founding members of the maritime coalition?",
    "Pakistan, Bangladesh and Somalia",
    "India, Pakistan and Egypt",
    "UAE, Oman and Iraq",
    "Indonesia, Malaysia and Djibouti",
    "The 14 are Saudi Arabia, Kuwait, Bahrain, Qatar, Pakistan, Türkiye, Egypt, Jordan, Yemen, Bangladesh, Nigeria, Sudan, Djibouti and Somalia. India, the UAE and Oman are not in that list.")

T = "Himalayan serow"
add(OTH, T, "The Himalayan serow was camera-recorded after about two decades in which forests?",
    "Dalhousie catchment forests of Himachal Pradesh",
    "Great Himalayan National Park",
    "Kedarnath Wildlife Sanctuary",
    "Dachigam National Park",
    "It was recorded in the Dalhousie catchment forests of Himachal Pradesh.")
add(OTH, T, "The serow sighting was in forests adjoining which sanctuary, in which district?",
    "Kalatop-Khajjiar Wildlife Sanctuary, Chamba",
    "Kalatop-Khajjiar, Kangra",
    "Khirganga, Kullu",
    "Churdhar, Sirmaur",
    "The forests adjoin Kalatop-Khajjiar Wildlife Sanctuary in Chamba district.")
add(OTH, T, "The serow is the state animal of which state, and under which schedule is the Himalayan serow protected?",
    "Mizoram; Schedule I of the Wildlife (Protection) Act, 1972",
    "Himachal Pradesh; Schedule I",
    "Mizoram; Schedule II",
    "Nagaland; Schedule I",
    "The serow is the state animal of Mizoram and the Himalayan serow is in Schedule I.")

# ---------- SPORTS ----------
T = "Commonwealth Table Tennis 2026"
add(OTH, T, "The 22nd Commonwealth Table Tennis Championships were held at:",
    "Thyagraj Stadium, New Delhi", "Indira Gandhi Stadium", "Jawaharlal Nehru Stadium, Cuttack", "Talkatora Stadium",
    "The venue was Thyagraj Stadium in New Delhi.")
add(OTH, T, "The official mascot of the 2026 Commonwealth Table Tennis Championships was:",
    "Mayur", "Finnie", "Shera", "Appu",
    "The mascot was Mayur.")
add(OTH, T, "How many of the seven gold medals did India win, and who stopped a clean sweep?",
    "Six; Malaysia won the men’s doubles",
    "Seven; nobody stopped the sweep",
    "Five; England won two titles",
    "Six; Malaysia won the women’s doubles",
    "India won six of seven. Malaysia won the men’s doubles.")
add(OTH, T, "These championships were held parallel to Glasgow 2026 because:",
    "Table tennis was not in the Glasgow sports programme",
    "They were a demonstration sport inside Glasgow",
    "The venue was shifted from Glasgow to Delhi mid-way",
    "India boycotted the Glasgow table tennis event",
    "Table tennis was not included in the Glasgow 2026 sports programme.")
add(OTH, T, "The championships returned in 2026 after the previous edition in:",
    "Cuttack in 2019", "Delhi in 2019", "Gold Coast in 2018", "Birmingham in 2022",
    "The previous edition was in Cuttack in 2019.")
add(OTH, T, "At the 2019 Commonwealth Table Tennis Championships, India:",
    "Became only the third country to sweep all seven gold medals",
    "Won six of seven golds",
    "Was the first country ever to sweep all seven",
    "Won only the team titles",
    "In 2019 India became only the third country in history to sweep all seven golds.")
add(OTH, T, "Best players of the 2026 table tennis championships were:",
    "Manush Shah (male) and Syndrela Das (female)",
    "Manav Thakkar and Sreeja Akula",
    "Sathiyan Gnanasekaran and Manika Batra",
    "Ankur Bhattacharjee and Yashaswini Ghorpade",
    "Best male was Manush Shah; best female was Syndrela Das.")
add(OTH, T, "Who won the men’s singles, and who was runner-up?",
    "Ankur Bhattacharjee beat Payas Jain, both of India",
    "Manush Shah beat Manav Thakkar",
    "Payas Jain beat Ankur Bhattacharjee",
    "Sathiyan beat Harmeet Desai",
    "Ankur Bhattacharjee (India) beat Payas Jain (India) in the men’s singles.")
add(OTH, T, "Who won the women’s singles, and who was runner-up?",
    "Yashaswini Ghorpade beat Sreeja Akula",
    "Sreeja Akula beat Yashaswini Ghorpade",
    "Syndrela Das beat Sreeja Akula",
    "Manika Batra beat Syndrela Das",
    "Yashaswini Ghorpade beat Sreeja Akula in the women’s singles.")
add(OTH, T, "The men’s doubles title went to:",
    "Wong Qi Shen and Choong Javen of Malaysia, over Manav Thakkar and Manush Shah",
    "Manav Thakkar and Manush Shah, over a Malaysian pair",
    "Sathiyan and Harmeet Desai",
    "Ankur Bhattacharjee and Payas Jain",
    "Malaysia’s Wong Qi Shen and Choong Javen beat India’s Thakkar and Shah.")
add(OTH, T, "Women’s doubles winners were:",
    "Sreeja Akula and Syndrela Das",
    "Yashaswini Ghorpade and Divyanshi Bhowmick",
    "Sreeja Akula and Manika Batra",
    "Syndrela Das and Sutirtha Mukherjee",
    "Sreeja Akula and Syndrela Das beat Yashaswini Ghorpade and Divyanshi Bhowmick.")
add(OTH, T, "Mixed doubles was won by which Indian pair?",
    "Manav Thakkar and Taneesha Kotecha",
    "Manush Shah and Syndrela Das",
    "Sathiyan Gnanasekaran and Sreeja Akula",
    "Ankur Bhattacharjee and Yashaswini Ghorpade",
    "Manav Thakkar and Taneesha Kotecha won mixed doubles, over Richard Yap Rui Zhe and Tee Ai Xin of Malaysia.")
add(OTH, T, "India’s men’s team at the championships included which of these groups?",
    "Manav Thakkar, Manush Shah, Sathiyan Gnanasekaran, Harmeet Desai and Payas Jain",
    "Manav Thakkar, Sharath Kamal, Sathiyan, Harmeet and G. Sathiyan’s junior",
    "Only Manush Shah and Ankur Bhattacharjee",
    "Manav Thakkar, Manush Shah and a Malaysian invitee",
    "The men’s team was Thakkar, Shah, Sathiyan, Harmeet Desai and Payas Jain. They beat Malaysia.")

T = "Lanka Premier League"
add(OTH, T, "Zaheer Khan became co-owner of which LPL franchise?",
    "Jaffna Kings, later rebranded Anchor Jaffna Kings",
    "Colombo Strikers",
    "Galle Titans",
    "Dambulla Aura",
    "He became co-owner of Jaffna Kings.")
add(OTH, T, "Which group acquired the Jaffna Kings, and where is it based?",
    "Anchor Sports AB, Stockholm", "Anchor Sports, Dubai", "Reliance Sports, Mumbai", "Nagendra Sports, Colombo",
    "Anchor Sports AB, a Stockholm-based group, acquired the franchise.")
add(OTH, T, "Zaheer Khan joined which person as co-owner?",
    "Nagendra Siddoutam, owner of Anchor Sports",
    "Pieter Elbers",
    "Mahela Jayawardene",
    "Willie Walsh",
    "He joined Nagendra Siddoutam, owner of Anchor Sports. The franchise was rebranded Anchor Jaffna Kings.")

print("after B", len(qs))
Path("/tmp/qs_part_b.json").write_text(json.dumps(qs, ensure_ascii=False))
