export type RawQ = {
  s: string;
  t: string;
  q: string;
  a: string;
  d: [string, string, string];
  w: string;
};

export type Question = {
  id: number;
  section: string;
  topic: string;
  prompt: string;
  options: string[];
  answer: number;
  why: string;
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function buildQuestions(raw: RawQ[]): Question[] {
  return raw.map((item, index) => {
    const options = [item.a, item.d[0], item.d[1], item.d[2]];
    const uniq = new Set(options);
    if (uniq.size !== 4) {
      throw new Error(`Duplicate options in Q seed ${index + 1}: ${item.q}`);
    }
    const rand = mulberry32(hash(item.q) ^ Math.imul(index + 1, 997));
    for (let j = options.length - 1; j > 0; j--) {
      const k = Math.floor(rand() * (j + 1));
      const swap = options[j];
      options[j] = options[k]!;
      options[k] = swap!;
    }
    return {
      id: index + 1,
      section: item.s,
      topic: item.t,
      prompt: item.q,
      options,
      answer: options.indexOf(item.a),
      why: item.w,
    };
  });
}
