import raw from "./questions.json";
import { buildQuestions, type Question, type RawQ } from "./build";

export type { Question };

export const QUESTIONS: Question[] = buildQuestions(raw as RawQ[]);

export const SECTIONS = [...new Set(QUESTIONS.map((q) => q.section))];

export function sectionCounts() {
  const counts = new Map<string, number>();
  for (const q of QUESTIONS) counts.set(q.section, (counts.get(q.section) ?? 0) + 1);
  return SECTIONS.map((section) => ({ section, count: counts.get(section) ?? 0 }));
}
