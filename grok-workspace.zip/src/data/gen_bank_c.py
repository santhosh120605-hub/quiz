#!/usr/bin/env python3
import json
from pathlib import Path

qs = json.loads(Path("/tmp/qs_part_b.json").read_text())

def add(s, t, q, a, d1, d2, d3, w):
    qs.append({"s": s, "t": t, "q": q, "a": a, "d": [d1, d2, d3], "w": w})

OTH = "GA · Other"
PIB = "GA · PIB"
ESI = "GA + ESI"
FIN = "GA + Finance"

# fix a leaked distractor if present
for item in qs:
    item["d"] = [
        "Avani Chaturvedi and Tanya Sharma" if x.startswith("Avani Chaturvedi and Bhawna") else x
        for x in item["d"]
    ]

T = "Appointments"
add(OTH, T, "Who assumed charge as CEO of IndiGo, and whom did he succeed?",
    "Willie Walsh, succeeding Pieter Elbers",
    "Pieter Elbers, succeeding Willie Walsh",
    "Tewolde Gebremariam, succeeding Pieter Elbers",
    "Campbell Wilson, succeeding Willie Walsh",
    "Willie Walsh became CEO of IndiGo and succeeded Pieter Elbers.")
add(OTH, T, "IndiGo was named “Best Airline in India and South Asia” at which awards, and for which year?",
    "Skytrax World Airline Awards 2025",
    "Skytrax World Airline Awards 2026",
    "ATRA awards 2025",
    "DGCA safety awards 2025",
    "The additional note is the Skytrax World Airline Awards 2025.")
add(OTH, T, "Who was appointed CEO and MD of Air India, and whom does he succeed?",
    "Tewolde Gebremariam, succeeding Campbell Wilson",
    "Campbell Wilson, succeeding Tewolde Gebremariam",
    "Willie Walsh, succeeding Campbell Wilson",
    "Pieter Elbers, succeeding Campbell Wilson",
    "Tewolde Gebremariam, former Group CEO of Ethiopian Airlines, succeeds Campbell Wilson.")
add(OTH, T, "Tewolde Gebremariam was previously:",
    "Group CEO of Ethiopian Airlines",
    "CEO of Kenya Airways",
    "CEO of IndiGo",
    "Chairman of IATA",
    "He is the former Group CEO of Ethiopian Airlines.")
add(OTH, T, "Who assumed charge as Acting Central Vigilance Commissioner, and whom did he succeed?",
    "A. S. Rajeev, succeeding Praveen Kumar Srivastava",
    "Praveen Kumar Srivastava, succeeding A. S. Rajeev",
    "Prasanta Mahapatra, succeeding Praveen Kumar Srivastava",
    "A. S. Rajeev, succeeding K. V. Chowdary",
    "A. S. Rajeev became Acting CVC in succession to Praveen Kumar Srivastava.")
add(OTH, T, "The Central Vigilance Commission is described as:",
    "India’s apex statutory vigilance body for Central Government organisations",
    "A constitutional body chaired by the Prime Minister",
    "The investigative wing of the CBI",
    "A regulator of stock exchanges",
    "CVC is India’s apex statutory vigilance body, overseeing vigilance administration in Central Government organisations.")
add(OTH, T, "Prasanta Mahapatra assumed charge as Executive Director of which regulator?",
    "SEBI", "RBI", "IRDAI", "PFRDA",
    "He became Executive Director of the Securities and Exchange Board of India.")
add(OTH, T, "As ED of SEBI, Prasanta Mahapatra will oversee which departments?",
    "Corporation Finance Investigation, and Recovery and Refund",
    "Foreign Exchange, and Financial Markets Regulation",
    "Commodity Derivatives and Investment Management only",
    "Only the Legal Affairs department",
    "He will oversee Corporation Finance Investigation and the Recovery and Refund Department.")
add(OTH, T, "The RBI appointed Monisha Chakraborty as Executive Director in charge of which departments?",
    "Foreign Exchange Department and Financial Markets Regulation Department",
    "Department of Supervision and Department of Currency Management",
    "Corporation Finance and Recovery",
    "Consumer Education and Payment Systems only",
    "She will oversee Foreign Exchange and Financial Markets Regulation.")

T = "Persons in news · other"
add(OTH, T, "Nathan Thomas was recognised by Guinness World Records as:",
    "The world’s youngest male professor",
    "The world’s youngest professor of either gender",
    "The youngest graduate of Miami Dade College",
    "The youngest Nobel nominee",
    "He was recognised as the world’s youngest male professor.")
add(OTH, T, "Nathan Thomas achieved the record at what age, on joining which college?",
    "18 years and 346 days, at Miami Dade College, Florida",
    "18 years and 362 days, at Miami Dade College",
    "19 years, at the University of Edinburgh",
    "18 years and 346 days, at Harvard",
    "He was 18 years and 346 days old when he joined Miami Dade College in Florida.")
add(OTH, T, "Whose record did Nathan Thomas break, and whose female record is he younger than?",
    "He broke Colin Maclaurin’s male record (professor at 19) and is 16 days younger than Alia Sabur",
    "He broke Alia Sabur’s record and is younger than Colin Maclaurin",
    "He broke a record set at age 17 by Colin Maclaurin",
    "He tied Alia Sabur’s age of 18 years and 362 days",
    "Colin Maclaurin became a professor at 19. Alia Sabur, the youngest female professor, was 18 years and 362 days; Nathan was 16 days younger.")
add(OTH, T, "Neeraj Chopra became co-owner of which grassroots programme, after serving as its ambassador?",
    "UBS Athletics Kids Cup, ambassador for two seasons",
    "Diamond League Kids, ambassador for one season",
    "Khelo India Athletics Cup",
    "UBS Olympics Kids Cup",
    "He became co-owner of the UBS Athletics Kids Cup after two seasons as ambassador. It introduces children to athletics through inclusive competitions.")
add(OTH, T, "Neeraj Chopra is described as the first track and field athlete from independent India to:",
    "Win two individual Olympic medals",
    "Win three CWG medals",
    "Hold the world record and an Olympic gold together",
    "Win Olympic gold and a CWG gold in the same year",
    "He won gold at Tokyo 2020 and silver at Paris 2024 — two individual Olympic medals.")
add(OTH, T, "India Post released a ₹5 commemorative stamp for the birth centenary of:",
    "Satish Gujral", "M. F. Husain", "Kailash Chandra Pant", "Syama Prasad Mookerjee",
    "The stamp marked the birth centenary of Satish Gujral.")
add(OTH, T, "Satish Gujral was awarded which honour in 1999?",
    "Padma Vibhushan", "Padma Shri", "Padma Bhushan only, not Vibhushan", "Bharat Ratna",
    "He received the Padma Vibhushan in 1999, India’s second-highest civilian award. He was a painter, sculptor, muralist, architect and writer.")
add(OTH, T, "Which cricketer announced retirement from international cricket in this set of news?",
    "Ajinkya Rahane", "Cheteshwar Pujara", "Ravichandran Ashwin", "Dinesh Karthik",
    "Ajinkya Rahane announced his retirement from international cricket.")

T = "Obituaries"
add(OTH, T, "Nirmal “Nims” Purja died in an avalanche on which mountain?",
    "Broad Peak in Pakistan", "K2", "Nanga Parbat", "Annapurna",
    "He died in an avalanche on Broad Peak, in the Karakoram, the world’s 12th-highest mountain.")
add(OTH, T, "Nims Purja was the first person to climb all 14 eight-thousanders:",
    "Twice, without supplementary oxygen",
    "Once, without supplementary oxygen",
    "Twice, with oxygen above 8,000 m",
    "In a single season, with oxygen",
    "He climbed all 14 eight-thousanders twice without supplementary oxygen. Purja was attempting to move closer to that first when he died. He had also climbed the 14 peaks in just over six months.")
add(OTH, T, "Which military first is attached to Nims Purja?",
    "The first Gurkha to climb Everest while serving in the British military",
    "The first Indian Army officer to climb Everest",
    "The first British officer to climb K2 in winter",
    "The first Gurkha to receive the Padma Shri",
    "He was the first Gurkha to climb Everest while serving in the British military, and was awarded an MBE in 2018.")
add(OTH, T, "Kailash Chandra Pant, who died in this period, was:",
    "A noted Hindi writer and journalist, awarded the Padma Shri in 2026",
    "A mountaineer awarded the Padma Shri",
    "A painter awarded the Padma Vibhushan",
    "The former Union minister K. C. Pant",
    "He was a noted Hindi writer and journalist. Earlier in 2026 he received the Padma Shri for literature and education.")

T = "Naoero and Shipki La"
add(OTH, T, "Nauru has officially changed its name to:",
    "The Republic of Naoero", "The Republic of Nauru Atoll", "Naoero Islands", "The Republic of Pleasant Island",
    "Nauru changed its name to the Republic of Naoero, its traditional indigenous name.")
add(OTH, T, "Citizens of the renamed country will be called:",
    "dei-Naoero", "Naoerans", "Nauruans, unchanged", "Naoeroese",
    "Citizens will be referred to as “dei-Naoero” instead of Nauruans.")
add(OTH, T, "Naoero is the world’s third-smallest country, after:",
    "Vatican City and Monaco", "Monaco and San Marino", "Vatican City and Nauru’s old listing", "Tuvalu and Monaco",
    "It is the third-smallest after Vatican City and Monaco.")
add(OTH, T, "India–China border trade through Shipki La resumed after a gap of:",
    "Six years", "Four years", "Ten years", "Two years",
    "Trade resumed after six years.")
add(OTH, T, "Shipki La is located in which district, and connects India with which region?",
    "Kinnaur, Himachal Pradesh, with Tibet",
    "Lahaul-Spiti, with Tibet",
    "Kinnaur, with Nepal",
    "Uttarkashi, with Tibet",
    "Shipki La, in Kinnaur district of Himachal Pradesh, is an ancient trade route to Tibet.")

T = "Days · other"
add(OTH, T, "World Wide Web Day is observed on:",
    "1 August", "6 August", "12 March", "1 September",
    "World Wide Web Day is on August 1.")
add(OTH, T, "The World Wide Web was invented by whom, where, and in which year?",
    "Sir Tim Berners-Lee at CERN in 1989",
    "Vint Cerf at CERN in 1983",
    "Tim Berners-Lee at MIT in 1991",
    "Robert Cailliau at Oxford in 1989",
    "Sir Tim Berners-Lee invented it in 1989 while working at CERN.")
add(OTH, T, "Hiroshima Day and Nagasaki Day fall on:",
    "6 August and 9 August", "9 August and 6 August", "6 August and 15 August", "5 August and 9 August",
    "Hiroshima Day is 6 August; Nagasaki Day is 9 August.")
add(OTH, T, "In 2026, the atomic bombings were marked as which anniversary?",
    "The 81st anniversary", "The 80th anniversary", "The 75th anniversary", "The 82nd anniversary",
    "2026 was the 81st anniversary of the 1945 bombings.")
add(OTH, T, "The bombs dropped on Hiroshima and Nagasaki were called:",
    "Little Boy and Fat Man", "Fat Man and Little Boy", "Thin Man and Fat Man", "Little Boy and Big Boy",
    "Hiroshima’s bomb was “Little Boy” and Nagasaki’s was “Fat Man”, both dropped by the United States.")

T = "Massachusetts, ICC, insurance"
add(OTH, T, "Who declared 15 August 2026 as “India Day” in Massachusetts?",
    "Governor Maura Healey", "Governor Kathy Hochul", "Mayor Michelle Wu alone", "The US President",
    "Massachusetts Governor Maura Healey made the declaration. Boston Mayor Michelle Wu issued a similar proclamation.")
add(OTH, T, "The 2026 India Day observance coincides with which anniversary of Independence?",
    "The 79th anniversary of 1947", "The 80th anniversary", "The 75th anniversary", "The 78th anniversary",
    "It coincides with the 79th anniversary of Independence in 1947.")
add(OTH, T, "Venezuela formally notified the United Nations of withdrawal from:",
    "The Rome Statute of the International Criminal Court",
    "The United Nations itself",
    "The International Court of Justice",
    "The Geneva Conventions",
    "It notified withdrawal from the Rome Statute of the ICC. The exit takes effect one year after notification.")
add(OTH, T, "The Rome Statute was adopted on, and entered into force on:",
    "17 July 1998, and 1 July 2002",
    "1 July 1998, and 17 July 2002",
    "17 July 2002, and 1 July 1998",
    "15 June 1998, and 1 July 2002",
    "It was adopted on 17 July 1998 and entered into force on 1 July 2002.")
add(OTH, T, "The ICC is headquartered in, and as of August 2026 had how many States Parties?",
    "The Hague, Netherlands; 125 States Parties",
    "Geneva; 125 States Parties",
    "The Hague; 123 States Parties",
    "Rome; 166 States Parties",
    "HQ is The Hague. As of August 2026 there were 125 States Parties. It prosecutes genocide, war crimes, crimes against humanity and the crime of aggression.")
add(OTH, T, "The Supreme Court extended mandatory third-party insurance for new private cars from:",
    "3 years to 4 years", "4 years to 5 years", "5 years to 6 years", "1 year to 3 years",
    "For new private cars the period rose from 3 years to 4 years.")
add(OTH, T, "For new two-wheelers, mandatory third-party insurance was increased from:",
    "5 years to 6 years", "3 years to 4 years", "5 years to 7 years", "4 years to 6 years",
    "For new two-wheelers it rose from 5 years to 6 years.")
add(OTH, T, "The Supreme Court also directed technology such as what, to catch uninsured vehicles?",
    "ANPR-linked e-challans", "FASTag-only challans", "A new insurance cess", "GPS locks on vehicles",
    "It directed mechanisms such as Automatic Number Plate Recognition-linked e-challans.")

# ================= ESI =================
T = "ADB loan and Urban Challenge Fund"
add(ESI, T, "The Asian Development Bank approved what support for India’s urban reform programme?",
    "A $1 billion loan, plus $3 million in technical assistance",
    "A $1 billion grant, plus $3 million TA",
    "A $3 billion loan and $1 million TA",
    "A $1 billion loan with no technical assistance",
    "ADB approved a $1 billion loan and will include $3 million TA to MoHUA.")
add(ESI, T, "The ADB financing will support which programme, linked to which Indian fund?",
    "Urban Transformation and Investment Program, linked to the Urban Challenge Fund",
    "AMRUT 2.0, linked to the Smart Cities Mission",
    "Urban Challenge Fund, linked to PM GatiShakti",
    "National Urban Livelihoods Mission",
    "It supports the Urban Transformation and Investment Program, linked to the Urban Challenge Fund.")
add(ESI, T, "The Urban Challenge Fund is what kind of scheme, of which ministry?",
    "A Centrally Sponsored Scheme of the Ministry of Housing and Urban Affairs",
    "A Central Sector Scheme of the Ministry of Finance",
    "A CSS of the Ministry of Jal Shakti",
    "A state scheme supported by ADB directly",
    "UCF is a CSS of MoHUA.")
add(ESI, T, "UCF was announced in, and approved by the Union Cabinet in:",
    "Union Budget 2025-26; February 2026",
    "Union Budget 2024-25; February 2025",
    "Union Budget 2026-27; August 2026",
    "Union Budget 2025-26; February 2025",
    "It was announced in the Union Budget 2025-26 and approved by the Cabinet in February 2026.")
add(ESI, T, "Total central assistance under UCF, and the investment it is expected to generate, are:",
    "₹1 lakh crore assistance, about ₹4 lakh crore of total investment",
    "₹4 lakh crore assistance, about ₹1 lakh crore of investment",
    "₹1 lakh crore assistance, about ₹2 lakh crore of investment",
    "₹90,000 crore assistance, about ₹4 lakh crore of investment",
    "Central assistance is ₹1 lakh crore, expected to generate about ₹4 lakh crore of urban investment.")
add(ESI, T, "UCF can provide up to what share of project cost, and at least how much must come from the market?",
    "Up to 25% from UCF, and at least 50% from market sources",
    "Up to 50% from UCF, and at least 25% from the market",
    "Up to 40% from UCF, and at least 40% from the market",
    "Up to 25% from UCF, and at least 70% from the market",
    "UCF provides up to 25%. At least 50% must come from market sources such as municipal bonds, bank loans and PPPs.")
add(ESI, T, "The Credit Repayment Guarantee Scheme under UCF is of what size, and for whom?",
    "₹5,000 crore, for smaller ULBs and cities in North-Eastern and hilly States/UTs",
    "₹7,000 crore, for all million-plus cities",
    "₹5,000 crore, only for metro rail",
    "₹90,000 crore, for smaller ULBs",
    "A ₹5,000 crore guarantee supports smaller ULBs and cities in the North-East and hilly States/UTs.")
add(ESI, T, "For a first-time loan, the central guarantee can cover up to:",
    "₹7 crore or 70% of the loan, whichever is lower",
    "₹7 crore or 70%, whichever is higher",
    "₹5 crore or 50%, whichever is lower",
    "₹10 crore or 70%, whichever is lower",
    "The guarantee can cover up to ₹7 crore or 70% of the loan amount, whichever is lower.")
add(ESI, T, "Of the ₹1 lakh crore UCF assistance, the three components are:",
    "₹90,000 crore projects, ₹5,000 crore preparation/capacity, ₹5,000 crore credit guarantee",
    "₹80,000 crore projects, ₹10,000 crore preparation, ₹10,000 crore guarantee",
    "₹90,000 crore projects, ₹7,000 crore preparation, ₹3,000 crore guarantee",
    "₹95,000 crore projects and ₹5,000 crore guarantee only",
    "₹90,000 crore is for projects, ₹5,000 crore for preparation and capacity building, and ₹5,000 crore for the credit guarantee.")

T = "Glaw Lake and Ramsar"
add(ESI, T, "Glaw Lake became which Ramsar Site of India, and a first for which state?",
    "The 101st Ramsar Site, and the first in Arunachal Pradesh",
    "The 100th Ramsar Site, and the first in Arunachal Pradesh",
    "The 101st, and the second in Arunachal Pradesh",
    "The 99th, in Lohit district of Assam",
    "It is India’s 101st Ramsar Site and the first in Arunachal Pradesh.")
add(ESI, T, "Who announced the Glaw Lake Ramsar designation?",
    "Union Environment Minister Bhupender Yadav",
    "The Chief Minister of Arunachal Pradesh",
    "The Director General of Forests only",
    "The Ramsar Secretary-General in Geneva",
    "Union Environment Minister Bhupender Yadav announced it.")
add(ESI, T, "Glaw Lake lies in which district and inside which protected area?",
    "Lohit district, inside Kamlang Tiger Reserve and Wildlife Sanctuary",
    "Anjaw district, inside Namdapha Tiger Reserve",
    "Lohit district, inside Namdapha",
    "Changlang district, inside Kamlang",
    "It is in Lohit, inside Kamlang Tiger Reserve and Wildlife Sanctuary in the Eastern Himalayas.")
add(ESI, T, "Glaw Lake is locally known as, and is fed by:",
    "Glaw Tuwi, fed by perennial mountain streams",
    "Glaw Tso, fed by glacial melt only",
    "Kamlang Lake, fed by the Lohit river",
    "Glaw Tuwi, a seasonal oxbow",
    "It is locally Glaw Tuwi and is fed by perennial mountain streams. It is a natural freshwater wetland.")
add(ESI, T, "The designated Ramsar area of Glaw Lake, the forest department’s waterbody figure, and the elevation are about:",
    "129 hectares, 82 hectares, and 1,168 metres",
    "82 hectares, 129 hectares, and 1,168 metres",
    "129 hectares, 20 hectares, and 2,168 metres",
    "1,168 hectares at 129 metres",
    "The Ramsar Site is about 129 hectares. The forest department records about 82 hectares of waterbody, at roughly 1,168 metres.")
add(ESI, T, "The Ramsar Convention was adopted on, and came into force in:",
    "2 February 1971 in Ramsar, Iran; in force in 1975",
    "2 February 1971 in Geneva; in force in 1975",
    "1 February 1982 in Ramsar; in force in 1982",
    "2 February 1975; in force in 1971",
    "It was adopted on 2 February 1971 in Ramsar, Iran, and came into force in 1975.")
add(ESI, T, "India ratified the Ramsar Convention on:",
    "1 February 1982", "2 February 1982", "1 February 1971", "2 February 1975",
    "India ratified it on 1 February 1982.")
add(ESI, T, "India’s global position on Ramsar sites is:",
    "Highest in Asia, and third in the world",
    "Highest in the world",
    "Second in Asia, third in the world",
    "Third in Asia, behind China and Japan",
    "India has the most Ramsar sites in Asia and ranks third globally.")
add(ESI, T, "Which two countries are ahead of India in the number of Ramsar sites, with what counts?",
    "United Kingdom 176 and Mexico 144",
    "Mexico 176 and the United Kingdom 144",
    "United Kingdom 144 and China 176",
    "Australia 176 and Mexico 144",
    "Only the UK (176) and Mexico (144) are ahead of India.")
add(ESI, T, "India’s Ramsar network grew from how many sites in 2014 to how many by mid-2026?",
    "From 26 sites to 100 sites", "From 26 sites to 101 sites by 2014’s comparison year", "From 20 sites to 100", "From 36 sites to 101",
    "The infographic traces expansion from 26 sites in 2014 to 100 sites in mid-2026. Glaw later became the 101st.")
add(ESI, T, "India’s 100th Ramsar Site is:",
    "Jai Prakash Narayan Bird Sanctuary (Surha Tal), Ballia, Uttar Pradesh, in June 2026",
    "Shekha Jheel, Aligarh, in June 2026",
    "Glaw Lake, in June 2026",
    "Patna Bird Sanctuary, in June 2026",
    "The 100th is Jai Prakash Narayan Bird Sanctuary (Surha Tal), Ballia, UP, designated in June 2026.")
add(ESI, T, "The 99th Ramsar Site is:",
    "Shekha Jheel Bird Sanctuary, Aligarh, Uttar Pradesh, in April 2026",
    "Surha Tal, Ballia, in April 2026",
    "Chhari-Dhand, Gujarat, in April 2026",
    "Renuka Lake, in April 2026",
    "The 99th is Shekha Jheel Bird Sanctuary, Aligarh, added in April 2026.")
add(ESI, T, "The 97th and 98th Ramsar Sites, added on the eve of World Wetlands Day 2026, are:",
    "Patna Bird Sanctuary (Uttar Pradesh) and Chhari-Dhand (Gujarat)",
    "Shekha Jheel and Surha Tal",
    "Nagi and Nakti bird sanctuaries",
    "Chilika and Keoladeo",
    "They are Patna Bird Sanctuary in UP and Chhari-Dhand in Gujarat.")
add(ESI, T, "The top three states by number of Ramsar sites are:",
    "Tamil Nadu 20, Uttar Pradesh 12, Bihar 6",
    "Uttar Pradesh 20, Tamil Nadu 12, Bihar 6",
    "Tamil Nadu 20, Bihar 12, Uttar Pradesh 6",
    "Tamil Nadu 18, Uttar Pradesh 10, Gujarat 6",
    "Tamil Nadu has 20 (highest), Uttar Pradesh 12 and Bihar 6.")
add(ESI, T, "Bihar’s Ramsar sites named in the infographic include:",
    "Gogabil Lake, Kabar Jheel, and the Nagi and Nakti bird sanctuaries",
    "Only Kanwar Lake",
    "Chhari-Dhand and Kabar Jheel",
    "Gogabil, Kabar and Chilika",
    "Bihar’s set includes Gogabil Lake, Kabar Jheel, and Nagi and Nakti.")
add(ESI, T, "India’s largest and smallest Ramsar sites named are:",
    "Sundarban Wetland, about 4,230 sq km; Renuka Lake, 20 hectares",
    "Chilika, about 4,230 sq km; Renuka, 20 hectares",
    "Sundarban, 4,230 hectares; Glaw Lake, 20 hectares",
    "Keoladeo, the largest; Renuka, 20 sq km",
    "Largest is Sundarban Wetland, West Bengal, about 4,230 sq km. Smallest is Renuka Lake, Himachal Pradesh, 20 hectares.")
add(ESI, T, "India’s first two Ramsar sites, designated in 1981, were:",
    "Chilika Lake (Odisha) and Keoladeo National Park (Rajasthan)",
    "Chilika and Loktak",
    "Keoladeo and Sundarban",
    "Chilika and Renuka",
    "The first sites (1981) were Chilika Lake and Keoladeo National Park.")
add(ESI, T, "On the Montreux Record, the current position of Keoladeo and Chilika is:",
    "Keoladeo remains; Chilika was removed after restoration",
    "Both remain",
    "Chilika remains; Keoladeo was removed",
    "Neither has ever been listed",
    "Keoladeo National Park remains on the Montreux Record, while Chilika was removed after successful ecological restoration.")
add(ESI, T, "Which Indian cities were the first to receive Wetland City Accreditation?",
    "Indore and Udaipur", "Bhopal and Udaipur", "Indore and Bhopal", "Srinagar and Udaipur",
    "Indore and Udaipur are India’s first cities to receive this recognition.")

T = "Green Credit Programme"
add(ESI, T, "The Green Credit Programme was launched in which year, by which ministry, as part of what?",
    "2023, by MoEFCC, as a core part of LiFE (Lifestyle for Environment)",
    "2021, by MoEFCC, as part of the NAPCC",
    "2023, by MoSPI, as part of LiFE",
    "2015, by MoEFCC, as a carbon market",
    "GCP was launched in 2023 by MoEFCC as a core component of LiFE.")
add(ESI, T, "How does GCP differ from carbon credits?",
    "It covers a broader set of ecological benefits, not only CO2 reduction",
    "It is tradable on commodity exchanges like carbon credits",
    "It can be reused across multiple CSR cycles",
    "It is issued only for industrial emissions",
    "Unlike carbon credits, which target CO2 reduction, GCP covers a broader spectrum of ecological benefits.")
add(ESI, T, "Which set correctly completes the eight GCP activities, including the less obvious ones?",
    "Tree plantation, water, sustainable agriculture, waste, air pollution, mangroves, Ecomark and sustainable buildings",
    "Only tree plantation and water",
    "Tree plantation, carbon capture, nuclear offsets and mangroves",
    "Ecomark, plastic credits, EV credits and tree plantation",
    "The eight are tree plantation, water management, sustainable agriculture, waste management, air-pollution reduction, mangrove conservation, Ecomark label development and sustainable building infrastructure.")
add(ESI, T, "The primary implementing agency for GCP is:",
    "Indian Council of Forestry Research and Education (ICFRE)",
    "Forest Survey of India",
    "CAMPA",
    "National Biodiversity Authority",
    "ICFRE is the designated primary implementing agency.")
add(ESI, T, "Forest-restoration credits are awarded only after a minimum of:",
    "5 years of work", "2 years of work", "10 years of work", "3 years of work",
    "Credits for forest restoration are awarded only after a minimum of 5 years.")
add(ESI, T, "A tree-plantation project qualifies only if canopy density reaches at least:",
    "40% on degraded forest or wasteland",
    "20% on any farmland",
    "60% on degraded forest",
    "40% on a natural forest that was already dense",
    "It must achieve a minimum canopy density of 40% on degraded forest or wasteland.")
add(ESI, T, "One green credit is equivalent to:",
    "One new tree that has survived for at least five years",
    "One tonne of CO2 avoided",
    "One hectare of canopy",
    "One tree planted, regardless of survival",
    "One green credit equals one new tree that has survived at least five years.")
add(ESI, T, "Green credits may generally be transferred only:",
    "Between a company and its subsidiaries, and are not tradable for multiple cycles",
    "Freely on a stock exchange",
    "To any NGO once a year",
    "Across countries under Article 6",
    "They are non-tradable for multiple cycles and generally cannot be transferred except between a company and its subsidiaries.")
add(ESI, T, "A green credit may be exchanged only once, and for which purposes?",
    "CSR, compensatory afforestation, or project-linked obligations",
    "Only carbon-tax payment",
    "CSR every financial year",
    "Income-tax rebate under 80G",
    "One-time exchange is allowed for CSR, Compensatory Afforestation or project-linked obligations. Once exchanged, credits cannot be reused.")
add(ESI, T, "Implementing agencies must complete plantation within how long of receiving payment, and maintain it for how long?",
    "Within 2 years, and maintain it for the next 10 years",
    "Within 5 years, and maintain it for 5 years",
    "Within 2 years, and maintain it for 5 years",
    "Within 10 years, and maintain it for 2 years",
    "Plantation must be completed within 2 years of payment and maintained for the next 10 years.")

T = "Project SARATHI"
add(ESI, T, "SARATHI expands to:",
    "Students’ Alliance for Responsible Action to Transform Healthcare Institutes",
    "Student Assistance and Rapid Action for Tertiary Hospitals in India",
    "Service Alliance for Rural and Tertiary Health Institutions",
    "Students’ Association for Responsible Action in Traditional Healthcare",
    "That is the expansion given for Project SARATHI.")
add(ESI, T, "Who chaired the meeting on expanding Project SARATHI beyond PGIMER Chandigarh?",
    "Union Health Minister J. P. Nadda",
    "The Director of AIIMS New Delhi",
    "Mansukh Mandaviya",
    "The WHO Regional Director",
    "J. P. Nadda chaired the meeting to explore expansion to Central Government hospitals and other institutions.")
add(ESI, T, "Project SARATHI uses trained youth volunteers for:",
    "Non-medical help to patients, reducing non-clinical workload of staff",
    "Clinical nursing in ICUs",
    "Pharmacovigilance reporting",
    "Ambulance driving",
    "Volunteers help patients with non-medical tasks, improving experience and reducing non-clinical workload.")
add(ESI, T, "The SARATHI pilot began when, with how many volunteers, from where?",
    "April 2024, with 22 volunteers from Government Polytechnic College for Women, Chandigarh",
    "6 May 2024, with 22 volunteers from PGIMER itself",
    "April 2023, with 220 volunteers",
    "April 2024, with 22 volunteers from Panjab University",
    "It began at PGIMER in April 2024 with 22 volunteers from Government Polytechnic College for Women, Chandigarh.")
add(ESI, T, "Project SARATHI was formally launched at PGIMER on:",
    "6 May 2024", "6 May 2025", "22 April 2024", "6 August 2024",
    "After the pilot, it was formally launched at PGIMER on 6 May 2024.")

T = "IPC and SEARN"
add(ESI, T, "The Indian Pharmacopoeia Commission was recognised by WHO-SEARN as:",
    "Regional Centre of Excellence in Pharmacovigilance and Technical Centre in Quality of Medicines",
    "Only a Regional Centre of Excellence in drug pricing",
    "A global centre replacing WHO-UMC",
    "Technical Centre in Pharmacovigilance only",
    "IPC was recognised both as a Regional Centre of Excellence in Pharmacovigilance and as a Technical Centre in Quality of Medicines.")
add(ESI, T, "The IPC recognition was announced at which meeting, held where?",
    "The 10th anniversary meeting of SEARN, in Kathmandu",
    "The 10th World Health Assembly, in Geneva",
    "The 5th SEARN meeting, in New Delhi",
    "The 10th SEARN meeting, in Jakarta",
    "It was announced during the 10th Anniversary Meeting of SEARN in Kathmandu, Nepal.")
add(ESI, T, "SEARN was established in which year?",
    "2016", "2010", "2006", "2020",
    "SEARN was established in 2016 to promote cooperation among regulators in the WHO South-East Asia Region.")
add(ESI, T, "IPC manages which two Indian safety programmes?",
    "PvPI and MvPI", "CDSCO and NPPA", "PvPI and AEFI only", "MvPI and CDSCO",
    "IPC manages the Pharmacovigilance Programme of India and the Materiovigilance Programme of India.")
add(ESI, T, "WHO-SEARO is headquartered in, and the region now has how many member states?",
    "New Delhi; 10 member states", "Kathmandu; 11 member states", "New Delhi; 11 member states", "Bangkok; 10 member states",
    "WHO-SEARO headquarters is New Delhi. The region currently has 10 member states.")
add(ESI, T, "Which country shifted from WHO’s South-East Asia Region to the Western Pacific Region in 2025?",
    "Indonesia", "Thailand", "Myanmar", "Sri Lanka",
    "Indonesia officially shifted to the Western Pacific Region in 2025.")

T = "AI in schools and SOAR"
add(ESI, T, "NCERT, with CBSE, introduced Computational Thinking and AI for which classes, from which year?",
    "Classes III to VIII, from 2026-27",
    "Classes VI to XII, from 2026-27",
    "Classes I to V, from 2025-26",
    "Classes IX to XII, from 2026-27",
    "The curriculum is for Classes III to VIII from academic year 2026-27, in line with NEP 2020 and NCF-SE 2023.")
add(ESI, T, "The school AI curriculum also incorporates:",
    "Responsible and ethical AI",
    "Only coding without ethics",
    "A mandatory robotics lab grant",
    "Replacement of mathematics in Classes III–V",
    "It incorporates responsible and ethical AI. Teacher handbooks and facilitator guides have been developed.")
add(ESI, T, "SOAR was launched by which ministry, and expands to what?",
    "MSDE; Skilling for AI Readiness",
    "Ministry of Education; Schooling for AI Readiness",
    "MeitY; Sovereign AI for All Regions",
    "MSDE; Skill India for AI Robotics",
    "The Ministry of Skill Development and Entrepreneurship launched SOAR — Skilling for AI Readiness.")
add(ESI, T, "SOAR’s target groups are:",
    "School students of Classes VI–XII, and educators",
    "Classes III–VIII only",
    "Only engineering colleges",
    "ITI students above 18 only",
    "Target groups are students of Classes VI–XII and educators.")
add(ESI, T, "The four components of SOAR are:",
    "AI to be Aware, AI to Acquire, AI for Aspire, and AI for Educators",
    "AI to Aware, AI to Apply, AI to Assess, AI to Award",
    "Aware, Acquire, Aspire and Accredit",
    "AI for Schools, AI for ITIs, AI for Colleges, AI for Start-ups",
    "SOAR comprises AI to be Aware, AI to Acquire, AI for Aspire and AI for Educators.")

T = "Urban Haats"
add(ESI, T, "How many Urban Haats are operational, and how many of them are in Rajasthan?",
    "28 operational, including 3 in Rajasthan",
    "31 operational, including 3 in Rajasthan",
    "28 operational, including 5 in Rajasthan",
    "18 operational, including 3 in Gujarat",
    "The Ministry of Textiles told the Rajya Sabha that 28 Urban Haats are operational, including 3 in Rajasthan.")
add(ESI, T, "An Urban Haat is:",
    "A permanent marketing facility where artisans and weavers sell directly through the year",
    "A seasonal fair held only during Handloom Day",
    "A GI registration office",
    "A mobile food-testing van",
    "It is a permanent facility in towns and cities for direct sales, broadly on the model of Dilli Haat, with stalls allotted rotationally at nominal charges.")
add(ESI, T, "Urban Haats are jointly supported by which two programmes, both abbreviated NHDP?",
    "National Handicrafts Development Programme and National Handloom Development Programme",
    "National Handloom Development Programme and National Heritage Development Programme",
    "Only the handicrafts NHDP",
    "PM Vishwakarma and NHDP handicrafts",
    "DC (Handicrafts) supports them via the National Handicrafts Development Programme and DC (Handlooms) via the National Handloom Development Programme.")
add(ESI, T, "The maximum financial ceiling per Urban Haat, under current handicrafts-side guidelines, is:",
    "₹8 crore for up to 80 stalls",
    "₹8 crore for up to 40 stalls",
    "₹10 crore for up to 80 stalls",
    "₹5 crore for up to 80 stalls",
    "The ceiling is ₹8 crore per Urban Haat for up to 80 stalls.")
add(ESI, T, "The normal funding pattern of an Urban Haat is:",
    "40% DC (Handicrafts), 40% DC (Handlooms), 20% state implementing agency",
    "50% Centre, 50% state",
    "80% DC (Handicrafts) and 20% state",
    "45% each from the two DCs and 10% state, everywhere",
    "Normally it is 40-40-20, so the combined central share is 80%.")
add(ESI, T, "For the North-East, Jammu & Kashmir and Ladakh, Urban Haat funding is:",
    "90:10, with 45% from each DC and 10% from the implementing agency",
    "80:20, same as the rest of India",
    "100% central funding",
    "70:30",
    "Those regions follow a 90:10 pattern — 45% each from the two DCs and 10% from the implementing agency.")

T = "MoSPI statistics"
add(ESI, T, "National Sample Surveys have been digitised using:",
    "CAPI integrated with the e-Sigma platform",
    "Paper schedules scanned into e-Sigma",
    "Only an AI chatbot, without tablets",
    "The PAIMANA app",
    "NSS has been digitised using Computer Assisted Personal Interview integrated with e-Sigma, with validation, multilingual interfaces and an AI chatbot.")
add(ESI, T, "The new base years for GDP, CPI and IIP are:",
    "GDP 2022-23, CPI 2024, IIP 2022-23",
    "GDP 2022-23, CPI 2022-23, IIP 2024",
    "GDP 2011-12, CPI 2024, IIP 2022-23",
    "All three moved to 2024",
    "GDP moves from 2011-12 to 2022-23, CPI from 2012 to 2024, and IIP from 2011-12 to 2022-23.")
add(ESI, T, "The new CPI series uses which classification, and NIC 2025 is aligned with what?",
    "COICOP-2018; NIC 2025 is aligned with ISIC Revision 5",
    "COICOP-1999; ISIC Revision 4",
    "SNA 2008; COICOP-2018",
    "ISIC Rev. 5 for CPI and COICOP for NIC",
    "CPI 2024 uses COICOP-2018. NIC 2025 is aligned with ISIC Revision 5.")
add(ESI, T, "SQAF is based on which UN framework, of which year?",
    "UN National Quality Assurance Framework, 2019",
    "IMF SDDS, 2016",
    "SNA 2008",
    "UNFPOS, 2019",
    "The Statistical Quality Assessment Framework is based on the UN National Quality Assurance Framework, 2019.")
add(ESI, T, "PAIMANA replaced which older system, and for what purpose?",
    "OCMS-2006, for monitoring Central Sector infrastructure projects",
    "e-Sigma, for survey processing",
    "CPGRAMS, for project grievances",
    "OCMS-2016, for state projects",
    "PAIMANA replaced OCMS-2006 for monitoring Central Sector infrastructure projects.")
add(ESI, T, "India adopted the UN Fundamental Principles of Official Statistics in:",
    "May 2016", "May 2019", "January 2008", "May 2024",
    "UNFPOS was adopted by India in May 2016.")
add(ESI, T, "e-SIGMA expands to:",
    "e-Survey Instrument and Generalised Multimodal Application",
    "Electronic Statistical Information and General Monitoring App",
    "e-Survey of Industries, GDP and Macro Accounts",
    "Electronic Sigma Sampling Method Application",
    "e-SIGMA is MoSPI’s e-Survey Instrument and Generalised Multimodal Application. CAPI works inside that ecosystem.")
add(ESI, T, "India’s national accounts are aligned with, and CPI/GDP dissemination follows:",
    "SNA 2008, and the IMF’s SDDS",
    "SNA 1993, and SDDS",
    "SNA 2008, and the IMF’s GDDS only",
    "ISIC Rev. 5, and SNA 2008 for dissemination",
    "National Accounts follow SNA 2008. CPI and GDP dissemination follows the IMF Special Data Dissemination Standard.")

T = "CARA and adoption"
add(ESI, T, "CARA digitised adoption through which module of which portal?",
    "The Adoption Module of the Mission Vatsalya portal",
    "CARINGS as a standalone portal outside Mission Vatsalya",
    "The e-Shram adoption module",
    "Mission Shakti’s adoption tab",
    "The complete process is on the Adoption Module of Mission Vatsalya. All SAAs are mandatorily integrated with CARINGS–Mission Vatsalya.")
add(ESI, T, "CARINGS stands for:",
    "Child Adoption Resource Information and Guidance System",
    "Central Adoption Resource Information and Guidance System",
    "Child Adoption Registry and Inspection Network System",
    "Central Authority for Resource Information on Guardianship",
    "CARINGS is the Child Adoption Resource Information and Guidance System.")
add(ESI, T, "States have been advised to establish at least one SAA in every district under which provisions?",
    "Sections 65 and 66 of the Juvenile Justice Act, 2015",
    "Section 68 of the JJ Act",
    "Sections 3 and 4 of the Adoption Regulations",
    "The Hindu Adoptions and Maintenance Act",
    "The advice cites Sections 65 and 66 of the JJ Act, 2015. Mission Vatsalya funds the agencies.")
add(ESI, T, "A child can enter the adoption referral system only after:",
    "Being declared Legally Free for Adoption by the Child Welfare Committee",
    "A police FIR is closed",
    "CARA issues a passport",
    "The Gram Sabha recommends adoption",
    "LFA must be declared by the CWC. Timelines are in Schedule XIV of the Adoption Regulations 2022.")
add(ESI, T, "The JJ Act, 2015 route of adoption is distinctive because:",
    "It covers eligible prospective parents irrespective of religion; nodal ministry is WCD",
    "It applies only to Hindus, Buddhists, Jains and Sikhs",
    "Its nodal ministry is Law and Justice",
    "It bars inter-country adoption",
    "The institutional/CARA route under the JJ Act covers parents irrespective of religion. Nodal ministry is Women and Child Development.")
add(ESI, T, "HAMA, 1956, applies to whom, and which ministry is nodal?",
    "Hindus, Buddhists, Jains and Sikhs; Ministry of Law and Justice",
    "All religions; Ministry of WCD",
    "Only Hindus; Ministry of WCD",
    "Hindus and Christians; Ministry of Law and Justice",
    "HAMA is the personal-law route for Hindus, Buddhists, Jains and Sikhs, with the Ministry of Law and Justice as nodal.")
add(ESI, T, "CARA is a statutory body under which section, and is India’s Central Authority under which convention?",
    "Section 68 of the JJ Act, 2015; Hague Convention on Inter-country Adoption, 1993",
    "Section 65 of the JJ Act; Hague Convention 1980",
    "Section 68 of HAMA; Hague Convention 1993",
    "Article 68 of the Constitution; UNCRC",
    "CARA is constituted under Section 68 of the JJ Act and is the Central Authority under the 1993 Hague Convention. It regulates in-country and inter-country adoptions.")

T = "Tribal land and FRA"
add(ESI, T, "Under Section 3(2) of the Forest Rights Act, forest land up to what area may be diverted, and with whose recommendation?",
    "Up to 1 hectare, only with the Gram Sabha’s recommendation",
    "Up to 1 hectare, with only the Collector’s approval",
    "Up to 5 hectares, with the Gram Sabha’s recommendation",
    "Up to 1 acre, with the Gram Sabha’s recommendation",
    "Up to 1 hectare can be diverted for specified government facilities for forest dwellers, only with the Gram Sabha’s recommendation.")
add(ESI, T, "For minor-mineral leases in Scheduled Areas, whose prior recommendation is mandatory, and under which law?",
    "The Gram Sabha or Panchayat, under PESA",
    "The Gram Sabha, under the FRA only",
    "The State Mining Secretary, under the MMDR Act",
    "MoEFCC, under PARIVESH",
    "Prior recommendation of the Gram Sabha/Panchayat is mandatory under PESA.")
add(ESI, T, "Forest-land diversion proposals for non-forest use are processed through:",
    "The PARIVESH portal", "The CARINGS portal", "e-Shram", "PM GatiShakti only",
    "They are processed through PARIVESH and must comply with forest and tribal-rights laws.")
add(ESI, T, "The full name of the FRA, 2006, begins with:",
    "Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act",
    "Forest Rights and Tribal Land (Recognition) Act",
    "Scheduled Areas and Forest Dwellers Act",
    "Panchayats (Extension to Forest Areas) Act",
    "That is the full name. It recognises individual and community rights of FDSTs and eligible OTFDs. The Ministry of Tribal Affairs is the nodal ministry.")

T = "Urban mobility and NCMC"
add(ESI, T, "MoHUA clarified that a separate “National Smart Public Transport Scheme” :",
    "Does not currently exist",
    "Was launched in Budget 2025-26",
    "Covers only metro rail",
    "Is the new name of NCMC",
    "There is currently no separate National Smart Public Transport Scheme. Support flows through PM-eBus Sewa, PM E-DRIVE, metro projects and NCMC.")
add(ESI, T, "Urban transport planning is:",
    "A State subject", "A Union subject", "A concurrent subject listed as such in the news", "A municipal subject outside the Constitution",
    "Urban planning is a State subject. The Centre offers policy and finance, including through NUTP 2006 and the Metro Rail Policy 2017.")
add(ESI, T, "NCMC follows which vision, and is based on which specification?",
    "“One Nation, One Card”; qSPARC developed by NPCI",
    "“One Nation, One Card”; the RuPay credit specification of Visa",
    "“One Card, One Metro”; qSPARC of RBI",
    "“National Common Mobility”; FASTag 2.0",
    "NCMC follows “One Nation, One Card” and is based on qSPARC — quick Specification for Payment Application of RuPay Chip — developed by NPCI.")
add(ESI, T, "PM-eBus Sewa guidelines mandate which fare system?",
    "NCMC-based Automatic Fare Collection",
    "Cash-only ticketing for the first three years",
    "A city-specific closed-loop card",
    "UPI QR without NCMC",
    "They mandate an NCMC-based Automatic Fare Collection System for bus operations.")
add(ESI, T, "Central financial assistance under MoHUA’s transport-planning sub-scheme can support preparation of:",
    "Integrated Mobility Plans, DPRs and Multi-Modal Integration Plans",
    "Only metro DPRs",
    "Only bus purchase",
    "State transport union wages",
    "The sub-scheme is “Transport Planning and Capacity Building in Urban Transport for Metro and Non-Metro Projects”.")

T = "RERA"
add(ESI, T, "A real-estate project must be registered with the state RERA before:",
    "Advertisement, marketing, booking or sale",
    "Only before the occupancy certificate",
    "Only if it is in a metro",
    "The first homebuyer complaint",
    "Registration is required before advertisement, marketing, booking or sale.")
add(ESI, T, "The penalty for not registering a project can be up to:",
    "10% of the estimated project cost",
    "5% of the amount collected",
    "10% of the profit",
    "₹10 lakh, whichever is lower",
    "A penalty of up to 10% of the estimated project cost may be imposed.")
add(ESI, T, "Projects generally need RERA registration if they exceed:",
    "500 sq. metres or more than 8 apartments",
    "1000 sq. metres or more than 12 apartments",
    "500 sq. feet or more than 8 apartments",
    "500 sq. metres and more than 12 apartments, both mandatory together",
    "Generally, projects exceeding 500 sq. metres or more than 8 apartments need registration. States may set a lower threshold.")
add(ESI, T, "Promoters must deposit what share of buyers’ money in a separate account, usable only for:",
    "70%, only for that project’s land cost and construction cost",
    "70%, for any project of the same promoter",
    "50%, for land and construction",
    "100%, for construction only",
    "70% of the amount realised must stay in a separate account for the land and construction cost of that project.")
add(ESI, T, "RERA aims to dispose of matters, as far as possible, within:",
    "60 days", "90 days", "30 days", "120 days",
    "Matters are to be disposed of, as far as possible, within 60 days.")
add(ESI, T, "Section 40 of RERA provides that unpaid interest, penalty or compensation can be recovered as:",
    "Arrears of land revenue",
    "A civil decree only through civil courts",
    "An income-tax demand",
    "A SARFAESI action",
    "Section 40 provides recovery as arrears of land revenue. Orders may come from the Authority, the Adjudicating Officer or the Appellate Tribunal.")

T = "Panchayat compendium and CPGRAMS"
add(ESI, T, "Who released “51 Stories of Panchayats Bringing Change for Good Governance”?",
    "Prof. S. P. Singh Baghel, Minister of State for Panchayati Raj",
    "The Union Minister for Rural Development",
    "The Cabinet Secretary",
    "DARPG secretary alone",
    "MoS Prof. S. P. Singh Baghel released it in New Delhi. The Hindi title is “51 Kahaniyan Badlav Ki, Panchayat Suraj Ki”.")
add(ESI, T, "The 51 stories document grievances resolved through:",
    "CPGRAMS at panchayat level",
    "Lok Adalats",
    "e-Shram",
    "RERA authorities",
    "They are 51 CPGRAMS cases of grievance redress at the grassroots, prepared with state Panchayati Raj departments.")
add(ESI, T, "CPGRAMS is administered by:",
    "DARPG in the Ministry of Personnel, Public Grievances and Pensions",
    "The Ministry of Panchayati Raj",
    "MeitY",
    "The Department of Posts",
    "CPGRAMS — Centralised Public Grievance Redress and Monitoring System — is monitored by DARPG.")
add(ESI, T, "Under the August 2024 guidelines, the grievance-resolution timeline was reduced from:",
    "30 days to 21 days", "21 days to 15 days", "30 days to 15 days", "45 days to 30 days",
    "It was reduced from 30 days to 21 days. If unresolved, an interim reply is required. An appeal is generally to be filed within 30 days. Citizens get a unique registration ID.")

T = "e-Shram"
add(ESI, T, "More than how many unorganised workers are registered on e-Shram?",
    "31.82 crore", "21.82 crore", "31.82 lakh", "13.82 crore",
    "More than 31.82 crore unorganised workers are registered. The portal also covers migrant, gig and platform workers and gives a UAN.")
add(ESI, T, "e-Shram was launched on which date, to create what database?",
    "26 August 2021, the National Database of Unorganised Workers",
    "21 October 2024, the NDUW",
    "26 August 2021, the National Career Service",
    "15 August 2021, the e-Shram One-Stop-Solution",
    "It was launched on 26 August 2021 to create the NDUW.")
add(ESI, T, "e-Shram One-Stop-Solution was launched on:",
    "21 October 2024", "26 August 2021", "21 October 2023", "1 April 2025",
    "The One-Stop-Solution, for multiple welfare schemes on one platform, was launched on 21 October 2024.")
add(ESI, T, "e-Shram is linked with which three platforms named in the magazine?",
    "NCS for jobs, SIDH for skills and PM-SYM for pension",
    "UMANG, GeM and DigiLocker",
    "EPFO, ESIC and NPS, for automatic membership",
    "NCS, e-NAM and PM-KISAN",
    "It is linked with National Career Service, Skill India Digital Hub and PM-SYM.")
add(ESI, T, "Who is generally eligible to register on e-Shram?",
    "An unorganised worker aged 16–59 who is not a member of EPFO, ESIC or government-funded NPS",
    "Any worker aged 18–60, including EPFO members",
    "Only migrant workers aged 18–59",
    "Unorganised workers aged 15–65",
    "Age is 16–59. The person should be an unorganised worker and should generally not be in EPFO, ESIC or government-funded NPS. Registration uses Aadhaar e-KYC and can be done via web, app, CSCs, State Sewa Kendras and UMANG.")

T = "BNS 2023"
add(ESI, T, "Under the Bharatiya Nyaya Sanhita, offences against women and children are placed in:",
    "Chapter V", "Chapter IV", "Chapter XVI, as in the IPC", "A separate schedule",
    "They have been placed together in Chapter V.")
add(ESI, T, "On gang rape of a minor, BNS 2023:",
    "Removes the IPC’s separate punishments for girls below 12 and below 16, and uses one provision for a woman below 16",
    "Keeps separate punishments for below 12 and below 16",
    "Applies only to girls below 12",
    "Decriminalises gang rape of girls aged 16–18",
    "BNS removes that age split and creates a common provision for gang rape of a woman below 16.")
add(ESI, T, "Section 70(2) of the BNS provides:",
    "Imprisonment for the remainder of natural life and fine, or death",
    "Imprisonment up to 10 years and fine",
    "Only a fine",
    "Imprisonment up to 20 years, with no death penalty",
    "Section 70(2) provides imprisonment for the remainder of natural life and fine, or death.")
add(ESI, T, "Section 69 punishes sexual intercourse by deceitful means, not amounting to rape, with:",
    "Imprisonment up to 10 years and fine",
    "Imprisonment up to 7 years",
    "The death penalty",
    "Imprisonment up to 10 years without fine",
    "The maximum is 10 years and fine. Deceitful means include a false promise of employment or promotion and marrying by suppressing identity, as well as a promise to marry made without intention to keep it.")
add(ESI, T, "Which procedural changes are correctly matched?",
    "Audio-video recording of the victim’s statement; medical report to the IO within 7 days; gender-neutral service of summons on an adult family member",
    "Medical report within 15 days; summons only on an adult male",
    "Statement only in writing; medical report within 7 days",
    "Summons on any neighbour; medical report within 48 hours",
    "The victim’s statement may be recorded by audio-video means, the medical report must reach the IO within 7 days, and an adult family member — not only an adult male — may receive summons.")

T = "MSME Amendment Bill 2026"
add(ESI, T, "The MSME Development (Amendment) Bill, 2026 amends which Act?",
    "The MSMED Act, 2006", "The Companies Act, 2013", "The LLP Act", "The MSME Act, 2020",
    "It amends the Micro, Small and Medium Enterprises Development Act, 2006, and has been passed by both Houses.")
add(ESI, T, "The Bill incorporates which classification into the Act?",
    "Investment plus turnover",
    "A new investment-only definition",
    "Employment-only criteria",
    "Turnover only, dropping investment",
    "Classification based on investment and turnover is incorporated. The Bill does not itself announce a new set of numerical limits.")
add(ESI, T, "Udyam registration under the new framework is:",
    "Digital, free and voluntary for all MSMEs",
    "Compulsory and paid",
    "Free but only for micro units",
    "Replaced by GST registration",
    "Registration becomes digital, free and voluntary through Udyam.")
add(ESI, T, "Mediation in delayed-payment disputes must finish within, and arbitration must be referred within:",
    "90 days for mediation; referral within 30 days",
    "60 days for mediation; referral within 90 days",
    "30 days for mediation; award within 30 days",
    "90 days for mediation; no arbitration timeline",
    "Online dispute resolution is introduced. Mediation must finish within 90 days. Arbitration is referred within 30 days, and the award is to come within 90 days after pleadings are complete.")
add(ESI, T, "If a challenge to an MSME award is pending for more than six months, the court must:",
    "Release at least 50% of the awarded amount to the MSE",
    "Release 75% to the buyer",
    "Stay the entire award",
    "Release 100% to the MSE",
    "Earlier the buyer had to deposit 75% to challenge an award. Now, if the challenge is pending over six months, at least 50% must be released to the MSE.")
add(ESI, T, "Settlement or arbitral awards under the amended law can be recovered as:",
    "Arrears of land revenue", "Income-tax dues", "Only through civil suit", "Bankruptcy claims only",
    "There was no specific provision to recover Section 18 awards as land revenue; the new framework allows recovery of the settlement or award as arrears of land revenue.")
add(ESI, T, "Current MSME limits, applicable from 1 April 2025, for a small enterprise are:",
    "Investment up to ₹25 crore and turnover up to ₹100 crore",
    "Investment up to ₹2.5 crore and turnover up to ₹10 crore",
    "Investment up to ₹50 crore and turnover up to ₹250 crore",
    "Investment up to ₹125 crore and turnover up to ₹500 crore",
    "Small: investment ≤ ₹25 crore and turnover ≤ ₹100 crore. Micro is ₹2.5 crore and ₹10 crore. Medium is ₹125 crore and ₹500 crore.")
add(ESI, T, "On TReDS and penalties, the Bill provides:",
    "All CPSEs must settle MSME invoices on TReDS; minor violations move to warnings and graded civil penalties",
    "TReDS remains optional; criminal fines stay for minor slips",
    "Only Maharatna CPSEs must use TReDS",
    "Penalties are abolished entirely",
    "CPSEs must use TReDS. Minor violations shift from conviction and fines to warnings and graded civil penalties.")

T = "GeM"
add(ESI, T, "GeM completed ten years of operations on:",
    "9 August 2026", "9 August 2016", "15 August 2026", "1 August 2026",
    "The decade was completed on 9 August 2026. The infographic gives the launch date as 9 August 2016.")
add(ESI, T, "GeM’s cumulative GMV and order count were:",
    "Over ₹20 lakh crore through more than 3.78 crore orders",
    "Over ₹20 lakh crore through 3.78 lakh orders",
    "Over ₹10 lakh crore through 3.78 crore orders",
    "₹3.78 lakh crore through 20 crore orders",
    "GMV was over ₹20 lakh crore via more than 3.78 crore orders.")
add(ESI, T, "GeM transaction charges were reduced from, and orders up to what value are exempt?",
    "From 0.50% to 0.30%; orders up to ₹10 lakh are exempt",
    "From 0.30% to 0.10%; orders up to ₹10 lakh",
    "From 0.50% to 0.30%; orders up to ₹25,000",
    "From 1% to 0.50%; orders up to ₹5 lakh",
    "Charges fell from 0.50% to 0.30%. Orders up to ₹10 lakh are fully exempt, and the fee is capped at ₹3 lakh.")
add(ESI, T, "GeM is a 100% government-owned not-for-profit company under which provision, and it replaced which body?",
    "Section 8 of the Companies Act, 2013; it replaced DGS&D",
    "Section 25 of the Companies Act, 1956; it replaced the DGS&D",
    "Section 8; it replaced GeM SPV’s parent NSIC",
    "A society under the Societies Act; it replaced DGS&D",
    "The infographic describes a Section 8 company, 100% government-owned, operated as a GeM SPV under the Ministry of Commerce and Industry, replacing DGS&D.")
add(ESI, T, "The public-procurement sub-targets on GeM’s MSE policy, as shown, are:",
    "25% from MSEs, with 4% from SC/ST MSEs and 3% from women-owned MSEs",
    "25% from MSEs, with 3% SC/ST and 4% women-owned",
    "20% from MSEs, with 4% women-owned",
    "25% from start-ups only",
    "Central ministries and CPSEs must procure at least 25% from MSEs, with sub-targets of 4% (SC/ST) and 3% (women-owned).")
add(ESI, T, "GeM’s tiered buying, as shown on the infographic, uses direct purchase up to:",
    "₹25,000, with a higher band from ₹25,000 to ₹5 lakh, and bidding or reverse auction above ₹5 lakh",
    "₹10 lakh for all direct purchase",
    "₹5 lakh with no bidding above that",
    "₹25,000 only, and tenders for everything else with no middle band",
    "The infographic shows a tier up to ₹25,000, a ₹25,000-to-₹5 lakh band, and mandatory competitive bidding or reverse auction above ₹5 lakh.")
add(ESI, T, "SWAYATT on GeM expands to:",
    "Startups, Women and Youth Advantage Through e-Transactions",
    "Startups and Women Advantage Through Trade",
    "Single Window for Artisans and Youth in e-Trade",
    "Sustainable Women and Youth Access to Tenders",
    "SWAYATT is Startups, Women and Youth Advantage Through e-Transactions, shown with Womaniya on the GeM infographic.")

T = "Captive port policy"
add(ESI, T, "The revised captive policy approved by the Cabinet updates which earlier policy?",
    "The 2016 Captive Policy for port-dependent industries at major ports",
    "The 2016 Major Port Authorities Act itself",
    "The 2021 Maritime India Vision tariff policy",
    "The 2015 Sagarmala captive policy",
    "It revises the Policy for Award of Waterfront and Associated Land to Port Dependent Industries, updating the 2016 Captive Policy.")
add(ESI, T, "Existing PDI concessions can be extended for up to how long, without a fresh tender?",
    "30 years", "20 years", "50 years", "10 years",
    "Major Port Authorities can renew or extend them for up to 30 years without a fresh tender.")
add(ESI, T, "The renewed concession is charged at:",
    "The higher of the prevailing market rate and the indexed revenue under the existing agreement",
    "The lower of those two figures",
    "Always the old indexed revenue",
    "A flat notified royalty",
    "The charge is the prevailing market rate or the indexed revenue payable under the existing agreement, whichever is higher.")
add(ESI, T, "Existing captive users may expand by adding:",
    "Berths, jetties, terminals and Single Buoy Moorings",
    "Only additional storage tanks",
    "Shipyards and naval bases",
    "Inland waterway terminals away from the port",
    "Expansion covers additional berths, jetties, terminals and SBMs.")
add(ESI, T, "For additional capacity, the existing concessionaire gets:",
    "A Right of First Refusal to match the highest bid, and only PDIs with the same cargo profile may bid",
    "An automatic allotment at the old rate",
    "A right to veto all bids",
    "A RoFR open to any industry",
    "Price is set by competitive bidding. The existing concessionaire may match the highest bid. Only eligible PDIs with the same cargo profile can participate.")
add(ESI, T, "A newly added berth’s concession period will be:",
    "Co-terminus with the maximum permissible period of the existing facility",
    "A fresh 30 years from the expansion",
    "99 years",
    "Five years, renewable yearly",
    "It is co-terminus, so expansion cannot be used to obtain an unjustified extension.")
add(ESI, T, "For the first time, which entities can receive waterfront without competitive bidding?",
    "Eligible government entities, at the notified floor price",
    "Any PDI, at market price",
    "Foreign terminal operators",
    "Only the Indian Navy",
    "Eligible government entities — departments, statutory authorities, autonomous bodies, Central and State PSUs and government-controlled JVs — can receive waterfront without bidding, in sectors such as fertilisers, food, petroleum, oil and gas, coal and steel, among others notified by MoPSW.")
add(ESI, T, "Under the 2016 policy, a PDI had to depend on the major port for at least what share of the facility’s designed capacity?",
    "70% of designed capacity, for captive cargo",
    "50%", "90%", "100%",
    "A PDI was linked to dependence on that Major Port for import or export of at least 70% of the designed capacity of the proposed facility.")
add(ESI, T, "As of 2026, India has how many notified Major Ports, of which how many are operational?",
    "14 notified, 12 operational", "13 notified, 12 operational", "12 notified, 12 operational", "14 notified, 14 operational",
    "There are 14 notified Major Ports, of which 12 are operational.")
add(ESI, T, "The two newer notified Major Ports are:",
    "Vadhavan in Maharashtra and Galathea Bay in Andaman & Nicobar Islands",
    "Vadhavan and Vizhinjam",
    "Galathea Bay and Dugarajapatnam",
    "Vadhavan and Tajpur",
    "They are Vadhavan Port, Maharashtra, and Galathea Bay Port, Andaman & Nicobar Islands.")
add(ESI, T, "The three recognised Green Hydrogen Port Hubs are:",
    "Deendayal, V.O. Chidambaranar and Paradip",
    "Kandla, Mundra and Paradip",
    "Deendayal, JNPA and Chennai",
    "VOC, Kamarajar and Vizag",
    "Under the National Green Hydrogen Mission they are Deendayal (Gujarat), V.O. Chidambaranar (Tamil Nadu) and Paradip (Odisha).")

T = "Tax devolution"
add(ESI, T, "The additional tax-devolution instalment released on 1 August 2026 was:",
    "₹1,09,019 crore", "₹1,90,019 crore", "₹1,09,190 crore", "₹10,919 crore",
    "The advance instalment was ₹1,09,019 crore, over and above the normal monthly devolution due on 10 August 2026.")
add(ESI, T, "Among states, the highest share of this additional devolution went to:",
    "Uttar Pradesh", "Bihar", "Maharashtra", "Madhya Pradesh",
    "Uttar Pradesh was highest, followed in the list by Bihar, Madhya Pradesh, West Bengal, Maharashtra and Rajasthan.")
add(ESI, T, "Tax devolution between the Union and the States is framed by which Article, and the sharing formula is recommended under which Article?",
    "Article 270 for distribution; Article 280 for the Finance Commission",
    "Article 280 for distribution; Article 270 for the Finance Commission",
    "Article 275 and Article 282",
    "Article 246 and Article 280",
    "Article 270 provides the framework. The Finance Commission under Article 280 recommends the collective state share and its inter-state distribution.")

T = "Bankers’ Books Evidence Bill"
add(ESI, T, "The Bankers’ Books Evidence Bill, 2026 seeks to replace which law?",
    "The Bankers’ Books Evidence Act, 1891",
    "The Bankers’ Books Evidence Act, 1934",
    "The Indian Evidence Act, 1872, entirely",
    "FEMA, 1999",
    "Finance Minister Nirmala Sitharaman introduced it in the Lok Sabha to repeal and replace the 1891 Act.")
add(ESI, T, "The Bill expressly recognises which records as bankers’ books?",
    "Electronic, digital, virtual and cloud-based records",
    "Only scanned PDFs of paper ledgers",
    "Only records stored in India, not on the cloud",
    "Only CBS printouts signed in ink",
    "It recognises electronic, digital, virtual and cloud-based banking records.")
add(ESI, T, "Bank records may be certified using:",
    "Manual, digital or electronic signatures",
    "Only a digital signature certificate",
    "Only the branch manager’s ink signature",
    "A blockchain hash alone",
    "Certification may use manual, digital or electronic signatures. Certified digital copies can be evidence, subject to authentication and integrity safeguards.")
add(ESI, T, "If a bank is not a party to a case, its officers generally need not appear unless:",
    "The court records a special cause, such as doubt about accuracy, authenticity or integrity",
    "Either party simply asks for the manager",
    "The amount exceeds ₹1 crore",
    "The record is more than three years old",
    "Officers generally need not appear or produce originals unless the court records a special cause of that kind.")
add(ESI, T, "The Central Government may, by notification:",
    "Extend the law to other financial-sector entities",
    "Exempt all private banks",
    "Apply it only to nationalised banks",
    "Repeal FEMA",
    "The Centre may extend the law to other financial-sector entities through notification.")

T = "NICDP"
add(ESI, T, "How many industrial nodes or projects have been approved under NICDP?",
    "20", "12", "14", "24",
    "The Ministry of Commerce and Industry told the Lok Sabha that 20 nodes/projects have been approved.")
add(ESI, T, "NICDP townships are developed through SPVs in which the State and the Centre respectively provide:",
    "Land from the State; equity and/or debt from the Government of India",
    "Equity from the State; land from the Centre",
    "Both land and equity from the Centre",
    "Only viability-gap grants, with private land",
    "SPVs are jointly formed. States provide land; the Centre provides financial support through equity and/or debt.")
add(ESI, T, "The normal construction period of an industrial node is:",
    "36–48 months from appointment of the EPC contractor",
    "24–36 months from Cabinet approval",
    "60 months from land acquisition",
    "18–24 months from EPC appointment",
    "It is around 36–48 months from appointment of the EPC contractor. Internal infrastructure is built through EPC; external connectivity uses the PM GatiShakti National Master Plan.")
add(ESI, T, "Which four industrial nodes are listed as completed?",
    "Dholera (Gujarat), Shendra-Bidkin (Maharashtra), Greater Noida (UP) and Vikram Udyogpuri (MP)",
    "Dholera, Shendra-Bidkin, Sri City and Tumakuru",
    "Dholera, Pitampura, Greater Noida and Vikram Udyogpuri",
    "Sanand, Shendra-Bidkin, Noida and Indore",
    "They are Dholera SIR, Shendra-Bidkin Industrial Area, the Integrated Industrial Township at Greater Noida, and Vikram Udyogpuri in Madhya Pradesh.")
add(ESI, T, "NICDP was created in December 2016 by expanding and renaming:",
    "The DMIC Project Implementation Trust Fund",
    "The Sagarmala Development Company",
    "The National Industrial Corridor Authority of 2007",
    "Invest India",
    "It expanded and renamed the earlier DMIC Project Implementation Trust Fund in December 2016.")

T = "Corporate Laws Amendment Bill 2026"
add(ESI, T, "The Joint Parliamentary Committee reported on the Corporate Laws (Amendment) Bill, 2026 on:",
    "3 August 2026", "4 August 2026", "1 August 2026", "31 July 2026",
    "The JPC submitted its report on 3 August 2026, broadly supporting the reforms with investor safeguards.")
add(ESI, T, "Proposed small-company thresholds for paid-up capital and turnover move to:",
    "₹20 crore and ₹200 crore, from ₹10 crore and ₹100 crore",
    "₹10 crore and ₹200 crore",
    "₹25 crore and ₹100 crore",
    "₹20 crore and ₹100 crore",
    "Paid-up capital would rise from up to ₹10 crore to ₹20 crore, and turnover from ₹100 crore to ₹200 crore.")
add(ESI, T, "The CSR net-profit threshold and the CSR-committee threshold are proposed to move to:",
    "₹10 crore net profit, and ₹1 crore CSR obligation",
    "₹5 crore net profit, and ₹1 crore obligation",
    "₹10 crore net profit, and ₹50 lakh obligation",
    "₹20 crore net profit, and ₹1 crore obligation",
    "CSR would apply at net profit of ₹10 crore or more, up from ₹5 crore. A separate CSR committee would be needed when the obligation exceeds ₹1 crore, up from ₹50 lakh.")
add(ESI, T, "Transfer of unspent CSR for ongoing projects is proposed to move from:",
    "30 days to 90 days", "90 days to 30 days", "30 days to 60 days", "15 days to 45 days",
    "The period is proposed to increase from 30 days to 90 days.")
add(ESI, T, "Fast-track merger shareholder approval is proposed to move from about 90% to:",
    "75%", "66%", "51%", "100%",
    "A 75% approval framework is proposed, from around 90%.")
add(ESI, T, "On AGMs, the Bill proposes:",
    "Virtual or audio-visual AGMs, but a physical AGM at least once every three years",
    "Fully virtual AGMs with no physical meeting required",
    "Physical AGMs only",
    "A physical AGM every year plus an optional virtual one",
    "Virtual/AV AGMs would be permitted, with a physical AGM at least once every three years.")
add(ESI, T, "NFRA’s powers are proposed to expand to include:",
    "Advisories, censures and warnings",
    "The power to wind up companies",
    "Criminal prosecution as the only new tool",
    "Setting the CSR threshold",
    "Powers would expand to include advisories, censures and warnings, beyond existing oversight.")
add(ESI, T, "Who is proposed as the Valuation Authority?",
    "IBBI", "NFRA", "SEBI", "ICA",
    "IBBI is proposed as the Valuation Authority, in place of the existing registered-valuer framework under the Companies Act alone.")
add(ESI, T, "Employee stock-linked benefits would expressly recognise:",
    "RSUs and Stock Appreciation Rights, besides traditional ESOPs",
    "Only traditional ESOPs",
    "Phantom stock but not RSUs",
    "Sweat equity only",
    "Explicit recognition is proposed for RSUs and SARs.")
add(ESI, T, "IFSC companies and LLPs would be permitted to:",
    "Maintain specified capital or contributions in permitted foreign currency",
    "Skip statutory audit",
    "Keep capital only in INR",
    "List only on domestic exchanges",
    "They may maintain specified capital or contributions in a permitted foreign currency.")
add(ESI, T, "Certain trusts may convert into LLPs if they are regulated by:",
    "SEBI or IFSCA, subject to investor approval",
    "RBI only",
    "The Charity Commissioner",
    "State stamp authorities",
    "Certain SEBI/IFSCA-regulated trusts may convert into LLPs, subject to investor approval. There was no broad enabling framework earlier.")

T = "Antariksh Venture Capital Fund"
add(ESI, T, "AVCF received SEBI approval on, and is what kind of fund?",
    "31 October 2025; a Category II Alternative Investment Fund",
    "31 October 2024; a Category I AIF",
    "31 October 2025; a Category III AIF",
    "November 2025; a mutual fund",
    "It is operational after SEBI approval on 31 October 2025 as a Category II AIF for Indian space-tech start-ups.")
add(ESI, T, "The Cabinet approved AVCF at what size, and the committed corpus after the November 2025 closing was:",
    "₹1,000 crore approved in October 2024; corpus ₹1,005 crore",
    "₹1,005 crore approved; corpus ₹1,000 crore",
    "₹10,000 crore approved; corpus ₹1,005 crore",
    "₹1,000 crore approved in 2025; corpus ₹1,500 crore",
    "The Union Cabinet approved a ₹1,000 crore fund in October 2024. After the initial closing in November 2025 the committed corpus was ₹1,005 crore.")
add(ESI, T, "AVCF is managed by, and supported in government by:",
    "SIDBI Venture Capital Limited, with IN-SPACe as the key government institution",
    "NSIC, with ISRO",
    "SIDBI itself as a bank, with NSIL",
    "NIIF, with IN-SPACe",
    "SVCL manages the fund. IN-SPACe is the key government institution.")
add(ESI, T, "Indicative investment per start-up, and the two stage bands, are:",
    "₹10–60 crore overall; ₹10–30 crore growth and ₹30–60 crore late-growth",
    "₹10–30 crore overall",
    "₹30–60 crore for every stage",
    "₹1–10 crore seed and ₹10–60 crore growth",
    "The indicative range is ₹10–60 crore: growth stage ₹10–30 crore and late-growth ₹30–60 crore. The fund was designed to support about 40 space start-ups.")

T = "Source from India"
add(ESI, T, "DGFT opened the “Source from India” feature to whom?",
    "DPIIT-recognised start-ups",
    "All GST-registered firms",
    "Only exporters with three years of shipping bills",
    "Only MSMEs with Udyam, not start-ups",
    "DPIIT-recognised start-ups can use Source from India on the Trade Connect ePlatform.")
add(ESI, T, "Eligible start-ups on Source from India are marked with:",
    "A Start-up Badge", "A GI tag", "An IEC gold mark", "A GeM verified tick",
    "They get a special Start-up Badge and can create digital microsites for global buyers.")
add(ESI, T, "Early-stage start-ups may join even without normal export performance if they have:",
    "An active IEC that is not on DGFT’s Denied Entity List",
    "A minimum export of ₹1 crore",
    "An AD Category I licence",
    "Three years of income-tax returns only",
    "They need an active Importer Exporter Code not on the DEL. Eligibility is checked on the DGFT database.")
add(ESI, T, "After GST, an IEC corresponds to which number, though it is still activated by DGFT?",
    "The firm’s PAN", "The GSTIN only, with no PAN link", "The CIN", "The Udyam number",
    "The IEC issued to a firm corresponds to its PAN, but is still separately issued or activated through DGFT.")
add(ESI, T, "Under the revised 2026 start-up recognition framework, the normal turnover ceiling rose from:",
    "₹100 crore to ₹200 crore", "₹50 crore to ₹100 crore", "₹100 crore to ₹300 crore for every start-up", "₹200 crore to ₹300 crore",
    "The normal ceiling increased from ₹100 crore to ₹200 crore. A Deep Tech category allows age up to 20 years and turnover up to ₹300 crore.")
add(ESI, T, "Trade Connect ePlatform was launched on:",
    "11 September 2024", "11 September 2023", "9 August 2016", "26 August 2021",
    "It was launched on 11 September 2024 by the Ministry of Commerce and Industry. It links exporters with Indian Missions, EPCs, the Department of Commerce, DGFT, EXIM Bank and other trade bodies. DPIIT is under the Ministry of Commerce and Industry.")

T = "NUDGE"
add(ESI, T, "The Income Tax Department’s NUDGE campaign led to about how many revised or updated returns?",
    "1.25 crore returns in FY 2024-25 and FY 2025-26",
    "1.25 lakh returns in one year",
    "25 lakh returns over two years",
    "1.25 crore returns in FY 2025-26 alone",
    "Around 1.25 crore taxpayers filed revised or updated ITRs during those two financial years.")
add(ESI, T, "Additional tax from the NUDGE corrections was about:",
    "₹9,494 crore", "₹94,940 crore", "₹4,949 crore", "₹9,494 lakh",
    "The corrections generated around ₹9,494 crore in additional tax.")
add(ESI, T, "NUDGE, run by CBDT, works by:",
    "Alerting taxpayers by SMS or email about mismatches and inviting voluntary correction before enforcement",
    "Issuing prosecution notices as the first step",
    "Auto-revising returns without informing the taxpayer",
    "Only matching TDS, with no communication",
    "It is a non-intrusive, technology-based approach. Major discrepancies include non-reporting of income or assets and incorrect or excessive deductions.")

T = "Anti-dumping and WTO"
add(ESI, T, "A fresh five-year anti-dumping duty was imposed on:",
    "Low Ash Metallurgical Coke from six nations",
    "Normal Butanol from six nations, as a fresh duty",
    "Untreated Fumed Silica, as a new product",
    "All steel products from China",
    "Duties were extended on Untreated Fumed Silica, Arylides, Seamless Tubes, Pipes and Profiles, and Normal Butanol. A fresh five-year duty was imposed on Low Ash Metallurgical Coke from six key nations.")
add(ESI, T, "ADD notifications are issued by, and investigations are done by:",
    "CBIC notifies and enforces; DGTR investigates",
    "DGTR both investigates and notifies the duty",
    "CBIC investigates; DGTR notifies",
    "WTO notifies; CBIC investigates",
    "DGTR in the Ministry of Commerce investigates. CBIC, in the Department of Revenue, notifies and enforces.")
add(ESI, T, "Anti-dumping duty in India is imposed in line with:",
    "Article VI of GATT 1994",
    "Article XX of GATT",
    "The TRIPS Agreement",
    "Article I of the WTO Agreement only",
    "It is imposed in compliance with Article VI of GATT 1994. ADD has a sunset clause of five years. Dumping itself is not illegal unless it causes or threatens material injury.")
add(ESI, T, "The WTO was established on, succeeding which agreement?",
    "1 January 1995, succeeding GATT 1947",
    "1 January 1994, succeeding GATT 1994",
    "15 April 1994, succeeding the ITO",
    "1 January 1995, succeeding the IMF articles",
    "The WTO was established on 1 January 1995. Its predecessor was GATT, 1947.")
add(ESI, T, "WTO headquarters, and its Director-General named in the magazine, are:",
    "Centre William Rappard, Geneva; Ngozi Okonjo-Iweala",
    "The Hague; Ngozi Okonjo-Iweala",
    "Geneva; Pascal Lamy",
    "Centre William Rappard; a Director-General from India",
    "HQ is Centre William Rappard, Geneva. Ngozi Okonjo-Iweala is the first woman and the first African to lead the WTO.")
add(ESI, T, "WTO membership, and India’s status, are stated as:",
    "166 members; India is a founding member of both GATT and the WTO",
    "164 members; India joined in 1995 but not GATT",
    "166 members; India is an observer",
    "125 members; India is a founder",
    "There are 166 members, representing over 98% of world trade. India is a founding member of GATT (1947) and the WTO (1995).")
add(ESI, T, "The WTO’s highest body, and how often it meets, is:",
    "The Ministerial Conference, at least once every two years",
    "The General Council, every year",
    "The Ministerial Conference, every year",
    "The Dispute Settlement Body, every two years",
    "The Ministerial Conference is the highest body and meets at least once every two years.")
add(ESI, T, "The General Council converts into which two bodies?",
    "The Dispute Settlement Body and the Trade Policy Review Body",
    "The Appellate Body and the Ministerial Conference",
    "The TPRB and the IMF board",
    "Only the Dispute Settlement Body",
    "It becomes the DSB for disputes and the TPRB to review national trade policies.")
add(ESI, T, "Which list matches the key WTO principles named in the magazine?",
    "MFN, national treatment, freer trade, predictability and transparency, and fair competition",
    "MFN, reciprocity, special and differential treatment only",
    "National treatment, TRIPS, TRIMS and GATS only",
    "MFN, quota freedom, and currency convertibility",
    "The five named principles are Most-Favoured Nation, National Treatment, Freer Trade, Predictability and Transparency, and Fair Competition.")

T = "Fiscal deficit Q1 FY27"
add(ESI, T, "India’s fiscal deficit in April–June 2026 was about:",
    "₹3.1 lakh crore, or 18.2% of the Budget Estimate",
    "₹2.8 lakh crore, or 18.2% of BE",
    "₹3.1 lakh crore, or 4.3% of GDP already in one quarter",
    "₹16.96 lakh crore",
    "It was about ₹3.1 lakh crore, 18.2% of the full-year BE, higher than about ₹2.8 lakh crore in Q1 FY26. Data are from the Controller General of Accounts.")
add(ESI, T, "The FY27 fiscal-deficit target is:",
    "₹16.96 lakh crore, equivalent to 4.3% of GDP",
    "₹16.96 lakh crore, or 3.1% of GDP",
    "₹12.22 lakh crore, or 4.3% of GDP",
    "₹3.1 lakh crore, or 4.3% of GDP",
    "The target is ₹16.96 lakh crore, 4.3% of GDP.")
add(ESI, T, "Net tax receipts and non-tax revenue in Q1 FY27 were about:",
    "₹6.4 lakh crore and ₹3.8 lakh crore",
    "₹5.4 lakh crore and ₹3.7 lakh crore",
    "₹6.4 lakh crore and ₹3.4 lakh crore",
    "₹3.8 lakh crore and ₹6.4 lakh crore",
    "Net tax receipts were about ₹6.4 lakh crore, up from ₹5.4 lakh crore. Non-tax revenue was about ₹3.8 lakh crore, against ₹3.7 lakh crore a year earlier.")
add(ESI, T, "Total expenditure and capital expenditure in Q1 FY27 were about:",
    "₹13.6 lakh crore total, and ₹3.4 lakh crore capex",
    "₹12.2 lakh crore total, and ₹2.75 lakh crore capex",
    "₹13.6 lakh crore total, and ₹2.75 lakh crore capex",
    "₹16.96 lakh crore total, and ₹3.4 lakh crore capex",
    "Total expenditure was about ₹13.6 lakh crore (₹12.2 lakh crore a year earlier). Capex was about ₹3.4 lakh crore, against ₹2.75 lakh crore.")
add(ESI, T, "Budgeted capital expenditure for FY27 is:",
    "₹12.22 lakh crore, or 3.1% of GDP",
    "₹12.22 lakh crore, or 4.3% of GDP",
    "₹16.96 lakh crore, or 3.1% of GDP",
    "₹3.4 lakh crore, or 3.1% of GDP",
    "FY27 budgeted capex is ₹12.22 lakh crore, equivalent to 3.1% of GDP.")

# ================= FINANCE =================
T = "Favara–UPI"
add(FIN, T, "Which Maldivian system went live with India’s UPI?",
    "Favara", "Faster Payments of Maldives", "MVR Pay", "Raast",
    "The Maldives Monetary Authority announced that Favara’s integration with UPI went live.")
add(FIN, T, "In the first phase, the Favara–UPI link allows:",
    "People in the Maldives to send money in real time to UPI accounts in India",
    "People in India to send money to any Favara wallet",
    "Two-way merchant payments at launch",
    "Only government transfers",
    "Individuals in the Maldives can send money in real time to UPI-enabled bank accounts in India.")
add(FIN, T, "A Favara–UPI transfer is initiated in, and credited in:",
    "Maldivian rufiyaa, credited in Indian rupees",
    "Indian rupees, credited in rufiyaa",
    "US dollars both ways",
    "Rufiyaa, credited in dirhams",
    "It is initiated in MVR and credited in INR.")
add(FIN, T, "The first-phase Maldivian banks on the corridor are:",
    "Bank of Maldives Plc and Maldives Islamic Bank Plc",
    "Bank of Maldives and State Bank of India, Malé",
    "Maldives Islamic Bank and HSBC Maldives",
    "Bank of Ceylon and Bank of Maldives",
    "The first phase started with Bank of Maldives Plc and Maldives Islamic Bank Plc.")
add(FIN, T, "The corridor was implemented through cooperation among:",
    "MMA, RBI and NPCI International Payments Limited",
    "MMA, RBI and SWIFT only",
    "Maldives Inland Revenue and NPCI",
    "SBI, MMA and Visa",
    "Cooperation was among the Maldives Monetary Authority, RBI, NIPL, participating banks and other stakeholders.")

T = "UPI MDR"
add(FIN, T, "The Taxation and Other Laws (Amendment) Bill, 2026 proposes to amend which section on payment charges?",
    "Section 10A of the Payment and Settlement Systems Act, 2007",
    "Section 10 of FEMA",
    "Section 269SU of the Income-tax Act only, with no PSS amendment",
    "Section 40 of RERA",
    "It proposes to amend Section 10A of the PSS Act, 2007, so the government can specify which electronic modes stay protected from transaction charges.")
add(FIN, T, "Has MDR been imposed on UPI?",
    "No. The Finance Minister said no MDR framework has been finalised and UPI stays free for consumers",
    "Yes, 0.30% from 1 August 2026",
    "Yes, but only on person-to-person transfers",
    "Yes, on all merchant transactions above ₹2,000",
    "No MDR has yet been imposed. Nirmala Sitharaman said no framework has been finalised and UPI will remain free for consumers.")
add(FIN, T, "Merchant Discount Rate is:",
    "A fee paid by a merchant for accepting a digital payment",
    "A fee paid by the customer to the merchant",
    "A tax withheld by the bank",
    "The interchange paid only by NPCI to the merchant",
    "MDR is paid by the merchant. It can compensate the acquiring bank, the payer’s bank, the payment aggregator or app, and the payment network.")
add(FIN, T, "The zero-MDR regime for specified UPI and RuPay debit-card transactions has operated since:",
    "1 January 2020", "1 January 2019", "1 August 2026", "1 July 2022",
    "Since 1 January 2020 those transactions have been under zero-MDR. Section 10A currently bars banks and system providers from charging persons making or receiving payments through specified electronic modes.")

T = "Taxation Bill 2026"
add(FIN, T, "The Taxation and Other Laws (Amendment) Bill, 2026 was introduced in the Lok Sabha on:",
    "4 August 2026, by Nirmala Sitharaman",
    "3 August 2026, by the JPC",
    "1 August 2026, by the Revenue Secretary",
    "9 August 2026, by the Finance Minister",
    "The Finance Minister introduced it on 4 August 2026.")
add(FIN, T, "Conditions for an overseas fund managed from India, without creating a taxable business connection, were cut from:",
    "13 conditions to 5", "10 conditions to 3", "13 conditions to 8", "5 conditions to 13",
    "They were simplified from 13 conditions to 5 key fund-level conditions.")
add(FIN, T, "Which earlier fund conditions were removed?",
    "Minimum 25 investors, maximum 10% by one investor, ₹100 crore average corpus, and maximum 25% in one entity",
    "Only the 25-investor rule",
    "A minimum corpus of ₹500 crore and a 49% single-investor cap",
    "The requirement of an Indian custodian only",
    "Removed requirements include minimum 25 investors, maximum 10% participation by one investor, minimum monthly average corpus of ₹100 crore, and maximum 25% in a single entity.")
add(FIN, T, "Foreign cloud companies using eligible Indian data centres:",
    "No longer need a separate Central Government notification for the existing tax exemption, and the operator may own or lease the facility",
    "Still need a notification, and must own the building",
    "Lose the exemption if they lease",
    "Are exempt only if the data stay outside India",
    "The separate notification is no longer required. An eligible operator can now own or lease the facility; earlier it had to be owned and operated by the Indian company.")
add(FIN, T, "The tax exemption for foreign companies supplying capital goods to Indian electronics contract manufacturers is extended to:",
    "2040-41, from 2030-31", "2035-36, from 2030-31", "2047-48, from 2030-31", "2030-31, unchanged",
    "It is extended from 2030-31 to 2040-41.")
add(FIN, T, "Tax exemption for components stored in bonded warehouses, and for rough diamonds in notified special zones, runs up to:",
    "31 March 2041 in both cases",
    "31 March 2031 for both",
    "31 March 2041 for diamonds and 2031 for components",
    "31 March 2026",
    "Both exemptions run up to 31 March 2041, the diamond one subject to prescribed conditions.")
add(FIN, T, "Eligible FIIs and the Bank for International Settlements are exempt from tax on interest and capital gains from specified government securities for income arising from:",
    "1 April 2026", "1 April 2025", "4 August 2026", "1 April 2041",
    "The Bill retains the ordinance provision for income arising from 1 April 2026.")

T = "AD Category II"
add(FIN, T, "Which firm received an expanded AD Category-II licence from the RBI?",
    "WSFx Global Pay Limited (GlobalPay)",
    "NPCI International",
    "Standard Chartered",
    "Bank of Maldives",
    "WSFx Global Pay Limited received the expanded licence under the FEMA (Authorised Persons) Regulations, 2026.")
add(FIN, T, "RBI authorises entities to deal in foreign exchange under which provision?",
    "Section 10 of FEMA, 1999",
    "Section 10A of the PSS Act",
    "Section 3 of FEMA",
    "Article 270",
    "Under Section 10 of FEMA, 1999, RBI can authorise specified entities. They are called Authorised Persons or Authorised Dealers.")
add(FIN, T, "An AD Category-I entity can undertake:",
    "All permissible current-account and capital-account transactions under FEMA",
    "Only non-trade current-account transactions",
    "Only trade up to ₹25 lakh",
    "Only the activities named in a one-page letter",
    "AD-I can undertake all permissible current- and capital-account transactions.")
add(FIN, T, "AD Category-II can undertake:",
    "Permissible non-trade current-account transactions except gifts and donations, plus foreign trade up to ₹25 lakh per transaction",
    "All capital-account transactions",
    "Gifts and donations only",
    "Trade of any size",
    "That is the AD-II permission. AD-III may do only what its RBI authorisation specifically permits.")
add(FIN, T, "Minimum net worth for an AD-II, and the forex-turnover floor for a non-bank AD-II, are:",
    "₹10 crore net worth, and ₹50 crore annual forex turnover",
    "₹25 crore net worth, and ₹50 crore turnover",
    "₹10 crore net worth, and ₹25 crore turnover",
    "₹50 crore net worth, and ₹10 crore turnover",
    "Minimum net worth for AD-II is ₹10 crore. Non-bank AD-II entities must generally maintain minimum annual forex turnover of ₹50 crore.")

T = "REIT and InvIT depository receipts"
add(FIN, T, "SEBI’s consultation paper proposes depository receipts for:",
    "REITs and publicly listed InvITs, but not privately listed InvITs",
    "All InvITs, including privately listed ones, and REITs",
    "Only REITs",
    "Only unlisted InvITs",
    "REITs and publicly listed InvITs could issue DRs. Privately listed InvITs would not.")
add(FIN, T, "A proposed DR would be:",
    "A foreign-currency instrument issued by a foreign depository against units held with a SEBI-registered domestic custodian",
    "A rupee instrument listed on NSE",
    "An ADR issued by the REIT trustee directly",
    "A masala bond",
    "It would be foreign-currency denominated, issued by a foreign depository, with underlying units kept with a SEBI-registered domestic custodian.")
add(FIN, T, "Who cannot hold these REIT/InvIT depository receipts?",
    "Residents of India and NRIs, including through beneficial ownership",
    "Only residents; NRIs may hold them",
    "Foreign portfolio investors",
    "Anyone except the sponsor",
    "Residents and NRIs cannot hold them, including through beneficial ownership.")
add(FIN, T, "A fresh issue of such DRs needs unitholder approval of:",
    "At least 75% of votes cast, unless the DRs are issued together with the initial listing",
    "At least 90% of votes cast in every case",
    "A simple majority of units, including at IPO",
    "SEBI approval only, with no unitholder vote",
    "At least 75% of votes cast must support a fresh issue. That vote is not required when DRs are issued simultaneously with the initial listing.")
add(FIN, T, "Units backing the depository receipts will be treated as:",
    "Non-public holding for the minimum public-unitholding test",
    "Public holding",
    "Sponsor locked-in units for three years automatically",
    "Outside the unitholding calculation",
    "They count as non-public. DR pricing cannot be lower than the price for the corresponding issue of units to domestic investors. Listing is only on specified international exchanges in permissible jurisdictions.")

# A few cross-box "which statement" items still grounded in single facts, to deepen large topics
T = "Commonwealth Games 2026"
add(OTH, T, "Arundhati Choudhary, who won boxing gold at Glasgow, represents which state and weight?",
    "Rajasthan, women’s 70 kg", "Haryana, women’s 70 kg", "Rajasthan, women’s 60 kg", "Assam, women’s 75 kg",
    "Arundhati Choudhary of Rajasthan won the women’s 70 kg boxing gold.")
add(OTH, T, "Which statement about Gulveer Singh is correct?",
    "He was the first Indian to win a CWG medal in the men’s 10,000 m",
    "He won the men’s 10,000 m gold",
    "He is from Haryana",
    "He won three medals at Glasgow",
    "Gulveer Singh (Uttar Pradesh) was the first Indian to medal in the men’s 10,000 m, then added 5,000 m bronze.")

T = "Nuclear Energy Mission"
add(PIB, T, "Imported reactors in the large-scale prong of the Nuclear Energy Mission are:",
    "Light Water Reactors at greenfield locations",
    "Pressurised Heavy Water Reactors imported from Russia only at Tarapur",
    "High-Temperature Gas-Cooled Reactors",
    "Fast breeder reactors at greenfield sites",
    "The large-scale prong pairs indigenous 700 MWe PHWRs with imported LWRs at greenfield locations.")

T = "22nd Commonwealth Table Tennis"
add(OTH, T, "India’s women’s team at the Commonwealth Table Tennis Championships included:",
    "Syndrela Das, Sreeja Akula, Yashaswini Ghorpade, Sutirtha Mukherjee and Swastika Ghosh",
    "Manika Batra, Sreeja Akula, Syndrela Das, Sutirtha Mukherjee and Archana Kamath",
    "Only Sreeja Akula and Syndrela Das",
    "Yashaswini Ghorpade and a Malaysian pairing",
    "The women’s team was Syndrela Das, Sreeja Akula, Yashaswini Ghorpade, Sutirtha Mukherjee and Swastika Ghosh. They beat Malaysia.")

print("TOTAL", len(qs))

# validate
seen = set()
problems = []
for i, item in enumerate(qs, 1):
    if item["q"] in seen:
        problems.append(f"dup q {i}: {item['q'][:80]}")
    seen.add(item["q"])
    opts = [item["a"], *item["d"]]
    if len(set(opts)) != 4:
        problems.append(f"opts {i}: {item['q'][:80]}")
    if not all(opts):
        problems.append(f"empty {i}")
    if len(item["d"]) != 3:
        problems.append(f"dlen {i}")
if problems:
    print("PROBLEMS", len(problems))
    for p in problems[:30]:
        print(p)
else:
    print("clean")

out = Path("/workspace/src/data/questions.json")
out.write_text(json.dumps(qs, ensure_ascii=False, indent=0))
print("bytes", out.stat().st_size)
