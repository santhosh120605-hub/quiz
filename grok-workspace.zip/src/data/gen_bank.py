#!/usr/bin/env python3
"""Authoritative MCQ bank for 1–7 August 2026 current affairs (GA, ESI, Finance)."""
import json
from pathlib import Path

qs = []

def add(s, t, q, a, d1, d2, d3, w):
    qs.append({"s": s, "t": t, "q": q, "a": a, "d": [d1, d2, d3], "w": w})

PIB = "GA · PIB"
OTH = "GA · Other"
ESI = "GA + ESI"
FIN = "GA + Finance"

# ---------- PIB · FIRST IN NEWS ----------
T = "First in news · GSI"
add(PIB, T, "Who became the first woman to head the Geological Survey of India in its 176-year history?",
    "Varsha Ashok Aglawe", "Varsha Ashok Agrawal", "Annapurni Subramaniam", "Bhawana Kanth",
    "Varsha Ashok Aglawe assumed charge as the 54th Director General of the Kolkata-based GSI.")
add(PIB, T, "Varsha Ashok Aglawe took charge as which numbered Director General of the GSI?",
    "54th Director General", "51st Director General", "45th Director General", "60th Director General",
    "She is the 54th DG of the Geological Survey of India.")
add(PIB, T, "Whom did Varsha Ashok Aglawe succeed as Director General of the GSI?",
    "Asit Saha", "Ajit Doval", "Asit Sharma", "Anil Saha",
    "Varsha Aglawe succeeded Asit Saha.")
add(PIB, T, "The Geological Survey of India, whose first woman DG took charge, is based in which city?",
    "Kolkata", "Hyderabad", "New Delhi", "Dehradun",
    "GSI is described as the Kolkata-based Geological Survey of India.")

T = "First in news · heart by train"
add(PIB, T, "India’s first live donor heart transported by train travelled between which cities?",
    "Surat to Ahmedabad", "Ahmedabad to Surat", "Mumbai to Ahmedabad", "Surat to Gandhinagar only",
    "The organ was transported from Surat to Ahmedabad.")
add(PIB, T, "The live donor heart was carried aboard which train?",
    "Mumbai Central–Gandhinagar Capital Vande Bharat Express",
    "Mumbai Central–Ahmedabad Shatabdi Express",
    "Surat–Ahmedabad Vande Bharat Express",
    "Gandhinagar Capital–New Delhi Vande Bharat Express",
    "It travelled on the Mumbai Central–Gandhinagar Capital Vande Bharat Express.")
add(PIB, T, "The heart transported by train was taken for transplant to which hospital?",
    "U.N. Mehta Institute of Cardiology & Research Centre, Ahmedabad",
    "AIIMS New Delhi",
    "PGIMER Chandigarh",
    "UN Mehta Institute, Surat",
    "It reached the U.N. Mehta Institute of Cardiology & Research Centre in Ahmedabad.")

T = "First in news · pigeonpea genome"
add(PIB, T, "India’s first fully annotated telomere-to-telomere reference genome of pigeonpea was developed by which organisation?",
    "Indian Council of Agricultural Research (ICAR)",
    "Council of Scientific and Industrial Research (CSIR)",
    "Department of Biotechnology alone",
    "Indian Council of Medical Research",
    "The T2T pigeonpea genome was developed by ICAR.")
add(PIB, T, "The T2T reference genome was developed for which pigeonpea variety?",
    "Asha (Cajanus cajan)", "Arhar-101", "Pusa Tur-16", "Malviya Asha",
    "It was developed for variety ‘Asha’ (Cajanus cajan), also called Arhar or Tur.")
add(PIB, T, "Which institute achieved the pigeonpea telomere-to-telomere breakthrough?",
    "ICAR-National Institute for Plant Biotechnology, New Delhi",
    "ICAR-National Institute of High Security Animal Diseases",
    "CSIR-National Botanical Research Institute",
    "ICAR-Indian Agricultural Research Institute, Karnal",
    "The work was done by ICAR-NIPB, New Delhi.")
add(PIB, T, "The ICAR pigeonpea sequence was approved as what?",
    "The global reference genome of pigeonpea",
    "A draft genome only for Indian breeders",
    "The global reference genome of chickpea",
    "A regional reference for Asia, not a global one",
    "The sequence has been approved as the global reference genome of pigeonpea.")
add(PIB, T, "In 2011, ICAR-NIPB published which milestone using pigeonpea variety Asha?",
    "The world’s first draft genome of a pulse crop",
    "The world’s first T2T genome of a pulse crop",
    "The world’s first draft genome of wheat",
    "India’s first animal vaccine genome",
    "In 2011 ICAR-NIPB published the world’s first draft genome of a pulse crop, using Asha.")
add(PIB, T, "The 2011 pigeonpea genome is also remembered as which first?",
    "The first crop genome sequenced entirely in India",
    "The first crop genome sequenced entirely in Asia",
    "The first animal genome sequenced entirely in India",
    "The first pulse genome sequenced outside India",
    "It was the first crop genome sequenced entirely in India; an improved version came out in 2017.")
add(PIB, T, "An improved version of the 2011 pigeonpea genome was subsequently published in which year?",
    "2017", "2014", "2019", "2021",
    "An improved version was published in 2017.")

T = "First in news · ASF vaccine"
add(PIB, T, "India’s first indigenous African Swine Fever vaccine for pigs was developed by which institute?",
    "ICAR-NIHSAD", "ICAR-NIPB", "ICAR-IVRI, Izatnagar only", "CSIR-CDRI",
    "It was developed by ICAR-National Institute of High Security Animal Diseases (ICAR-NIHSAD).")
add(PIB, T, "The indigenous African Swine Fever vaccine is based on which platform?",
    "An MA-104 cell line-based live attenuated vaccine",
    "An inactivated whole-virus vaccine on Vero cells",
    "An mRNA vaccine against Genotype I",
    "A DNA vaccine against Genotype IV",
    "It is an MA-104 cell line-based live attenuated vaccine against ASFV Genotype II.")
add(PIB, T, "The indigenous ASF vaccine targets which virus genotype?",
    "African Swine Fever Virus Genotype II",
    "African Swine Fever Virus Genotype I",
    "Classical Swine Fever Virus Genotype II",
    "African Swine Fever Virus Genotype IV",
    "The vaccine was developed against ASFV Genotype II.")

# ---------- GOVERNMENT INITIATIVES ----------
T = "Global Live Events Leadership"
add(PIB, T, "The Live Events Development Cell (LEDC) was constituted in which month and year?",
    "July 2025", "July 2024", "January 2026", "August 2026",
    "LEDC was constituted in July 2025.")
add(PIB, T, "LEDC is chaired by whom?",
    "Secretary, Ministry of Information and Broadcasting",
    "Secretary, Ministry of Culture",
    "Minister of Tourism",
    "CEO, NITI Aayog",
    "LEDC is chaired by the Secretary, Ministry of Information and Broadcasting.")
add(PIB, T, "LEDC aims to position India as a global hub for live events by which year?",
    "2030", "2028", "2035", "2047",
    "The aim is to position India as a global hub for live events by 2030.")

T = "Multi-Lane Free Flow Tolling"
add(PIB, T, "NHAI launched the Multi-Lane Free Flow tolling system at which toll plaza?",
    "Shahjahanpur Toll Plaza", "Daulatpura Toll Plaza", "Manoharpura Toll Plaza", "Shahpura Toll Plaza",
    "MLFF was launched at Shahjahanpur Toll Plaza.")
add(PIB, T, "Shahjahanpur became the third barrier-free toll plaza on the Delhi–Jaipur stretch after which two plazas?",
    "Daulatpura and Manoharpura", "Manoharpur and Shahpura", "Daulatabad and Manoharpur", "Kherki Daula and Shahjahanpur",
    "It followed Daulatpura and Manoharpura.")
add(PIB, T, "The MLFF plazas mentioned lie on which highway section?",
    "Delhi–Jaipur section of NH-48 in Rajasthan",
    "Delhi–Jaipur section of NH-44 in Haryana",
    "Delhi–Agra section of NH-48 in Rajasthan",
    "Jaipur–Ahmedabad section of NH-48",
    "They are on the busy Delhi–Jaipur section of NH-48 in Rajasthan.")
add(PIB, T, "MLFF combines which two technologies?",
    "ANPR and FASTag-based electronic toll collection",
    "RFID gantries and GPS-only tolling",
    "ANPR and cash lanes",
    "FASTag and manual boom barriers only",
    "The system combines Automatic Number Plate Recognition with FASTag-based ETC.")

T = "e-Zero FIR System"
add(PIB, T, "How many e-Zero FIRs had been registered since rollout, as stated in the magazine?",
    "12,257", "12,027", "10,257", "15,115",
    "More than 12,000 e-Zero FIRs — specifically 12,257 — had been registered.")
add(PIB, T, "e-Zero FIRs had been registered across how many States and Union Territories?",
    "18", "12", "22", "28",
    "They were registered across 18 States and UTs.")
add(PIB, T, "Which State/UT topped e-Zero FIR registrations, and with how many?",
    "Delhi with 6,115", "Delhi with 4,174", "Chandigarh with 6,115", "Maharashtra with 6,115",
    "Delhi topped the list with 6,115 e-Zero FIRs.")
add(PIB, T, "Which UT followed Delhi in e-Zero FIR numbers?",
    "Chandigarh with 4,174", "Chandigarh with 6,115", "Puducherry with 4,174", "Ladakh with 2,174",
    "Chandigarh followed with 4,174.")
add(PIB, T, "e-Zero FIR is led by which body?",
    "Indian Cybercrime Coordination Centre (I4C) under MHA",
    "CERT-In under MeitY",
    "National Crime Records Bureau alone",
    "CBI’s Economic Offences Wing",
    "It is led by I4C under the Ministry of Home Affairs.")
add(PIB, T, "e-Zero FIR was first implemented in which place and when?",
    "Delhi in May 2025", "Delhi in May 2024", "Chandigarh in May 2025", "Mumbai in August 2025",
    "It was first implemented in Delhi in May 2025.")
add(PIB, T, "Complaints that can auto-generate an e-Zero FIR are reported through which channels?",
    "National Cyber Crime Reporting Portal or helpline 1930",
    "Dial 112 or the e-Courts portal",
    "Helpline 1930 only, not NCRP",
    "Cyber Dost app or helpline 1098",
    "They are reported through NCRP or helpline 1930, if they meet the State/UT financial-loss threshold.")

T = "SoFTeL scheme"
add(PIB, T, "SoFTeL is an initiative of which authority?",
    "Food Safety and Standards Authority of India",
    "Food Corporation of India",
    "Bureau of Indian Standards",
    "Ministry of Health alone, outside FSSAI",
    "SoFTeL is an initiative of FSSAI.")
add(PIB, T, "What does SoFTeL expand to?",
    "Strengthening of Food Testing System in the Country including Mobile Food Testing Labs",
    "Safe Food Testing and Labelling scheme of FSSAI",
    "Standardisation of Food Technology Laboratories",
    "Strengthening of Forensic Testing Labs",
    "SoFTeL is Strengthening of Food Testing System in the Country including provision of Mobile Food Testing Labs.")
add(PIB, T, "Under SoFTeL, how many State Food Testing Laboratories have been structurally upgraded?",
    "47", "37", "57", "27",
    "47 State Food Testing Laboratories have been upgraded with advanced analytical equipment.")
add(PIB, T, "The stated objective of SoFTeL includes which of the following?",
    "Upgrading state food labs, setting up microbiology facilities, and deploying mobile food testing vans",
    "Only building a central lab in Ghaziabad",
    "Replacing FSSAI with state-only regulators",
    "Certifying restaurants, not laboratories",
    "The objective is to upgrade state food labs, set up microbiology facilities and deploy mobile vans.")

# ---------- SUMMITS ----------
T = "GI & Beyond 2.0 Summit"
add(PIB, T, "Where was the GI & Beyond 2.0 Summit held?",
    "New Delhi", "Varanasi", "Jaipur", "Chennai",
    "The summit was held at New Delhi.")
add(PIB, T, "GI & Beyond 2.0 was organised by the Office of the DC (Handlooms) in association with which body?",
    "Handloom Export Promotion Council (HEPC)",
    "Handicrafts and Handlooms Export Corporation",
    "Export Promotion Council for Handicrafts",
    "India Brand Equity Foundation",
    "It was organised with the Handloom Export Promotion Council.")
add(PIB, T, "Which platform was launched at GI & Beyond 2.0 with the tagline “One Platform. Endless Markets”?",
    "Digital Handloom Atlas", "Handloom e-Vidya", "India Handmade Portal", "GeM Handloom",
    "The Digital Handloom Atlas was launched with that tagline.")
add(PIB, T, "The Digital Handloom Atlas is meant to do what?",
    "Showcase Indian handloom products, including GI products, and connect artisans with global markets",
    "Replace GI registration with a private marketplace",
    "Map only powerloom clusters in Tamil Nadu",
    "Sell handloom yarn to mills",
    "It aims to showcase handloom products, including GI products, and connect artisans with global markets.")
add(PIB, T, "Which logo was also unveiled at the GI & Beyond 2.0 Summit?",
    "Diamond Jubilee Logo of HEPC",
    "Golden Jubilee Logo of the Ministry of Textiles",
    "Diamond Jubilee Logo of NHDP",
    "GI India logo of DPIIT",
    "The Diamond Jubilee Logo of the Handloom Export Promotion Council was unveiled.")

T = "3rd India International FinTech Festival"
add(PIB, T, "The 3rd India International FinTech Festival was organised by which chamber?",
    "ASSOCHAM", "FICCI", "CII", "NASSCOM",
    "It was organised by the Associated Chambers of Commerce & Industry of India.")
add(PIB, T, "The 3rd India International FinTech Festival was held in which city?",
    "New Delhi", "Mumbai", "Gandhinagar", "Bengaluru",
    "The festival was held in New Delhi.")
add(PIB, T, "What was the theme of the 3rd India International FinTech Festival?",
    "FinTech: Building Profitable, Scalable and Trusted Digital Finance for India’s Next Phase of Economic Growth",
    "FinTech: Inclusion, UPI and the Next Billion Users",
    "Digital Finance for a Viksit Bharat by 2047",
    "Building Cross-Border Payments for the Global South",
    "The theme is the long ‘Profitable, Scalable and Trusted Digital Finance’ formulation.")

# ---------- PIB MOUs ----------
T = "MoTA & CSIR-NBRI"
add(PIB, T, "The MoU between the Ministry of Tribal Affairs and CSIR-NBRI focuses on which plants?",
    "Rare, Endangered and Threatened medicinal plant species",
    "Only commercially grown aromatic crops",
    "Marine algae along the tribal coasts",
    "High-yielding food-grain varieties",
    "The partnership focuses on conservation of RET medicinal plant species.")
add(PIB, T, "CSIR-NBRI in the tribal bioresources MoU stands for which institute?",
    "CSIR-National Botanical Research Institute",
    "CSIR-National Botanical Resource Institute",
    "CSIR-National Bureau of Plant Genetic Resources",
    "CSIR-National Institute of Science Communication",
    "NBRI is the CSIR-National Botanical Research Institute.")

T = "C-DOT CoE at IISc"
add(PIB, T, "A C-DOT Centre of Excellence was established at which campus under the new MoU?",
    "FSID, IISc Bengaluru", "IIT Madras Research Park", "IIIT Hyderabad", "IIT Roorkee",
    "A C-DOT CoE has been established at FSID, IISc Bengaluru.")
add(PIB, T, "With the IISc Bengaluru centre, how many Centres of Excellence has C-DOT established?",
    "Five", "Three", "Four", "Six",
    "C-DOT has now established five Centres of Excellence.")
add(PIB, T, "The four earlier C-DOT CoE collaborations named in the magazine are with which institutes?",
    "IIIT Hyderabad, IIIT Kanpur, IIIT Gandhinagar and IIIT Roorkee",
    "IIT Bombay, IIT Delhi, IIT Madras and IIT Kanpur",
    "IISc, IIIT Hyderabad, IIT Delhi and IIT Guwahati",
    "IIIT Hyderabad, NIT Trichy, IIIT Delhi and IIT Roorkee",
    "The magazine lists IIIT Hyderabad, IIIT Kanpur, IIIT Gandhinagar and IIIT Roorkee.")
add(PIB, T, "FSID in the C-DOT MoU expands to what?",
    "Foundation for Science Innovation and Development",
    "Forum for Scientific Innovation and Design",
    "Foundation for Space Innovation and Defence",
    "Federal School of Innovation and Design",
    "FSID is the Foundation for Science Innovation and Development.")

T = "Pawan Hans & Noemi"
add(PIB, T, "Pawan Hans Limited signed an MoU with which foreign firm?",
    "Noemi Aerospace (Elfly AS) of Norway",
    "Airbus Helicopters of France",
    "Embraer of Brazil",
    "Massivit of Israel",
    "The MoU is with Noemi Aerospace (Elfly AS), Norway.")
add(PIB, T, "The Pawan Hans–Noemi MoU explores collaboration in which area?",
    "Next-generation sustainable aviation, including electric seaplanes",
    "Military attack helicopters",
    "Airport retail concessions",
    "Drone skill centres",
    "The objective covers sustainable aviation technologies, including electric seaplane solutions.")

# ---------- SCIENCE PIB ----------
T = "Bharatiya Antariksh Station"
add(PIB, T, "Bharatiya Antariksh Station is planned as India’s first indigenous space station of how many modules?",
    "Five modules", "Three modules", "Seven modules", "Four modules",
    "BAS will comprise five modules.")
add(PIB, T, "BAS is targeted to be established by which year?",
    "2035", "2030", "2028", "2040",
    "The station is targeted by 2035.")
add(PIB, T, "The first module of Bharatiya Antariksh Station (BAS-01) is to be launched by which year?",
    "2028", "2026", "2030", "2035",
    "BAS-01 is to be launched by 2028.")

T = "Nuclear Energy Mission"
add(PIB, T, "The Nuclear Energy Mission was outlined in which Union Budget?",
    "Union Budget 2025-26", "Union Budget 2024-25", "Union Budget 2026-27", "Union Budget 2023-24",
    "NEM was outlined in the Union Budget 2025-26.")
add(PIB, T, "NEM seeks to expand India’s nuclear capacity from about 8.78 GW to how much, and by when?",
    "100 GW by 2047", "100 GW by 2035", "50 GW by 2047", "22 GW by 2047",
    "The objective is to expand from ~8.78 GW to 100 GW by 2047.")
add(PIB, T, "By when does NEM aim to operationalise at least five indigenous Small Modular Reactors?",
    "2033", "2030", "2035", "2047",
    "At least five indigenous SMRs are to be developed, tested and operationalised by 2033.")
add(PIB, T, "How much initial budgetary provision is allocated specifically for SMR research, development and deployment?",
    "₹20,000 crore", "₹10,000 crore", "₹25,000 crore", "₹2,000 crore",
    "₹20,000 crore is allocated for SMR R&D and deployment.")
add(PIB, T, "The 100 GW nuclear target is linked to which longer climate goal?",
    "India’s Net Zero emissions goal by 2070",
    "India’s Net Zero goal by 2050",
    "A 50% non-fossil target by 2030 only",
    "Coal phase-out by 2040",
    "The 100 GW target is considered important for achieving Net Zero by 2070.")
add(PIB, T, "Present nuclear capacity of about 8.78 GW is expected to reach about how much by 2031-32?",
    "About 22 GW", "About 32 GW", "About 12 GW", "About 50 GW",
    "It is expected to reach about 22 GW by 2031-32.")
add(PIB, T, "Beyond 2032, how much additional nuclear capacity is envisaged to be set up by NPCIL?",
    "Another 32 GW", "Another 22 GW", "Another 50 GW", "Another 8.78 GW",
    "Another 32 GW is envisaged to be set up beyond 2032 by NPCIL.")
add(PIB, T, "The large-scale prong of NEM relies on rapidly deploying which indigenous reactors?",
    "700 MWe Pressurised Heavy Water Reactors",
    "220 MWe Pressurised Water Reactors only",
    "500 MWe Light Water Reactors designed by BARC",
    "1000 MWe Fast Breeder Reactors",
    "Large-scale expansion means massive 700 MWe indigenous PHWRs, alongside imported LWRs.")
add(PIB, T, "BSMR-200, being engineered by BARC, has which capacity and site?",
    "220 MWe Pressurized Water Reactor at Tarapur, Maharashtra",
    "200 MWe PHWR at Kalpakkam, Tamil Nadu",
    "220 MWe PHWR at Kakrapar, Gujarat",
    "55 MWe reactor at Tarapur",
    "BSMR-200 (220 MWe) is an indigenous PWR slated for Tarapur, Maharashtra.")
add(PIB, T, "SMR-55 is approved for engineering and deployment at which site, and at what capacity?",
    "55 MWe at Tarapur", "55 MWe at Kudankulam", "200 MWe at Tarapur", "5 MWth at Tarapur",
    "SMR-55 is a 55 MWe compact design also approved for the Tarapur site.")
add(PIB, T, "HTGCR in the BARC demonstration set is primarily designed for what?",
    "Clean hydrogen generation, at 5 MWth",
    "Desalination, at 50 MWe",
    "Weapons-grade plutonium, at 5 MWe",
    "District heating, at 55 MWth",
    "HTGCR (5 MWth) is a High-Temperature Gas-Cooled Reactor designed primarily to support clean hydrogen generation.")
add(PIB, T, "What does the SHANTI Act, 2025 expand to?",
    "Sustainable Harnessing and Advancement of Nuclear Energy for Transforming India Act",
    "Strategic Harnessing and Atomic Nuclear Technology of India Act",
    "Safe Handling and Advancement of Nuclear Trade in India Act",
    "State-owned Harnessing of Atomic Energy Act",
    "SHANTI is the Sustainable Harnessing and Advancement of Nuclear Energy for Transforming India Act, 2025.")
add(PIB, T, "The SHANTI Act, 2025 was enacted by which ministry?",
    "Ministry of Law and Justice",
    "Ministry of Power",
    "Department of Atomic Energy alone, without a ministry of enactment named",
    "Ministry of New and Renewable Energy",
    "The magazine states the SHANTI Act, 2025 was enacted by the Ministry of Law and Justice.")
add(PIB, T, "What did the SHANTI Act, 2025 change about private participation?",
    "It enabled limited private participation under regulatory oversight",
    "It banned all private participation in nuclear energy",
    "It allowed unrestricted private ownership of strategic reactors",
    "It transferred all reactors to state governments",
    "The Act modernised the framework and enabled limited private participation under regulatory oversight.")
add(PIB, T, "India’s present installed nuclear capacity is stated as how much, from how many plants?",
    "8,780 MW from 24 nuclear power plants",
    "8,780 MW from 22 plants",
    "8,180 MW from 24 plants",
    "10,080 MW from 24 plants",
    "Installed capacity is 8,780 MW comprising 24 nuclear power plants.")
add(PIB, T, "Nuclear power’s share in total electricity generation in 2025-26 is given as about what?",
    "About 3.1%", "About 8.7%", "About 1.3%", "About 5.2%",
    "The 24 plants contributed about 3.1% in 2025-26.")
add(PIB, T, "The 500 MW Prototype Fast Breeder Reactor at Kalpakkam was commissioned by which entity?",
    "BHAVINI", "NPCIL", "BARC", "NTPC",
    "A 500 MW PFBR was commissioned by BHAVINI at Kalpakkam, Tamil Nadu.")
add(PIB, T, "Pre-project activities have been approved for which further fast breeder reactors?",
    "2 × 500 MW FBR 1 and 2 at Kalpakkam",
    "2 × 700 MW PHWR at Tarapur",
    "1 × 500 MW FBR at Kudankulam",
    "2 × 220 MW BSMR at Kalpakkam",
    "Government has approved pre-project activities of 2 × 500 MW FBR 1 & 2 at Kalpakkam.")

T = "ISRO collision avoidance"
add(PIB, T, "Satellites in which orbit are described as more vulnerable to collision because of a denser object population?",
    "Low Earth Orbit, less than 2000 km altitude",
    "Geostationary orbit, about 36,000 km",
    "Medium Earth Orbit only",
    "Lunar orbit",
    "LEO (less than 2000 km) is more vulnerable due to a denser space-object population.")
add(PIB, T, "Which body has formulated a policy framework on India’s liability for third-party damage by Indian space objects?",
    "IN-SPACe", "ISRO headquarters alone", "TRAI", "Department of Space’s AMD",
    "IN-SPACe formulated the framework; it is presently under consideration.")
add(PIB, T, "India announced the Debris Free Space Mission in which year?",
    "2024", "2022", "2025", "2019",
    "DFSM was announced in 2024.")
add(PIB, T, "Under DFSM, ISRO aims at what outcome?",
    "Zero debris from Indian space actors, government as well as private, in the foreseeable future",
    "Zero debris only from government launches by 2030",
    "Removal of all foreign debris in LEO",
    "A ban on private launches in LEO",
    "The aim is zero debris from Indian government and private space actors in the foreseeable future.")
add(PIB, T, "The Multi-Object Tracking Radar capable of tracking large LEO objects is located where?",
    "Sriharikota", "Hanle, Ladakh", "Mount Abu", "Bengaluru",
    "MOTR at Sriharikota can track large objects in Low Earth Orbit.")
add(PIB, T, "Under the NETRA project, an optical telescope is being established at which place?",
    "Hanle, Ladakh", "Sriharikota", "Leh town", "Ponmudi",
    "An optical telescope is being established at Hanle, Ladakh under NETRA.")
add(PIB, T, "The Hanle telescope under NETRA will track space objects of what size, and in which orbit?",
    "30 cm or larger at Geostationary Earth Orbit altitude",
    "10 cm or larger in Low Earth Orbit",
    "1 metre or larger at GEO",
    "30 cm or larger in Medium Earth Orbit only",
    "It will track objects of 30 cm or larger at GEO altitude.")
add(PIB, T, "NETRA expands to what?",
    "Network for Space Object Tracking and Analysis",
    "National Earth Tracking and Radar Array",
    "Network for Satellite Orbit and Trajectory Research",
    "National Experiment for Tracking Radio Astronomy",
    "NETRA is the Network for Space Object Tracking and Analysis Project.")

T = "U3O8 resources"
add(PIB, T, "AMD has established about how many tonnes of in-situ U3O8 resources?",
    "4,42,800 tonnes", "4,24,800 tonnes", "5,42,800 tonnes", "3,42,800 tonnes",
    "About 4,42,800 tonnes of in-situ U3O8 have been established.")
add(PIB, T, "Which organisation established the in-situ U3O8 uranium resource figure?",
    "Atomic Minerals Directorate for Exploration and Research",
    "Atomic Energy Regulatory Board",
    "Uranium Corporation of India",
    "Bhabha Atomic Research Centre",
    "The figure is from the Atomic Minerals Directorate for Exploration and Research (AMD).")
add(PIB, T, "Which of these states is named among those with AMD’s in-situ U3O8 resources?",
    "Meghalaya", "Kerala", "Goa", "Punjab",
    "The list includes Meghalaya, along with AP, Telangana, Jharkhand, Rajasthan, Karnataka, Chhattisgarh, UP, Uttarakhand, HP and Maharashtra. Kerala, Goa and Punjab are not in that list.")

T = "TRAI MyCall"
add(PIB, T, "TRAI MyCall was relaunched by which regulator?",
    "Telecom Regulatory Authority of India",
    "Department of Telecommunications alone",
    "TRAI’s consumer court in Mumbai",
    "NIXI",
    "TRAI launched a revamped version of the TRAI MyCall app.")
add(PIB, T, "What can users do on the revamped TRAI MyCall app?",
    "Directly assess and report their voice-calling experience",
    "Port their mobile number between operators",
    "Pay telecom bills through UPI only",
    "File an e-Zero FIR",
    "The app lets telecom users assess and report voice-calling experience.")

# ---------- DEFENCE PIB ----------
T = "Exercise Pitch Black 2026"
add(PIB, T, "Exercise Pitch Black is the premier biennial air combat exercise of which air force?",
    "Royal Australian Air Force", "Royal Air Force of the UK", "Indian Air Force", "US Air Force",
    "It is the RAAF’s premier biennial multinational air combat exercise.")
add(PIB, T, "Pitch Black 2026 was primarily operated from which Australian bases?",
    "RAAF Base Darwin, RAAF Base Tindal and RAAF Base Amberley",
    "RAAF Base Pearce, Williamtown and Edinburgh",
    "Only RAAF Base Darwin",
    "RAAF Base Amberley and Townsville only",
    "Darwin and Tindal in the Northern Territory, and Amberley in Queensland.")
add(PIB, T, "How many countries participated in Pitch Black 2026?",
    "21 countries", "18 countries", "26 countries", "14 countries",
    "Total participants: 21 countries.")
add(PIB, T, "India deployed which fighter aircraft to Pitch Black 2026?",
    "Rafale", "Tejas Mk1A", "Su-30MKI only", "Mirage 2000",
    "IAF deployed Rafale fighters, supported by C-17 and IL-78.")
add(PIB, T, "Which support aircraft accompanied the IAF Rafales to Pitch Black 2026?",
    "C-17 Globemaster III and IL-78",
    "C-130J and IL-76",
    "C-17 and P-8I",
    "IL-78 and Mi-17",
    "Support came from C-17 Globemaster III transport aircraft and IL-78 tankers.")
add(PIB, T, "In which earlier editions had the IAF participated in Pitch Black, as named in the magazine?",
    "2018, 2022 and 2024", "2016, 2020 and 2024", "2018, 2021 and 2024", "2014, 2018 and 2022",
    "IAF had previously participated in the 2018, 2022 and 2024 editions.")
add(PIB, T, "Pitch Black’s 2026 edition came in which year of the exercise’s history?",
    "Its 45th year", "Its 40th year", "Its 50th year", "Its 25th year",
    "The magazine refers to the exercise’s 45-year-long history.")

T = "DSC A24"
add(PIB, T, "DSC A24 (Yard 329) is which ship of the Indian Navy’s Diving Support Craft project?",
    "The fifth and final ship", "The first ship", "The third of five", "A sixth additional ship",
    "It is the fifth and final ship of the five-ship DSC project.")
add(PIB, T, "Where was DSC A24 launched, and by whom was it constructed?",
    "Titagarh, Kolkata, by Titagarh Rail Systems Limited",
    "Visakhapatnam, by Hindustan Shipyard",
    "Garden Reach, Kolkata, by GRSE",
    "Mumbai, by Mazagon Dock",
    "It was launched at Titagarh, Kolkata, and constructed by TRSL.")

T = "NIPUN"
add(PIB, T, "NIPUN, delivered to the Indian Navy, is which vessel?",
    "The second Diving Support Vessel, built by Hindustan Shipyard Limited",
    "The first Diving Support Craft, built by TRSL",
    "A nuclear submarine",
    "The fifth DSC of Yard 329",
    "NIPUN is the second DSV, built by HSL and delivered to the Navy.")
add(PIB, T, "Which ship is the first indigenously designed and constructed Diving Support Vessel of the Indian Navy?",
    "INS Nistar", "INS Nipun", "INS Nireekshak", "INS Sarvekshak",
    "INS Nistar is the first indigenously designed and constructed DSV.")

T = "Agni-4"
add(PIB, T, "Agni-4 was successfully test-fired from which range, and under whose aegis?",
    "Integrated Test Range, Chandipur, under the Strategic Forces Command",
    "Wheeler Island, under DRDO only",
    "Pokhran, under the Strategic Forces Command",
    "ITR Chandipur, under the Indian Army’s Southern Command",
    "It was test-fired from ITR Chandipur in Odisha under the Strategic Forces Command.")

# ---------- ENVIRONMENT PIB ----------
T = "El Niño and the monsoon"
add(PIB, T, "IMD predicted the development of which condition during the 2026 Southwest Monsoon?",
    "El Niño conditions", "La Niña conditions", "A neutral ENSO only", "A recognised Super El Niño",
    "IMD predicted El Niño conditions during the 2026 Southwest Monsoon season.")
add(PIB, T, "Do WMO and IMD officially recognise a category called “Super El Niño”?",
    "No, they do not officially recognise it",
    "Yes, both recognise it above a +2.5°C anomaly",
    "Only WMO recognises it, not IMD",
    "Only IMD recognises it",
    "WMO and IMD do not officially recognise “Super El Niño”.")
add(PIB, T, "Operationally, El Niño events are classified as which set of categories?",
    "Weak, moderate, strong and very strong",
    "Weak, moderate, strong and super",
    "Mild, normal, strong and extreme",
    "Category I to Category IV only by rainfall",
    "They are classified as weak, moderate, strong and very strong, mainly on equatorial central Pacific SST anomalies.")
add(PIB, T, "El Niño is which phase of ENSO?",
    "The warm phase, with unusually warm SSTs in the central and eastern equatorial Pacific",
    "The cool phase of ENSO",
    "A phase confined to the Indian Ocean Dipole",
    "The neutral phase of the Pacific",
    "El Niño is the warm phase of ENSO.")
add(PIB, T, "La Niña is characterised by what?",
    "Cooler-than-normal sea-surface temperatures in the central and eastern tropical Pacific",
    "Warmer-than-normal SSTs in the eastern Pacific",
    "A permanent monsoon failure over India",
    "Cooling of the Arabian Sea only",
    "La Niña is the cool phase of ENSO, broadly opposite to El Niño.")

# ---------- AWARDS ----------
T = "Lokmanya Tilak National Award 2026"
add(PIB, T, "The Lokmanya Tilak National Award 2026 was awarded to whom?",
    "Ajit Doval", "S. Jaishankar", "Rajnath Singh", "Nirmala Sitharaman",
    "It was awarded to Ajit Doval, the longest-serving National Security Advisor of India.")
add(PIB, T, "Ajit Doval received the 2026 Lokmanya Tilak National Award in which capacity highlighted by the magazine?",
    "The longest-serving National Security Advisor of India",
    "The Chief of Defence Staff",
    "The Governor of Maharashtra",
    "The Union Home Minister",
    "He is described as the longest-serving NSA of India.")
add(PIB, T, "Who confers or organises the Lokmanya Tilak National Award named in the magazine?",
    "Lokmanya Tilak Smarak Trust, Pune",
    "Tilak Maharashtra Vidyapeeth, Mumbai",
    "Ministry of Culture",
    "Pune Municipal Corporation",
    "It was awarded by the Lokmanya Tilak Smarak Trust in Pune.")
add(PIB, T, "The 2026 presentation of the Tilak award coincided with which anniversary?",
    "The 106th death anniversary of Lokmanya Bal Gangadhar Tilak",
    "The 100th death anniversary of Tilak",
    "The 150th birth anniversary of Tilak",
    "The 75th death anniversary of Tilak",
    "It coincided with the 106th death anniversary of Lokmanya Bal Gangadhar Tilak.")

T = "Sarvottam Jeevan Raksha Padak"
add(PIB, T, "The Sarvottam Jeevan Raksha Padak in this edition was awarded to whom?",
    "12 rat miners for the Silkyara Tunnel rescue in Uttarakhand",
    "The NDRF team at the Uttarakhand floods",
    "12 CRPF personnel at Silkyara",
    "The Silkyara project engineers",
    "It was awarded to 12 rat miners for courage during the Silkyara Tunnel rescue.")
add(PIB, T, "Sarvottam Jeevan Raksha Padak is described as what?",
    "India’s highest civilian life-saving honour",
    "India’s highest peacetime gallantry award",
    "A police medal equivalent to the President’s Police Medal",
    "A wartime decoration of the armed forces",
    "It is India’s highest civilian life-saving honour.")
add(PIB, T, "Sarvottam Jeevan Raksha Padak is administered by which ministry?",
    "Ministry of Home Affairs",
    "Ministry of Defence",
    "Ministry of Health",
    "Prime Minister’s Office",
    "It is administered by the Ministry of Home Affairs.")

# ---------- PERSON / FAIR ----------
T = "Aasha Malviya"
add(PIB, T, "Aasha Malviya completed a solo cycling expedition of what distance?",
    "8,500 km", "5,800 km", "10,500 km", "3,500 km",
    "She completed an 8,500-km solo cycling expedition across India.")
add(PIB, T, "Aasha Malviya’s expedition concluded at which place?",
    "Kibithu in Arunachal Pradesh", "Kibithu in Sikkim", "Dong in Arunachal Pradesh", "Shipki La",
    "It started from the westernmost part of India and concluded at Kibithu in Arunachal Pradesh.")

T = "Bastar Pandum"
add(PIB, T, "Bastar Pandum is organised by which state government?",
    "Government of Chhattisgarh", "Government of Jharkhand", "Government of Odisha", "Government of Madhya Pradesh",
    "It is a tribal cultural festival organised by the Government of Chhattisgarh.")
add(PIB, T, "Bastar Pandum is meant to showcase the heritage of which region’s tribal communities?",
    "The Bastar region", "The Dang region", "The Gondwana region of Maharashtra only", "Bastar and Koraput jointly",
    "It showcases the heritage, folk arts and ancient lifestyle of tribal communities in the Bastar region.")

# ---------- PLACES PIB ----------
T = "Centre of Excellence for Handloom Technology"
add(PIB, T, "The Centre of Excellence for Handloom Technology was set up by the Ministry of Textiles at which institute?",
    "IIT Delhi", "NIFT New Delhi", "IIT Madras", "NID Ahmedabad",
    "It was set up at the Indian Institute of Technology Delhi.")
add(PIB, T, "Handloom 4.0, launched with the CoE-HT, is described as what?",
    "A digital companion for every loom to help weavers assess productivity and sustainability",
    "An export marketplace replacing the Digital Handloom Atlas",
    "A GI registration portal",
    "A powerloom modernisation subsidy",
    "Handloom 4.0 is a digital companion for every loom.")
add(PIB, T, "Handloom e-Vidya is which of the five CoE-HT initiatives?",
    "A problem-linked digital learning platform for weavers, students and other stakeholders",
    "An accelerator for handloom startups",
    "A GenZ design studio",
    "A scheme to recycle defence textiles",
    "Handloom e-Vidya is the problem-linked digital learning and knowledge platform.")
add(PIB, T, "HandloomX under the CoE-HT is what?",
    "An accelerator and incubation platform for startups across the handloom value chain",
    "A yarn-subsidy scheme",
    "A postage-stamp series",
    "The export council of HEPC",
    "HandloomX is an accelerator and incubation platform.")
add(PIB, T, "Kalagriha Handloom Studio is also called what, and aims at whom?",
    "GenZ Design Studio, connecting handloom with next-generation consumers",
    "Weaver Design Studio for master weavers only",
    "GI Design Cell of the Ministry of Culture",
    "A museum gallery at Rashtrapati Bhavan",
    "Kalagriha is the GenZ Design Studio aimed at next-generation consumers through digital visualisation, customisation and authentication.")
add(PIB, T, "Threads of Valour promotes circularity by doing what?",
    "Transforming recycled defence textiles into premium handloom products",
    "Weaving paramilitary uniforms only in Khadi",
    "Exporting surplus defence cloth as scrap",
    "Replacing jute apparel of the CWG squad",
    "It transforms recycled defence textiles into premium handloom products.")

T = "Ujh Multipurpose Project"
add(PIB, T, "The Ujh Multipurpose Project is located in which district?",
    "Kathua district, Jammu & Kashmir", "Udhampur, Jammu & Kashmir", "Kathua, Himachal Pradesh", "Samba, J&K",
    "It is located in Kathua district, Jammu & Kashmir.")
add(PIB, T, "The Ujh River, on which the project is developed, is a major tributary of which river?",
    "Ravi", "Chenab", "Beas", "Jhelum",
    "Ujh is a major tributary of the Ravi.")
add(PIB, T, "The Ujh Multipurpose Project is being implemented by which agency?",
    "WAPCOS Ltd. under the Ministry of Jal Shakti",
    "NHPC under the Ministry of Power",
    "NWDA under the Ministry of Jal Shakti",
    "BRO under the Ministry of Defence",
    "It is being implemented by WAPCOS Ltd., a Government of India undertaking under the Ministry of Jal Shakti.")

# ---------- DAYS PIB ----------
T = "World Breastfeeding Week 2026"
add(PIB, T, "World Breastfeeding Week 2026 was observed on which dates?",
    "1st to 7th August", "1st to 7th July", "7th to 14th August", "1st August only",
    "It is listed as 1st to 7th August.")
add(PIB, T, "The theme of World Breastfeeding Week 2026 was:",
    "Breastfeeding for a Sustainable Start in Life: Strengthen What Works",
    "Breastfeeding: Support, Promote, Protect",
    "Closing the Gap for Working Mothers",
    "Breastfeeding and Planetary Health",
    "The theme is “Breastfeeding for a Sustainable Start in Life: Strengthen What Works.”")

T = "National Handloom Day"
add(PIB, T, "The 12th National Handloom Day was observed on which date?",
    "7 August", "5 August", "15 August", "9 August",
    "National Handloom Day falls on 7 August.")
add(PIB, T, "National celebrations of Handloom Day were held at which venue?",
    "Rashtrapati Bhavan Cultural Centre, New Delhi",
    "Central Cottage Industries Emporium only",
    "Vigyan Bhawan",
    "Pragati Maidan",
    "National celebrations were held at RBCC, New Delhi.")
add(PIB, T, "National Handloom Day commemorates which historical event?",
    "The Swadeshi Movement launched on 7 August 1905",
    "The Quit India Movement of 1942",
    "The Dandi March of 1930",
    "The partition of Bengal in 1911",
    "It commemorates the Swadeshi Movement launched on 7 August 1905.")
add(PIB, T, "National Handloom Day was first observed in which year?",
    "2015", "2014", "2005", "2017",
    "It was first observed in 2015.")
add(PIB, T, "The ‘Weaves of India’ Festival during Handloom Day was held at which place?",
    "Central Cottage Industries Emporium, Janpath, New Delhi",
    "Dilli Haat, INA",
    "National Crafts Museum",
    "Handloom Haat, Ahmedabad",
    "It was held at CCIE, Janpath, New Delhi.")
add(PIB, T, "How many commemorative postage stamps on handloom traditions were released on National Handloom Day?",
    "Four", "Two", "Five", "Twelve",
    "Four commemorative postage stamps were released.")

T = "Lalit Kala Akademi"
add(PIB, T, "The 72nd Foundation Day of Lalit Kala Akademi fell on which date?",
    "5 August", "7 August", "15 August", "5 September",
    "It is listed as August 5.")
add(PIB, T, "Lalit Kala Akademi is the National Academy of Art under which ministry?",
    "Ministry of Culture", "Ministry of Textiles", "Ministry of Education", "Ministry of Tourism",
    "It is the National Academy of Art under the Ministry of Culture.")
add(PIB, T, "Lalit Kala Akademi was established in which year?",
    "1954", "1947", "1950", "1964",
    "The Akademi was established in 1954 to promote visual arts.")

# ---------- MISC PIB ----------
T = "Articles 370 and 35A"
add(PIB, T, "Articles 370 and 35(A) were abrogated on which date?",
    "5 August 2019", "5 August 2020", "31 October 2019", "15 August 2019",
    "They were abrogated on August 5, 2019. The 2026 anniversary is the seventh.")
add(PIB, T, "The 2026 anniversary of the abrogation gained extra significance because the nation also marked what?",
    "The 125th birth anniversary of Dr Syama Prasad Mookerjee",
    "The 100th birth anniversary of Dr Syama Prasad Mookerjee",
    "The 75th anniversary of the Constitution",
    "The 50th year of the Shimla Agreement",
    "2026 also commemorates the 125th birth anniversary of Dr Syama Prasad Mookerjee.")
add(PIB, T, "Article 370, enacted in 1949, allowed Jammu and Kashmir which of the following?",
    "Its own constitution, a state flag, and independent internal administration",
    "Only a separate high court",
    "A right to secede after ten years",
    "Its own currency and army",
    "It allowed a separate constitution, a state flag and independent internal administration.")
add(PIB, T, "Article 35(A) was introduced by what instrument, and in which year?",
    "A 1954 Presidential Order under Article 370",
    "A 1952 Parliamentary Act",
    "The Delhi Agreement of 1952 itself",
    "A 1949 Schedule to the Constitution",
    "It was introduced via a 1954 Presidential Order under Article 370.")
add(PIB, T, "Under Article 35(A), who could define “permanent residents” of Jammu and Kashmir?",
    "The state legislature",
    "Only the President of India",
    "The Constituent Assembly of India",
    "The Supreme Court",
    "It empowered the state legislature to define permanent residents, who alone could buy land, get government jobs or state scholarships.")

T = "India as a Tourism Hub"
add(PIB, T, "Domestic tourist visits in India in 2024 are given as:",
    "2.9 billion, exceeding pre-pandemic levels",
    "2.9 crore",
    "1.9 billion",
    "2.02 billion",
    "There were 2.9 billion domestic tourist visits in 2024.")
add(PIB, T, "International tourist arrivals in 2025 are stated as around:",
    "2.02 crore", "2.02 lakh", "2.9 crore", "15.73 crore",
    "Around 2.02 crore international tourist arrivals in 2025.")
add(PIB, T, "Tourism’s contribution to India’s GDP in FY 2023-24 was:",
    "₹15.73 lakh crore, about 5.22% of the economy",
    "₹15.73 lakh crore, about 8.22%",
    "₹5.73 lakh crore, about 5.22%",
    "₹15.73 thousand crore, about 5.22%",
    "₹15.73 lakh crore, accounting for 5.22% of the economy.")
add(PIB, T, "India is home to how many UNESCO World Heritage Sites, National Parks and Biosphere Reserves, as stated?",
    "45 UNESCO sites, 106 National Parks and 18 Biosphere Reserves",
    "42 UNESCO sites, 106 National Parks and 18 Biosphere Reserves",
    "45 UNESCO sites, 100 National Parks and 18 Biosphere Reserves",
    "45 UNESCO sites, 106 National Parks and 12 Biosphere Reserves",
    "The magazine states 45 UNESCO World Heritage Sites, 106 National Parks and 18 Biosphere Reserves.")
add(PIB, T, "India is described as emerging as a leading destination for which form of tourism?",
    "MICE — Meetings, Incentives, Conferences and Exhibitions",
    "Only medical tourism",
    "Only cruise tourism",
    "Dark-sky tourism",
    "India is emerging as a leading MICE destination.")

T = "XWG Diesel"
add(PIB, T, "Xtreme Weather Grade (XWG) Diesel was developed jointly by whom?",
    "The Indian Army and Oil Marketing Companies",
    "The Indian Air Force and ONGC",
    "DRDO and Indian Oil alone, excluding other OMCs",
    "The Indian Navy and BPCL only",
    "It was developed jointly by the Indian Army and Oil Marketing Companies.")
add(PIB, T, "XWG Diesel is meant to enhance mobility of which vehicles?",
    "Combat and logistics vehicles in extreme climatic conditions",
    "Only civilian trucks in the plains",
    "Naval warships",
    "Electric buses under PM-eBus Sewa",
    "The specialised fuel is for combat and logistics vehicles in extreme climatic conditions.")

T = "Coal milestones"
add(PIB, T, "India’s coal resource is assessed at about how much, and what is its global rank by resource size?",
    "About 4,00,715 million tonnes, the world’s fifth largest",
    "About 4,00,715 million tonnes, the world’s third largest",
    "About 3,00,715 million tonnes, the fifth largest",
    "About 4,00,715 billion tonnes, the fifth largest",
    "India holds the world’s fifth largest coal resource, about 4,00,715 million tonnes.")
add(PIB, T, "In production and consumption of coal, India ranks as:",
    "The second largest producer and the second largest consumer",
    "The largest producer and second largest consumer",
    "The third largest producer and largest consumer",
    "The fifth largest producer and consumer",
    "India ranks second as both producer and consumer of coal.")
add(PIB, T, "Domestic coal production in FY 2024-25 and FY 2025-26 was:",
    "1047.52 MT and 1040.08 MT",
    "1040.08 MT and 1047.52 MT",
    "947.52 MT and 1040.08 MT",
    "1147.52 MT and 1040.08 MT",
    "Production was 1047.52 MT in FY 2024-25 and 1040.08 MT in FY 2025-26, both above one billion tonnes.")

T = "Mahanadi dispute"
add(PIB, T, "The Mahanadi water dispute is primarily between which two states?",
    "Odisha and Chhattisgarh", "Odisha and Jharkhand", "Chhattisgarh and Maharashtra", "Odisha and Andhra Pradesh",
    "It is primarily between Odisha and Chhattisgarh.")
add(PIB, T, "The Mahanadi originates in which hills and district?",
    "Sihawa Hills of Dhamtari district, Chhattisgarh",
    "Amarkantak in Anuppur, Madhya Pradesh",
    "Mahabaleshwar, Maharashtra",
    "Sihawa Hills of Raipur district",
    "It originates in the Sihawa Hills of Dhamtari district, Chhattisgarh.")
add(PIB, T, "Hirakud Dam is built across the Mahanadi near which place?",
    "Sambalpur in Odisha", "Cuttack in Odisha", "Raipur in Chhattisgarh", "Hirakud in Chhattisgarh",
    "Hirakud Dam, near Sambalpur in Odisha, is built across the Mahanadi.")
add(PIB, T, "The Mahanadi is described as what kind of river?",
    "A major east-flowing peninsular river",
    "A west-flowing peninsular river",
    "A trans-Himalayan river",
    "A tributary of the Godavari",
    "It is a major east-flowing peninsular river of India.")

print("part A", len(qs))
Path("/tmp/qs_part_a.json").write_text(json.dumps(qs, ensure_ascii=False))
print("wrote", len(qs))
