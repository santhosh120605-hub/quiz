import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import { Check, Flag, X } from "lucide-react";
import { QUESTIONS, sectionCounts, type Question } from "@/data/questions";

type Phase = "home" | "quiz" | "result" | "review";

type Save = {
  phase: Exclude<Phase, "home">;
  index: number;
  answers: Array<number | null>;
  flags: boolean[];
};

const STORAGE_KEY = "week-one-drill-v1";
const TOTAL = QUESTIONS.length;

function emptyAnswers() {
  return Array<number | null>(TOTAL).fill(null);
}

function emptyFlags() {
  return Array<boolean>(TOTAL).fill(false);
}

function loadSave(): Save | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Save;
    if (!parsed || !Array.isArray(parsed.answers) || parsed.answers.length !== TOTAL) return null;
    if (!Array.isArray(parsed.flags) || parsed.flags.length !== TOTAL) return null;
    if (parsed.index < 0 || parsed.index >= TOTAL) parsed.index = 0;
    return parsed;
  } catch {
    return null;
  }
}

function scoreOf(answers: Array<number | null>) {
  let correct = 0;
  let wrong = 0;
  let skipped = 0;
  for (let i = 0; i < TOTAL; i++) {
    const pick = answers[i];
    if (pick == null) skipped += 1;
    else if (pick === QUESTIONS[i]!.answer) correct += 1;
    else wrong += 1;
  }
  return { correct, wrong, skipped, attempted: correct + wrong };
}

function sectionScore(answers: Array<number | null>) {
  return sectionCounts().map(({ section, count }) => {
    let correct = 0;
    let attempted = 0;
    QUESTIONS.forEach((q, i) => {
      if (q.section !== section) return;
      const pick = answers[i];
      if (pick == null) return;
      attempted += 1;
      if (pick === q.answer) correct += 1;
    });
    return { section, count, correct, attempted };
  });
}

export function Drill() {
  const [phase, setPhase] = useState<Phase>("home");
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Array<number | null>>(emptyAnswers);
  const [flags, setFlags] = useState<boolean[]>(emptyFlags);
  const [hasSave, setHasSave] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [mapFilter, setMapFilter] = useState<"all" | "open" | "flagged" | "wrong">("all");
  const [jump, setJump] = useState("");
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = loadSave();
    if (!saved) return;
    setHasSave(true);
    setAnswers(saved.answers);
    setFlags(saved.flags);
    setIndex(saved.index);
    setPhase(saved.phase);
  }, []);

  useEffect(() => {
    if (phase === "home") return;
    const payload: Save = { phase, index, answers, flags };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    setHasSave(true);
  }, [phase, index, answers, flags]);

  useEffect(() => {
    const root = mapRef.current;
    const el = root?.querySelector<HTMLButtonElement>(`[data-q="${index}"]`);
    if (!root || !el) return;
    const top = el.offsetTop - root.offsetTop;
    const bottom = top + el.offsetHeight;
    if (top < root.scrollTop) root.scrollTop = top - 8;
    else if (bottom > root.scrollTop + root.clientHeight) {
      root.scrollTop = bottom - root.clientHeight + 8;
    }
  }, [index, phase, mapFilter]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (phase !== "quiz" && phase !== "review") return;
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        setIndex((n) => Math.min(TOTAL - 1, n + 1));
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        setIndex((n) => Math.max(0, n - 1));
      } else if (phase === "quiz" && ["1", "2", "3", "4"].includes(event.key)) {
        pick(Number(event.key) - 1);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const question = QUESTIONS[index]!;
  const totals = useMemo(() => scoreOf(answers), [answers]);
  const blocks = useMemo(() => sectionScore(answers), [answers]);
  const answeredCount = totals.attempted;

  function pick(option: number) {
    if (phase !== "quiz") return;
    setAnswers((prev) => {
      const next = prev.slice();
      next[index] = option;
      return next;
    });
  }

  function toggleFlag() {
    setFlags((prev) => {
      const next = prev.slice();
      next[index] = !next[index];
      return next;
    });
  }

  function startFresh() {
    setAnswers(emptyAnswers());
    setFlags(emptyFlags());
    setIndex(0);
    setMapFilter("all");
    setConfirming(false);
    setPhase("quiz");
    localStorage.removeItem(STORAGE_KEY);
  }

  function goJump() {
    const n = Number(jump);
    if (!Number.isFinite(n)) return;
    const clamped = Math.min(TOTAL, Math.max(1, Math.floor(n)));
    setIndex(clamped - 1);
    setJump("");
  }

  const visibleIds = useMemo(() => {
    const ids: number[] = [];
    for (let i = 0; i < TOTAL; i++) {
      if (mapFilter === "open" && answers[i] != null) continue;
      if (mapFilter === "flagged" && !flags[i]) continue;
      if (mapFilter === "wrong" && !(answers[i] != null && answers[i] !== QUESTIONS[i]!.answer)) continue;
      ids.push(i);
    }
    return ids;
  }, [mapFilter, answers, flags]);

  return (
    <div className="min-h-dvh text-ink">
      <header className="border-b-4 border-gold bg-teal-deep text-paper">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <div>
            <p className="text-xs font-semibold tracking-[0.18em] text-foam/80">1–7 AUGUST 2026</p>
            <p className="font-serif text-lg leading-none">Week One Drill</p>
          </div>
          {phase !== "home" ? (
            <p className="text-right text-sm text-foam">
              <span className="font-semibold text-paper">{answeredCount}</span> answered
              <span className="mx-1 text-foam/50">/</span>
              {TOTAL}
            </p>
          ) : null}
        </div>
      </header>

      {phase === "home" ? (
        <Home
          hasSave={hasSave}
          onStart={startFresh}
          onResume={() => {
            const saved = loadSave();
            if (!saved) {
              startFresh();
              return;
            }
            setPhase(saved.phase);
          }}
        />
      ) : null}

      {phase === "result" ? (
        <Result
          totals={totals}
          blocks={blocks}
          onReview={() => {
            setMapFilter("all");
            setIndex(0);
            setPhase("review");
          }}
          onMistakes={() => {
            setMapFilter("wrong");
            const first = answers.findIndex((pick, i) => pick != null && pick !== QUESTIONS[i]!.answer);
            setIndex(first >= 0 ? first : 0);
            setPhase("review");
          }}
          onAgain={startFresh}
        />
      ) : null}

      {phase === "quiz" || phase === "review" ? (
        <Paper
          phase={phase}
          question={question}
          index={index}
          answers={answers}
          flagged={flags[index] ?? false}
          onPick={pick}
          onFlag={toggleFlag}
          onPrev={() => setIndex((n) => Math.max(0, n - 1))}
          onNext={() => setIndex((n) => Math.min(TOTAL - 1, n + 1))}
          onSubmit={() => setConfirming(true)}
          onExit={() => setPhase("result")}
          mapRef={mapRef}
          visibleIds={visibleIds}
          mapFilter={mapFilter}
          setMapFilter={setMapFilter}
          jump={jump}
          setJump={setJump}
          onJump={goJump}
          flags={flags}
          onJumpTo={setIndex}
        />
      ) : null}

      {confirming ? (
        <div className="fixed inset-0 z-20 flex items-end justify-center bg-ink/40 p-4 sm:items-center">
          <div className="w-full max-w-md border border-line bg-card p-5 shadow-lg" role="dialog" aria-modal="true">
            <h2 className="font-serif text-2xl">Submit the paper?</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              {totals.skipped === 0
                ? "Every question has an answer. You can still go back before submitting."
                : `${totals.skipped} question${totals.skipped === 1 ? " is" : "s are"} still open. Unanswered items score as skipped.`}
            </p>
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <button
                type="button"
                className="min-h-11 flex-1 border border-line bg-card px-4 text-sm font-semibold"
                onClick={() => setConfirming(false)}
              >
                Keep going
              </button>
              <button
                type="button"
                className="min-h-11 flex-1 bg-teal px-4 text-sm font-semibold text-paper"
                onClick={() => {
                  setConfirming(false);
                  setPhase("result");
                }}
              >
                Submit and see marks
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Home({ hasSave, onStart, onResume }: { hasSave: boolean; onStart: () => void; onResume: () => void }) {
  const blocks = sectionCounts();
  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <p className="text-xs font-semibold tracking-[0.16em] text-teal">GA · ESI · FINANCE</p>
      <h1 className="mt-2 max-w-2xl font-serif text-4xl leading-tight sm:text-5xl">
        The full first-week paper. Every question. No clock.
      </h1>
      <p className="mt-4 max-w-2xl text-base leading-relaxed text-muted">
        One sitting built from the 1–7 August 2026 current-affairs boxes: each row is in the paper, and the long
        ones — Games, nuclear, Ramsar, ports, company law — are drilled harder. Choose an option, move with the
        map, and open the score only when you submit.
      </p>
      <div className="mt-6 flex flex-wrap gap-2 text-sm">
        <Stat label="Questions" value={String(TOTAL)} />
        <Stat label="Blocks" value="4" />
        <Stat label="Timer" value="None" />
      </div>
      <div className="mt-6 flex flex-col gap-2 sm:flex-row">
        <button type="button" className="min-h-11 bg-teal px-5 font-semibold text-paper" onClick={onStart}>
          Start the full paper
        </button>
        {hasSave ? (
          <button type="button" className="min-h-11 border border-teal px-5 font-semibold text-teal" onClick={onResume}>
            Resume saved paper
          </button>
        ) : null}
      </div>
      <ul className="mt-8 grid gap-3 sm:grid-cols-2">
        {blocks.map((block) => (
          <li key={block.section} className="border border-line bg-card px-4 py-3">
            <p className="text-xs font-semibold tracking-wide text-teal">{block.section}</p>
            <p className="mt-1 font-serif text-2xl">{block.count}</p>
            <p className="text-sm text-muted">questions in this block</p>
          </li>
        ))}
      </ul>
      <p className="mt-6 max-w-2xl text-sm leading-relaxed text-muted">
        Answers stay on this device until you submit or start again. Keys 1–4 mark an option; arrow keys move.
      </p>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <span className="inline-flex items-baseline gap-2 border border-line bg-card px-3 py-2">
      <span className="font-serif text-xl">{value}</span>
      <span className="text-muted">{label}</span>
    </span>
  );
}

function Result({
  totals,
  blocks,
  onReview,
  onMistakes,
  onAgain,
}: {
  totals: ReturnType<typeof scoreOf>;
  blocks: ReturnType<typeof sectionScore>;
  onReview: () => void;
  onMistakes: () => void;
  onAgain: () => void;
}) {
  const pct = Math.round((totals.correct / TOTAL) * 100);
  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <p className="text-xs font-semibold tracking-[0.16em] text-teal">PAPER SUBMITTED</p>
      <h1 className="mt-2 font-serif text-4xl leading-tight">Your marks</h1>
      <p className="mt-3 font-serif text-6xl text-teal">
        {totals.correct}
        <span className="text-3xl text-muted"> / {TOTAL}</span>
      </p>
      <p className="mt-1 text-muted">{pct}% correct · no negative marking</p>
      <dl className="mt-6 grid grid-cols-3 gap-2 text-center">
        <div className="border border-line bg-card px-2 py-3">
          <dt className="text-xs text-muted">Correct</dt>
          <dd className="font-serif text-2xl text-moss">{totals.correct}</dd>
        </div>
        <div className="border border-line bg-card px-2 py-3">
          <dt className="text-xs text-muted">Wrong</dt>
          <dd className="font-serif text-2xl text-maroon">{totals.wrong}</dd>
        </div>
        <div className="border border-line bg-card px-2 py-3">
          <dt className="text-xs text-muted">Skipped</dt>
          <dd className="font-serif text-2xl">{totals.skipped}</dd>
        </div>
      </dl>
      <div className="mt-6 overflow-x-auto border border-line bg-card">
        <table className="w-full min-w-[32rem] text-left text-sm">
          <thead className="bg-teal text-paper">
            <tr>
              <th className="px-3 py-2 font-semibold">Block</th>
              <th className="px-3 py-2 font-semibold">Correct</th>
              <th className="px-3 py-2 font-semibold">Attempted</th>
              <th className="px-3 py-2 font-semibold">In paper</th>
            </tr>
          </thead>
          <tbody>
            {blocks.map((block) => (
              <tr key={block.section} className="border-t border-line">
                <td className="px-3 py-2">{block.section}</td>
                <td className="px-3 py-2">{block.correct}</td>
                <td className="px-3 py-2">{block.attempted}</td>
                <td className="px-3 py-2">{block.count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-6 flex flex-col gap-2 sm:flex-row">
        <button type="button" className="min-h-11 bg-teal px-5 font-semibold text-paper" onClick={onReview}>
          Review every answer
        </button>
        <button
          type="button"
          className="min-h-11 border border-maroon px-5 font-semibold text-maroon"
          onClick={onMistakes}
          disabled={totals.wrong === 0}
        >
          Review mistakes
        </button>
        <button type="button" className="min-h-11 border border-line bg-card px-5 font-semibold" onClick={onAgain}>
          Start again
        </button>
      </div>
    </main>
  );
}

function Paper(props: {
  phase: "quiz" | "review";
  question: Question;
  index: number;
  answers: Array<number | null>;
  flagged: boolean;
  onPick: (option: number) => void;
  onFlag: () => void;
  onPrev: () => void;
  onNext: () => void;
  onSubmit: () => void;
  onExit: () => void;
  mapRef: RefObject<HTMLDivElement | null>;
  visibleIds: number[];
  mapFilter: "all" | "open" | "flagged" | "wrong";
  setMapFilter: (value: "all" | "open" | "flagged" | "wrong") => void;
  jump: string;
  setJump: (value: string) => void;
  onJump: () => void;
  flags: boolean[];
  onJumpTo: (index: number) => void;
}) {
  const { question, index, answers, phase } = props;
  const pick = answers[index];
  const letters = ["A", "B", "C", "D"];

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-4.25rem)] max-w-5xl flex-col">
      <div className="flex-1 px-4 pt-4">
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold tracking-wide text-teal">
          <span>
            {index + 1} / {TOTAL}
          </span>
          <span className="text-line">|</span>
          <span>{question.section}</span>
        </div>
        <p className="mt-1 text-sm text-muted">{question.topic}</p>
        <h2 className="mt-3 font-serif text-2xl leading-snug sm:text-3xl">{question.prompt}</h2>
        <div className="mt-4 grid gap-2" role="listbox" aria-label="Options">
          {question.options.map((option, optionIndex) => {
            const selected = pick === optionIndex;
            const showKey = phase === "review";
            const isCorrect = optionIndex === question.answer;
            const isWrongPick = showKey && selected && !isCorrect;
            let tone = "border-line bg-card";
            if (!showKey && selected) tone = "border-teal bg-foam";
            if (showKey && isCorrect) tone = "border-moss bg-foam";
            if (isWrongPick) tone = "border-maroon bg-card";
            return (
              <button
                key={option}
                type="button"
                role="option"
                aria-selected={selected}
                disabled={phase === "review"}
                onClick={() => props.onPick(optionIndex)}
                className={`flex min-h-11 items-start gap-3 border px-3 py-3 text-left ${tone}`}
              >
                <span
                  className={`mt-0.5 flex size-7 shrink-0 items-center justify-center text-xs font-semibold ${
                    showKey && isCorrect
                      ? "bg-moss text-paper"
                      : isWrongPick
                        ? "bg-maroon text-paper"
                        : selected
                          ? "bg-teal text-paper"
                          : "bg-paper text-ink"
                  }`}
                >
                  {letters[optionIndex]}
                </span>
                <span className="text-sm leading-relaxed sm:text-base">{option}</span>
                {showKey && isCorrect ? <Check className="ml-auto size-4 shrink-0 text-moss" aria-hidden /> : null}
                {isWrongPick ? <X className="ml-auto size-4 shrink-0 text-maroon" aria-hidden /> : null}
              </button>
            );
          })}
        </div>
        {phase === "review" ? (
          <p className="mt-4 border-l-4 border-teal bg-card px-3 py-3 text-sm leading-relaxed">
            <span className="font-semibold">Why. </span>
            {question.why}
            {pick == null ? <span className="mt-1 block text-muted">You skipped this one.</span> : null}
          </p>
        ) : null}
        <div className="mt-4 flex flex-wrap gap-2 pb-4">
          <button type="button" className="min-h-11 border border-line bg-card px-4 text-sm font-semibold" onClick={props.onPrev} disabled={index === 0}>
            Previous
          </button>
          <button
            type="button"
            className="min-h-11 border border-line bg-card px-4 text-sm font-semibold"
            onClick={props.onNext}
            disabled={index === TOTAL - 1}
          >
            Next
          </button>
          {phase === "quiz" ? (
            <button
              type="button"
              className={`inline-flex min-h-11 items-center gap-2 border px-4 text-sm font-semibold ${
                props.flagged ? "border-gold bg-card text-gold" : "border-line bg-card"
              }`}
              onClick={props.onFlag}
            >
              <Flag className="size-4" aria-hidden />
              {props.flagged ? "Flagged" : "Flag"}
            </button>
          ) : null}
          <button
            type="button"
            className="min-h-11 bg-teal px-4 text-sm font-semibold text-paper sm:ml-auto"
            onClick={phase === "quiz" ? props.onSubmit : props.onExit}
          >
            {phase === "quiz" ? "Submit paper" : "Back to marks"}
          </button>
        </div>
      </div>

      <section className="sticky bottom-0 border-t border-line bg-card" aria-label="Question map">
        <div className="flex flex-wrap items-center gap-2 px-3 py-2">
          <p className="text-xs font-semibold tracking-wide text-teal">All {TOTAL} questions</p>
          <Filter
            active={props.mapFilter === "all"}
            onClick={() => props.setMapFilter("all")}
            label="All"
          />
          {phase === "quiz" ? (
            <Filter active={props.mapFilter === "open"} onClick={() => props.setMapFilter("open")} label="Open" />
          ) : (
            <Filter active={props.mapFilter === "wrong"} onClick={() => props.setMapFilter("wrong")} label="Wrong" />
          )}
          <Filter active={props.mapFilter === "flagged"} onClick={() => props.setMapFilter("flagged")} label="Flagged" />
          <form
            className="ml-auto flex items-center gap-1"
            onSubmit={(event) => {
              event.preventDefault();
              props.onJump();
            }}
          >
            <label className="sr-only" htmlFor="jump">
              Jump to question number
            </label>
            <input
              id="jump"
              inputMode="numeric"
              value={props.jump}
              onChange={(event) => props.setJump(event.target.value.replace(/[^\d]/g, ""))}
              placeholder={`1–${TOTAL}`}
              className="h-11 w-20 border border-line bg-paper px-2 text-sm"
            />
            <button type="submit" className="h-11 border border-line px-3 text-sm font-semibold">
              Go
            </button>
          </form>
        </div>
        <div ref={props.mapRef} className="max-h-44 overflow-y-auto px-3 pb-3">
          <div className="flex flex-wrap gap-1">
            {props.visibleIds.map((id) => {
              const chosen = answers[id];
              const current = id === index;
              const flagged = props.flags[id];
              let tone = "border-line bg-paper text-ink";
              if (chosen != null && phase === "quiz") tone = "border-teal bg-foam text-teal";
              if (phase === "review" && chosen == null) tone = "border-line bg-paper text-muted";
              if (phase === "review" && chosen != null && chosen === QUESTIONS[id]!.answer) {
                tone = "border-moss bg-foam text-moss";
              }
              if (phase === "review" && chosen != null && chosen !== QUESTIONS[id]!.answer) {
                tone = "border-maroon bg-card text-maroon";
              }
              if (current) tone = "border-teal-deep bg-teal text-paper";
              return (
                <button
                  key={id}
                  type="button"
                  data-q={id}
                  onClick={() => props.onJumpTo(id)}
                  className={`relative size-11 text-xs font-semibold ${tone}`}
                  aria-current={current ? "true" : undefined}
                  aria-label={`Question ${id + 1}`}
                >
                  {id + 1}
                  {flagged ? <span className="absolute right-0.5 top-0.5 size-1.5 bg-gold" /> : null}
                </button>
              );
            })}
          </div>
          {props.visibleIds.length === 0 ? (
            <p className="py-4 text-sm text-muted">Nothing in this filter.</p>
          ) : null}
        </div>
      </section>
    </div>
  );
}

function Filter({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-8 px-2 text-xs font-semibold ${active ? "bg-teal text-paper" : "text-muted"}`}
    >
      {label}
    </button>
  );
}
