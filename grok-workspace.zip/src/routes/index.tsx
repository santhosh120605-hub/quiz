import { createFileRoute } from "@tanstack/react-router";
import { Drill } from "@/components/drill";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Drill />;
}
