//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-no2Qda9q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DVuIetVe.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DVuIetVe.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DbsivEwu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
